#!/bin/bash
# DSP 서비스 중지
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_DIR="$ROOT_DIR/logs"

stop_pid() {
    local name=$1
    local pidfile="$LOG_DIR/$2.pid"
    if [ -f "$pidfile" ]; then
        local pid=$(cat "$pidfile")
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            echo "[stop] $name (PID $pid) 종료됨"
        else
            echo "[stop] $name 이미 종료됨"
        fi
        rm -f "$pidfile"
    fi
}

stop_pid "API 서버"    server
stop_pid "스캔 워커"   worker
stop_pid "Python 스캐너" python
stop_pid "Dash 대시보드" dash

# 포트 강제 종료 (혹시 남아있으면)
for port in 3000 8000 8050; do
    pid=$(lsof -ti:$port 2>/dev/null)
    if [ -n "$pid" ]; then
        kill -9 $pid 2>/dev/null && echo "[stop] 포트 $port 강제 종료"
    fi
done

echo "✅ DSP 중지 완료"
