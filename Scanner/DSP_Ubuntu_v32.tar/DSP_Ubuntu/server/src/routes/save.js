/**
 * POST /save
 *
 * python/scanner.py 의 /scan 엔드포인트가 스캔 완료 후 호출합니다.
 * multipart/form-data 형식으로 payload JSON + 원시 JSON 파일들을 전송합니다.
 *
 * ── 파일 저장 정책 ──────────────────────────────────────────────────────
 * DB(Supabase)에 이미 저장되는 정제 데이터와 중복을 피하기 위해
 * 스캐너 원시 출력(RAW)만 디스크에 저장합니다.
 *
 *   저장 O (RAW — DB에 없는 원본):
 *     grype.json   — Grype 원시 JSON 출력 전체
 *     trivy.json   — Trivy 원시 JSON 출력 전체
 *
 *   저장 X (이미 DB에 있는 정제 데이터):
 *     result_grype_vulnerabilities.json  → OS_filtered 테이블        (구 grype_filtered)
 *     result_trivy_vulnerabilities.json  → application_filtered 테이블
 *     result_secrets.json                → security_filtered 테이블
 *     result_scan_report.json            → scan_reports 테이블
 *     result_cross_analysis.json         → grype_only / trivy_only / mismatch 3개 테이블로 분산
 *
 * ── 저장 경로 ──────────────────────────────────────────────────────────
 *   server/uploads/{user_id}/{job_id}_{YYYYMMDD_HHMMSS}/
 *     ├── grype.json
 *     └── trivy.json
 *
 *   같은 이미지를 여러 번 분석해도 타임스탬프로 구분됩니다.
 *   나중에 계정관리 도입 시 user_id → 실제 계정명으로 교체합니다.
 *
 * ── Supabase 스키마 (2026-05-28 DB 리팩토링 반영) ───────────────────────
 *   [기존 유지]
 *   - application_filtered.is_fixed_available: GENERATED → INSERT 불가
 *   - application_filtered.severity: CHECK enum {CRITICAL/HIGH/MEDIUM/LOW/UNKNOWN}
 *   - application_filtered.source:   CHECK enum {'trivy' only}
 *   - security_filtered.severity:    CHECK 제약 없음
 *   - security_filtered.source:      CHECK enum {'trivy' only}
 *   - scan_jobs.status CHECK: {pending/uploaded/running/completed/failed/cancelled}
 *   - scan_jobs.trivy_status/grype_status CHECK: {pending/running/completed/failed/skipped}
 *   - scan_jobs.file_type CHECK: {image_tar/dockerfile/sbom}
 *   [신규/변경 — 2026-05 리팩토링]
 *   - grype_filtered 삭제 → OS_filtered 로 대체 (컬럼 동일 + `version` 추가).
 *     OS_filtered.is_fixed_available: GENERATED → INSERT 불가
 *     OS_filtered.source: 'grype' / severity: 자유 텍스트
 *   - 교차분석이 디스크 cross_analysis JSON 뿐이었던 → DB 정식 테이블 3개로 적재:
 *       grype_only   (20 cols, OS_filtered 와 동일 스키마)
 *       trivy_only   (19 cols, application_filtered 와 동일 스키마)
 *       mismatch     (28 cols, Grype 베이스 + grype_* + trivy_* 평탄화)
 *   [FK 정책]
 *   - user_id FK → profiles.id  (user_profiles 는 DB 작업 미완성으로 임시 공존, 향후 이전 예정)
 *   - auth 미도입 시 user_id 는 INSERT 에서 제외 (NULL)
 *   - job_id: scanner.py 가 생성하지 않으므로 Node.js 에서 UUID 생성
 */

const express        = require('express');
const multer         = require('multer');
const fs             = require('fs');
const path           = require('path');
const { v4: uuidv4 } = require('uuid');
const supabase       = require('../db/index');
const { getUserSupabase } = require('../db/index');   // v17: JWT → user_id 추출용

const router     = express.Router();
const CHUNK_SIZE = 500;

// RAW 파일만 디스크에 저장 (grype / trivy)
const RAW_FILES = new Set(['grype.json', 'trivy.json']);

// 업로드 루트: server/uploads/
const UPLOAD_BASE = path.resolve(__dirname, '../../uploads');

// multipart/form-data 파싱 — 메모리에 받은 뒤 직접 경로 결정 후 저장
const upload = multer({ storage: multer.memoryStorage() });

// ── 헬퍼: 타임스탬프 생성 (YYYYMMDD_HHMMSS) ────────────────────
function makeTimestamp() {
  const d   = new Date();
  const pad = n => String(n).padStart(2, '0');
  return (
    `${d.getFullYear()}` +
    `${pad(d.getMonth() + 1)}` +
    `${pad(d.getDate())}_` +
    `${pad(d.getHours())}` +
    `${pad(d.getMinutes())}` +
    `${pad(d.getSeconds())}`
  );
}

// ── 헬퍼: user_id → 파일시스템 안전 문자열 ──────────────────────
function safeId(id) {
  return String(id || 'anonymous').replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 64);
}

// ── 헬퍼: Supabase 청크 삽입 ────────────────────────────────────
async function insertChunked(table, rows) {
  for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
    const chunk = rows.slice(i, i + CHUNK_SIZE);
    const { error } = await supabase.from(table).insert(chunk);
    if (error) {
      console.error(`[Save] ${table} INSERT 실패: ${error.message}`);
      console.error(`[Save] ${table} 첫 행 샘플:`, JSON.stringify(chunk[0]).slice(0, 200));
    }
  }
}

// (참고) toGrypeSev() 함수는 제거됨.
// 이유: grype_filtered.severity 컬럼에 CHECK 제약이 없어 변환 불필요.
//       application_filtered (UPPERCASE) 와 형식을 통일하기 위해 UPPERCASE 그대로 사용.

// ── POST /save ──────────────────────────────────────────────────
router.post('/', upload.any(), async (req, res) => {

  // ── 0. payload 파싱 ──────────────────────────────────────────
  const payloadStr = req.body.payload;
  if (!payloadStr) {
    return res.status(400).json({ error: 'payload 필드 필요' });
  }

  let payload;
  try {
    payload = JSON.parse(payloadStr);
  } catch (e) {
    return res.status(400).json({ error: `payload JSON 파싱 실패: ${e.message}` });
  }

  const scanJob      = payload.scan_job      || {};
  const scanReport   = payload.scan_report   || {};
  const filteredData = payload.filtered_data || {};

  // ── v17: JWT → user_id 추출 ──────────────────────────────────
  // Dash → scanner → Node 의 사슬을 통해 Authorization 헤더가 릴레이됨.
  // 토큰이 있고 유효하면 그 사용자의 uuid 를 모든 INSERT 의 user_id 컬럼에
  // 채워, 향후 GET /scan-results 등에서 RLS 정책이 본인 행만 반환하게 한다.
  // 토큰이 없거나 위조면 authUserId = null → RLS 적용 라우트에선 보이지 않음.
  const authToken = req.headers.authorization?.split(' ')[1];
  let authUserId = null;
  if (authToken) {
    try {
      // v24: auth.getUser() 는 인자 없이 호출하면 클라이언트의 auth 세션을 보고,
      // global.headers.Authorization 만 박은 우리 케이스에선 user = null 로 반환됨.
      // → JWT 를 명시적으로 인자로 박아 SDK 가 /auth/v1/user 호출 시 Authorization
      //   헤더로 정확히 사용하도록 강제. (v17~v23 줄곧 인자 누락으로 user_id 가
      //   가끔 NULL 로 적재되던 회귀의 진짜 원인)
      const userClient = getUserSupabase(authToken);
      const { data: { user }, error: authErr } = await userClient.auth.getUser(authToken);
      if (authErr) {
        console.warn('[Save] auth.getUser 실패:', authErr.message);
      } else if (user) {
        authUserId = user.id;
      }
    } catch (e) {
      console.warn('[Save] 토큰 검증 예외 (user_id 미적용 진행):', e.message);
    }
  }
  // v25: 토큰 없음/무효 시 INSERT 자체 거부 (NULL garbage 영구 차단).
  // v17~v24 까지는 NULL 적재를 허용해 RLS 가 가려주는 방식이었으나,
  // 디스크/DB 에 orphan 행이 쌓여 운영상 부담 → 인증 필수로 격상.
  // 다중 추출본이 동시 실행되는 케이스(과거 v17~v23 폴더가 살아 있는 등)
  // 에서 토큰 없이 호출되어도 모두 거부됨.
  if (!authUserId) {
    console.warn('[Save] Authorization 토큰 없음/무효 → 401 거부 (INSERT 진행 안 함)');
    return res.status(401).json({
      ok: false,
      error: '인증 토큰이 없거나 유효하지 않습니다. 다시 로그인 후 시도해 주세요.',
    });
  }
  console.log(`[Save] 인증된 사용자: ${authUserId}`);

  // job_id + 타임스탬프 — 동일 이미지 반복 분석 시에도 고유한 경로 보장
  const job_id    = uuidv4();
  const timestamp = makeTimestamp();
  const now       = new Date().toISOString();

  // ── 1. RAW 파일 디스크 저장 ──────────────────────────────────
  // uploads/{user_id}/{job_id}_{YYYYMMDD_HHMMSS}/grype.json 등
  // v17: 실제 인증된 uuid 가 있으면 그걸 쓰고, 없으면 기존 scanJob.user_id
  // ('admin' 등) 로 폴백. 디스크 경로 디렉토리명 충돌 방지 목적.
  const userId  = safeId(authUserId || scanJob.user_id);
  const dirName = `${job_id}_${timestamp}`;
  const scanDir = path.join(UPLOAD_BASE, userId, dirName);

  // 디렉터리 생성 (없으면 자동 생성)
  fs.mkdirSync(scanDir, { recursive: true });

  const savedFiles = [];
  for (const file of (req.files || [])) {
    const fname = path.basename(file.originalname); // 경로 인젝션 방지
    if (!RAW_FILES.has(fname)) continue;            // RAW 3종만 저장

    const dest = path.join(scanDir, fname);
    fs.writeFileSync(dest, file.buffer);
    savedFiles.push(fname);
    console.log(`[Save] RAW 저장: ${dest} (${(file.size / 1024).toFixed(1)} KB)`);
  }

  // DB에 기록할 상대 경로 (OS 구분자 → 슬래시 통일)
  const uploadPath = `${userId}/${dirName}`.replace(/\\/g, '/');

  // ── DB 작업 (동기 — 응답 전 완료 보장) ──────────────────────
  // 데이터 흐름 1단계: 정제 결과를 Supabase 에 모두 적재한 뒤 응답한다.
  // 동기 처리 이유: 대시보드가 스캔 직후 GET /results/:job_id 로 DB 를
  //   조회하므로, 적재 완료 전에 응답하면 레이스(빈 결과)가 발생한다.
  //   행 수백 개 INSERT 는 수초 내 완료되어 스캐너 타임아웃(180s) 내 안전.
  try {
    // ── 2. scan_jobs 레코드 생성 ──────────────────────────────
    const { error: jobErr } = await supabase.from('scan_jobs').insert({
      id:                    job_id,
      user_id:               authUserId,           // v17: JWT 의 uuid (없으면 NULL)
      scan_name:             scanJob.scan_name    || null,  // scanner.py 가 보내는 값 보존
      file_name:             scanJob.file_name    || '',
      file_type:             scanJob.file_type    || 'image_tar',
      image_name:            scanJob.image_name   || null,
      upload_path:           uploadPath,           // RAW 저장 경로 기록
      status:                'running',
      trivy_status:          scanJob.trivy_status || 'pending',
      grype_status:          scanJob.grype_status || 'pending',
      started_at:            scanJob.started_at   || now,
      total_vulnerabilities: 0,
      critical_count:        0,
      high_count:            0,
      medium_count:          0,
      low_count:             0,
      unknown_count:         0,
    });
    if (jobErr) {
      console.error('[Save] scan_jobs insert 실패:', jobErr.message);
      return res.status(500).json({
        ok: false, job_id, error: `scan_jobs insert 실패: ${jobErr.message}`,
      });
    }

    // ── 3. Trivy 취약점 → application_filtered ────────────────
    // ※ is_fixed_available: GENERATED ALWAYS (fixed_version IS NOT NULL) → INSERT 제외
    const trivyVulns = filteredData.trivy_vulnerabilities || [];
    if (trivyVulns.length > 0) {
      const rows = trivyVulns
        .filter(v => v.vulnerability_id && v.package_name)
        .map(v => ({
          scan_job_id:       job_id,
          user_id:           authUserId,           // v17: RLS 정책용
          // 실제 컬럼명은 'source' (이전 'scanner' 키는 PGRST204 차단)
          // CHECK 제약: 'trivy' 만 허용. v.source 가 'trivy' 가 아니면 fallback
          source:            v.source === 'trivy' ? v.source : 'trivy',
          target:            v.target            || null,
          result_class:      v.result_class      || null,
          result_type:       v.result_type       || null,
          vulnerability_id:  v.vulnerability_id,
          package_name:      v.package_name,
          package_path:      v.package_path      || null,
          installed_version: v.installed_version || null,
          fixed_version:     v.fixed_version     || null,
          severity:          v.severity          || 'UNKNOWN',  // CHECK: CRITICAL/HIGH/MEDIUM/LOW/UNKNOWN
          title:             v.title             || null,
          description:       v.description       || null,
          primary_url:       v.primary_url       || null,
        }));
      await insertChunked('application_filtered', rows);
    }

    // ── 4. Grype 취약점 → OS_filtered ────────────────────────────────
    // (2026-05 DB 리팩토링: grype_filtered 테이블이 OS_filtered 로 교체됨.
    //  기존 컬럼 동일 + `version` 컬럼 추가.)
    // ※ is_fixed_available: GENERATED ALWAYS (state = 'fixed') → INSERT 제외
    // ※ severity: CHECK 제약 없음 → UPPERCASE 그대로 사용
    const grypeVulns = filteredData.grype_vulnerabilities || [];
    if (grypeVulns.length > 0) {
      const rows = grypeVulns
        .filter(v => v.vulnerability_id && v.package_name)
        .map(v => ({
          scan_job_id:              job_id,
          user_id:                  authUserId,    // v17: RLS 정책용
          // 실제 컬럼명은 'source' (CHECK: 'grype' 만 허용)
          source:                   v.source === 'grype' ? v.source : 'grype',
          vulnerability_id:         v.vulnerability_id,
          data_source:              v.data_source              || null,
          severity:                 v.severity                 || 'UNKNOWN',
          description:              v.description              || null,
          fix_version:              v.fix_version              || null,
          state:                    v.state                    || null,
          risk:                     v.risk != null ? String(v.risk) : null,
          artifact_id:              v.artifact_id              || null,
          package_name:             v.package_name,
          package_type:             v.package_type             || null,
          install_path:             v.install_path             || null,
          related_vulnerability_id: v.related_vulnerability_id || null,
          version:                  v.version                  || null,   // OS_filtered 신규 컬럼
        }));
      await insertChunked('OS_filtered', rows);
    }

    // ── 5. 시크릿 → security_filtered ─────────────────────────
    const secrets = filteredData.secrets || [];
    if (secrets.length > 0) {
      const rows = secrets
        .filter(s => s.rule_id)
        .map(s => ({
          scan_job_id:  job_id,
          user_id:      authUserId,                // v17: RLS 정책용
          // 실제 컬럼명은 'source' (CHECK: 'trivy' 만)
          source:       s.source === 'trivy' ? s.source : 'trivy',
          rule_id:      s.rule_id,
          category:     s.category     || null,
          severity:     s.severity     || 'HIGH',  // CHECK 없음
          match_text:   s.match_text   || null,
          layer_digest: s.layer_digest || null,
          diff_id:      s.diff_id      || null,
          created_by:   s.created_by   || null,
        }));
      await insertChunked('security_filtered', rows);
    }

    // ── 6. 교차분석: Grype 단독 탐지 → grype_only ─────────────────────
    // (2026-05 DB 리팩토링 신규 테이블. scanner.py 의 filtered_data.grype_only
    //  는 OS_filtered 와 동일 스키마의 Grype 객체 리스트.)
    const grypeOnlyList = filteredData.grype_only || [];
    if (grypeOnlyList.length > 0) {
      const rows = grypeOnlyList
        .filter(v => v.vulnerability_id && v.package_name)
        .map(v => ({
          scan_job_id:              job_id,
          user_id:                  authUserId,    // v17: RLS 정책용
          source:                   v.source === 'grype' ? v.source : 'grype',
          vulnerability_id:         v.vulnerability_id,
          data_source:              v.data_source              || null,
          severity:                 v.severity                 || 'UNKNOWN',
          description:              v.description              || null,
          fix_version:              v.fix_version              || null,
          state:                    v.state                    || null,
          risk:                     v.risk != null ? String(v.risk) : null,
          artifact_id:              v.artifact_id              || null,
          package_name:             v.package_name,
          package_type:             v.package_type             || null,
          install_path:             v.install_path             || null,
          related_vulnerability_id: v.related_vulnerability_id || null,
          is_fixed_available:       !!v.is_fixed_available,
          version:                  v.version                  || null,
        }));
      await insertChunked('grype_only', rows);
    }

    // ── 7. 교차분석: Trivy 단독 탐지 → trivy_only ─────────────────────
    // (2026-05 DB 리팩토링 신규 테이블. scanner.py 의 filtered_data.trivy_only
    //  는 application_filtered 와 동일 스키마의 Trivy 객체 리스트.)
    const trivyOnlyList = filteredData.trivy_only || [];
    if (trivyOnlyList.length > 0) {
      const rows = trivyOnlyList
        .filter(v => v.vulnerability_id && v.package_name)
        .map(v => ({
          scan_job_id:        job_id,
          user_id:            authUserId,          // v17: RLS 정책용
          source:             v.source === 'trivy' ? v.source : 'trivy',
          target:             v.target            || null,
          result_class:       v.result_class      || null,
          result_type:        v.result_type       || null,
          vulnerability_id:   v.vulnerability_id,
          package_name:       v.package_name,
          package_path:       v.package_path      || null,
          installed_version:  v.installed_version || null,
          fixed_version:      v.fixed_version     || null,
          severity:           v.severity          || 'UNKNOWN',
          title:              v.title             || null,
          description:        v.description       || null,
          primary_url:        v.primary_url       || null,
          is_fixed_available: !!v.is_fixed_available,
        }));
      await insertChunked('trivy_only', rows);
    }

    // ── 8. 교차분석: 양도구 severity 불일치 → mismatch ────────────────
    // (2026-05 DB 리팩토링 신규 테이블, 28컬럼. scanner.py 의 mismatch[i] 구조:
    //   - 베이스: Grype 객체 전체 (vulnerability_id/package_name/version/risk/...)
    //   - entry.grype_severity / entry.trivy_severity : 양도구 severity 명시
    //   - entry.trivy_data : Trivy 객체 전체가 nested dict
    //  → mismatch 28 컬럼은 위 구조를 grype_* / trivy_* 접두사로 평탄화한 것.)
    const mismatchList = filteredData.mismatch || [];
    if (mismatchList.length > 0) {
      const rows = mismatchList
        .filter(m => m.vulnerability_id && m.package_name)
        .map(m => {
          const t = m.trivy_data || {};
          return {
            scan_job_id:              job_id,
            user_id:                  authUserId,  // v17: RLS 정책용
            // ── 공통 (Grype 베이스) ──
            vulnerability_id:         m.vulnerability_id,
            related_vulnerability_id: m.related_vulnerability_id || null,
            package_name:             m.package_name,
            package_type:             m.package_type             || null,
            version:                  m.version                  || null,
            artifact_id:              m.artifact_id              || null,
            install_path:             m.install_path             || null,
            description:              m.description              || null,
            is_fixed_available:       !!m.is_fixed_available,
            // ── 권장 심각도 (두 도구 중 높은 쪽, scanner.py 가 max 기준으로 산출) ──
            resolved_severity:        m.resolved_severity || null,
            // ── Grype 측 ──
            grype_severity:           m.grype_severity || m.severity || 'UNKNOWN',
            grype_risk:               m.risk != null ? String(m.risk) : null,
            grype_state:              m.state          || null,
            grype_fix_version:        m.fix_version    || null,
            grype_data_source:        m.data_source    || null,
            // ── Trivy 측 (trivy_data nested) ──
            trivy_severity:           m.trivy_severity || t.severity || 'UNKNOWN',
            trivy_target:             t.target            || null,
            trivy_result_class:       t.result_class      || null,
            trivy_result_type:        t.result_type       || null,
            trivy_package_path:       t.package_path      || null,
            trivy_installed_version:  t.installed_version || null,
            trivy_fixed_version:      t.fixed_version     || null,
            trivy_primary_url:        t.primary_url       || null,
            trivy_title:              t.title             || null,
          };
        });
      await insertChunked('mismatch', rows);
    }

    // ── 9. 교차분석 통계 → scan_reports ───────────────────────────────
    if (scanReport.total_count != null) {
      const { error: reportErr } = await supabase.from('scan_reports').insert({
        scan_jobs_id:   job_id,
        user_id:        authUserId,                // v17: RLS 정책용
        image_tag:      scanReport.image_tag      || scanJob.file_name || null,
        total_count:    scanReport.total_count    || 0,
        common_count:   scanReport.common_count   || 0,
        grype_only:     scanReport.grype_only     || 0,
        trivy_only:     scanReport.trivy_only     || 0,
        mismatch_count: scanReport.mismatch_count || 0,
        // 참고: scan_reports.scan_job_id 외래키는 실제로 비활성 (검증됨)
        //       scan_jobs_id 컬럼이 정상 작동하는 외래키이므로 그쪽만 사용
      });
      if (reportErr) console.warn('[Save] scan_reports insert 실패:', reportErr.message);
    }

    // ── 10. scan_jobs 카운트 + 상태 최종 업데이트 ────────────────────
    const { error: updErr } = await supabase.from('scan_jobs').update({
      status:                scanJob.status                || 'completed',
      total_vulnerabilities: scanJob.total_vulnerabilities || 0,
      critical_count:        scanJob.critical_count        || 0,
      high_count:            scanJob.high_count            || 0,
      medium_count:          scanJob.medium_count          || 0,
      low_count:             scanJob.low_count             || 0,
      unknown_count:         scanJob.unknown_count         || 0,
      finished_at:           scanJob.finished_at           || now,
      updated_at:            now,
    }).eq('id', job_id);
    if (updErr) console.warn('[Save] scan_jobs update 실패:', updErr.message);

    console.log(
      `[Save] DB 작업 완료 — job: ${job_id} | path: uploads/${uploadPath} | ` +
      `raw파일: [${savedFiles.join(', ')}] | ` +
      `OS(grype): ${grypeVulns.length} | app(trivy): ${trivyVulns.length} | secrets: ${secrets.length} | ` +
      `grype_only: ${grypeOnlyList.length} | trivy_only: ${trivyOnlyList.length} | mismatch: ${mismatchList.length}`
    );

    // ── 응답 — DB 적재 완료 후 스캐너에게 job_id 반환 ───────────
    // 스캐너는 이 job_id 를 대시보드로 전달하고, 대시보드는
    // GET /results/:job_id 로 방금 적재된 DB 데이터를 조회한다.
    res.status(201).json({
      ok:          true,
      job_id,
      upload_path: uploadPath,
      counts: {
        trivy:      trivyVulns.length,
        grype:      grypeVulns.length,
        secrets:    secrets.length,
        grype_only: grypeOnlyList.length,
        trivy_only: trivyOnlyList.length,
        mismatch:   mismatchList.length,
      },
      message: 'Files saved and DB populated.',
    });

  } catch (e) {
    console.error('[Save] 예외:', e.message);
    await supabase.from('scan_jobs').update({
      status:        'failed',
      error_message: e.message.slice(0, 500),
      updated_at:    now,
    }).eq('id', job_id).catch(() => {});
    res.status(500).json({ ok: false, job_id, error: e.message.slice(0, 500) });
  }
});

module.exports = router;
