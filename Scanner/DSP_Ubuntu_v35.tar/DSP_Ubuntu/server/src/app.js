const express = require('express');
const cors = require('cors');

const scanRouter        = require('./routes/scan');
const filesRouter       = require('./routes/files');
const saveRouter        = require('./routes/save');
const resultsRouter     = require('./routes/results');
const pdfRouter         = require('./routes/pdf');
const scanResultsRouter = require('./routes/scanResults');   // user-scoped grype_only 조회
const { ALLOWED_ORIGINS } = require('./config');

const app = express();

const isProd = process.env.NODE_ENV === 'production';

// ── CORS ──────────────────────────────────────────────────
// 프론트엔드는 Dash(:8050) 단독 — Node 는 API 전용 서버이다.
// (구 client/ 정적 HTML 프론트엔드는 폐기됨)
if (!isProd) {
  app.use(cors({
    origin: ALLOWED_ORIGINS,
    methods: ['GET', 'POST', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  }));
}

app.use(express.json());

// RAW 원시출력은 Supabase Storage(raw-scans 비공개 버킷)에 저장된다.
// 로컬 디스크 정적 제공(/files)은 폐기 — 다운로드는 /files-manage 의 signed URL 사용.

// ── 라우터 ────────────────────────────────────────────────
app.use('/scan',         scanRouter);
app.use('/save',         saveRouter);
app.use('/results',      resultsRouter);
app.use('/pdf',          pdfRouter);
app.use('/files-manage', filesRouter);
app.use('/scan-results', scanResultsRouter);   // RLS 적용 grype_only 조회 (Bearer 토큰 필수)

// ── 헬스체크 ──────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'DSP' });
});

// ── 404 핸들러 (API 전용) ────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: '요청한 경로를 찾을 수 없습니다.' });
});

// ── 글로벌 에러 핸들러 ────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('[Error]', err);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

module.exports = app;
