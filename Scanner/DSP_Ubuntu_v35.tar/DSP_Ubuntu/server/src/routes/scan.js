/**
 * 스캔 라우터 (조회 전용)
 *
 * GET  /scan/:jobId  → 잡 상태·결과 조회 (Supabase)
 * GET  /scan         → 최근 잡 목록
 *
 * ※ 스캔 실행은 python/scanner.py 가 담당합니다.
 *   scanner.py → /scan-dash → POST /save-scan 으로 결과가 저장됩니다.
 */

const express = require('express');
const supabase = require('../db/index');
const { STORAGE_RAW_BUCKET } = require('../config');
const repo = require('../db/scanRepository');

const router = express.Router();

// ── GET /scan/:jobId ──────────────────────────────────────
router.get('/:jobId', async (req, res, next) => {
  try {
    const { jobId } = req.params;

    let dbResult = null;
    try {
      dbResult = await repo.getJobWithResults(jobId);
    } catch (e) {
      console.warn('[Scan] DB 조회 실패:', e.message);
    }

    if (!dbResult) {
      return res.status(404).json({ error: `jobId를 찾을 수 없습니다: ${jobId}` });
    }

    const job = dbResult.job;
    const sr  = dbResult.scanReport;

    // RAW 원시출력 크기 조회 (Supabase Storage)
    let fileSize = null;
    let fileSizeLabel = null;
    if (job?.upload_path) {
      try {
        const { data: objects } = await supabase.storage
          .from(STORAGE_RAW_BUCKET)
          .list(job.upload_path);
        const total = (objects || []).reduce((sum, o) => sum + (o.metadata?.size || 0), 0);
        if (total > 0) {
          fileSize = total;
          const mb = total / (1024 ** 2);
          fileSizeLabel = mb >= 1024
            ? `${(mb / 1024).toFixed(2)} GB`
            : `${mb.toFixed(1)} MB`;
        }
      } catch { /* 조회 실패 시 null */ }
    }

    return res.json({
      jobId,
      status:        job?.status    || 'unknown',
      fileName:      job?.file_name || null,
      imageName:     job?.image_name || null,
      fileType:      job?.file_type  || null,
      fileUrl:       job?.upload_path ? `/files-manage/${jobId}` : null,
      fileSize,
      fileSizeLabel,
      createdAt:     job?.created_at  || null,
      updatedAt:     job?.updated_at  || null,
      startedAt:     job?.started_at  || null,
      finishedAt:    job?.finished_at || null,
      summary: {
        total:    job?.total_vulnerabilities || 0,
        critical: job?.critical_count        || 0,
        high:     job?.high_count            || 0,
        medium:   job?.medium_count          || 0,
        low:      job?.low_count             || 0,
        unknown:  job?.unknown_count         || 0,
      },
      trivy: {
        total:   dbResult.applicationFiltered.length,
        results: dbResult.applicationFiltered,
      },
      grype: {
        total:   dbResult.grypeFiltered.length,
        results: dbResult.grypeFiltered,
      },
      security: dbResult.securityFiltered,
      logs:     dbResult.logs,
      crossAnalysis: sr ? {
        totalCount:     sr.total_count    || 0,
        commonCount:    sr.common_count   || 0,
        grypeOnlyCount: sr.grype_only     || 0,
        trivyOnlyCount: sr.trivy_only     || 0,
        mismatchCount:  sr.mismatch_count || 0,
      } : null,
    });
  } catch (err) {
    next(err);
  }
});

// ── GET /scan ─────────────────────────────────────────────
router.get('/', async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit) || 20;
    const jobs  = await repo.listJobs(limit);
    return res.json(jobs);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
