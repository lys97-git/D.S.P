/**
 * 파일 관리 라우터 (RAW 원시출력 — Supabase Storage)
 *
 * GET    /files-manage         → 저장된 RAW 목록 (DB + Storage 오브젝트 크기)
 * GET    /files-manage/:jobId  → 특정 잡의 RAW 정보 + 다운로드용 signed URL
 * DELETE /files-manage/:jobId  → 특정 잡의 RAW 삭제 (Storage + DB upload_path 초기화)
 *
 * RAW(grype.json/trivy.json)는 raw-scans 비공개 버킷의
 *   {user_id}/{job_id}_{timestamp}/  프리픽스 아래에 저장된다.
 * (구버전은 로컬 디스크 server/uploads 에 저장했으나 Storage 로 이전됨)
 */

const express  = require('express');
const supabase = require('../db/index');
const { STORAGE_RAW_BUCKET } = require('../config');

const router = express.Router();
const SIGNED_URL_TTL = 3600; // 1시간

/** 바이트 → 사람이 읽기 쉬운 문자열 */
function formatSize(bytes) {
  if (bytes == null) return null;
  if (bytes < 1024)      return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 ** 3) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
}

/** Storage 프리픽스 아래 오브젝트 목록 + 총 크기 */
async function listRawObjects(prefix) {
  if (!prefix) return { exists: false, files: [], totalBytes: 0 };
  const { data, error } = await supabase.storage.from(STORAGE_RAW_BUCKET).list(prefix);
  if (error || !data || data.length === 0) {
    return { exists: false, files: [], totalBytes: 0 };
  }
  const files = data
    .filter(o => o.name)
    .map(o => ({ name: o.name, size: o.metadata?.size ?? null, sizeLabel: formatSize(o.metadata?.size) }));
  const totalBytes = files.reduce((sum, f) => sum + (f.size || 0), 0);
  return { exists: files.length > 0, files, totalBytes };
}

// ── GET /files-manage ─────────────────────────────────────
router.get('/', async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit) || 50;

    const { data: jobs, error } = await supabase
      .from('scan_jobs')
      .select('id, file_name, upload_path, status, created_at, finished_at')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) return res.status(500).json({ error: error.message });

    const files = [];
    let totalBytes = 0;
    for (const job of (jobs || [])) {
      const info = await listRawObjects(job.upload_path);
      totalBytes += info.totalBytes;
      files.push({
        jobId:      job.id,
        fileName:   job.file_name,
        uploadPath: job.upload_path,
        status:     job.status,
        createdAt:  job.created_at,
        finishedAt: job.finished_at,
        bucket:     STORAGE_RAW_BUCKET,
        rawFiles:   info.files,
        sizeLabel:  formatSize(info.totalBytes),
        exists:     info.exists,
      });
    }

    return res.json({
      count:     files.length,
      totalSize: formatSize(totalBytes),
      totalBytes,
      files,
    });
  } catch (err) {
    next(err);
  }
});

// ── GET /files-manage/:jobId ──────────────────────────────
router.get('/:jobId', async (req, res, next) => {
  try {
    const { jobId } = req.params;

    const { data: job, error } = await supabase
      .from('scan_jobs')
      .select('id, file_name, upload_path, status, created_at, finished_at')
      .eq('id', jobId)
      .single();

    if (error || !job) return res.status(404).json({ error: '잡을 찾을 수 없습니다.' });

    const info = await listRawObjects(job.upload_path);

    // 각 RAW 파일에 대해 다운로드용 signed URL 발급 (비공개 버킷)
    const downloads = [];
    for (const f of info.files) {
      const objectPath = `${job.upload_path}/${f.name}`;
      const { data: urlData } = await supabase.storage
        .from(STORAGE_RAW_BUCKET)
        .createSignedUrl(objectPath, SIGNED_URL_TTL, { download: f.name });
      downloads.push({ name: f.name, sizeLabel: f.sizeLabel, url: urlData?.signedUrl || null });
    }

    return res.json({
      jobId:      job.id,
      fileName:   job.file_name,
      uploadPath: job.upload_path,
      status:     job.status,
      createdAt:  job.created_at,
      finishedAt: job.finished_at,
      bucket:     STORAGE_RAW_BUCKET,
      exists:     info.exists,
      sizeLabel:  formatSize(info.totalBytes),
      downloads,
    });
  } catch (err) {
    next(err);
  }
});

// ── DELETE /files-manage/:jobId ───────────────────────────
router.delete('/:jobId', async (req, res, next) => {
  try {
    const { jobId } = req.params;

    const { data: job, error: fetchErr } = await supabase
      .from('scan_jobs')
      .select('id, file_name, upload_path')
      .eq('id', jobId)
      .single();

    if (fetchErr || !job) return res.status(404).json({ error: '잡을 찾을 수 없습니다.' });
    if (!job.upload_path)  return res.status(404).json({ error: '저장된 파일이 없습니다.' });

    const info = await listRawObjects(job.upload_path);

    let deleted = false;
    if (info.files.length > 0) {
      const paths = info.files.map(f => `${job.upload_path}/${f.name}`);
      const { error: rmErr } = await supabase.storage.from(STORAGE_RAW_BUCKET).remove(paths);
      if (rmErr) throw new Error(`Storage 삭제 실패: ${rmErr.message}`);
      deleted = true;
    }

    // DB upload_path 초기화 (행/통계는 유지)
    await supabase.from('scan_jobs').update({ upload_path: null }).eq('id', jobId);

    return res.json({
      jobId,
      fileName: job.file_name,
      deleted,
      message: deleted ? 'RAW 파일이 삭제되었습니다.' : '저장된 RAW 파일이 없었습니다.',
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
