import asyncio
import json
import os
import subprocess
import tempfile
import threading
import time
import uuid
import shlex
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, FastAPI, File, Form, UploadFile, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
import paramiko

try:
    import docker
except ImportError:
    docker = None


SUSPICIOUS_COMMANDS = ["curl", "wget", "bash", "sh", "nc", "ncat", "python", "perl", "chmod", "chown"]
SUSPICIOUS_LOG_WORDS = ["error", "denied", "failed", "unauthorized", "forbidden", "critical", "exploit"]
RESTART_THRESHOLD = 3

router = APIRouter(prefix="/dynamic-api", tags=["dynamic-analysis"])


class RunRequest(BaseModel):
    image: str
    name: str = ""


class ActionRequest(BaseModel):
    name: str
    action: str


class ExecRequest(BaseModel):
    name: str
    command: str


class SharedTerminalSession:
    def __init__(self):
        self.connect_lock = asyncio.Lock()
        self.io_lock = threading.Lock()
        self.clients: set[WebSocket] = set()
        self.ssh_client = None
        self.ssh_channel = None
        self.reader_task: Optional[asyncio.Task] = None
        self.recent_output = deque(maxlen=160)
        self.password = (os.environ.get("DYNAMIC_VM_PASSWORD") or "").strip()
        self.cols = 120
        self.rows = 32
        self.pending_command = ""

    def is_connected(self):
        return self.ssh_client is not None and self.ssh_channel is not None and not self.ssh_channel.closed

    async def ensure_connected(self, websocket: Optional[WebSocket] = None):
        if self.is_connected():
            return False

        async with self.connect_lock:
            if self.is_connected():
                return False

            vm_config = _vm_terminal_config()
            password = self.password
            cols = self.cols
            rows = self.rows

            while True:
                if not password:
                    if websocket is None:
                        raise RuntimeError("No VM password is configured on the server.")
                    prompt = (
                        f"[DSP Dynamic Terminal] SSH login required.\r\n"
                        f"{vm_config['user']}@{vm_config['host']}'s password: "
                    )
                    password, cols, rows = await _receive_terminal_auth(websocket, prompt)

                try:
                    ssh_client, ssh_channel, banner_text = await asyncio.to_thread(
                        _connect_vm_shell,
                        password,
                        cols,
                        rows,
                    )
                    break
                except paramiko.AuthenticationException:
                    self.password = ""
                    if websocket is None:
                        raise
                    await websocket.send_bytes(
                        b"\r\n[DSP Dynamic Terminal] SSH authentication failed. Please try again.\r\n"
                    )
                    password = ""

            self.password = password
            self.ssh_client = ssh_client
            self.ssh_channel = ssh_channel
            self.cols = cols
            self.rows = rows
            self.recent_output.clear()
            self.recent_output.append(banner_text.encode("utf-8", errors="replace"))
            self.reader_task = asyncio.create_task(self._pump_output())
            return True

    async def register_client(self, websocket: WebSocket):
        self.clients.add(websocket)
        snapshot = b"".join(self.recent_output)
        if snapshot:
            await websocket.send_bytes(snapshot)

    async def remove_client(self, websocket: WebSocket):
        self.clients.discard(websocket)

    async def broadcast(self, payload: bytes):
        dead_clients = []
        for client in list(self.clients):
            try:
                await client.send_bytes(payload)
            except Exception:
                dead_clients.append(client)
        for client in dead_clients:
            self.clients.discard(client)

    def _write_text(self, text: str):
        with self.io_lock:
            if self.ssh_channel is not None and not self.ssh_channel.closed:
                self.ssh_channel.send(text)

    async def write(self, raw_bytes: bytes):
        if not raw_bytes or not self.is_connected():
            return
        decoded = raw_bytes.decode("utf-8", errors="ignore")
        for command in self._consume_commands(decoded):
            STATE.handle_terminal_command(command)
        await asyncio.to_thread(self._write_text, decoded)

    def _consume_commands(self, text: str):
        commands = []
        for char in text:
            if char in ("\r", "\n"):
                command = self.pending_command.strip()
                if command:
                    commands.append(command)
                self.pending_command = ""
                continue

            if char in ("\x08", "\x7f"):
                if self.pending_command:
                    self.pending_command = self.pending_command[:-1]
                continue

            if char.isprintable():
                self.pending_command += char

        return commands

    def _resize_pty(self, cols: int, rows: int):
        with self.io_lock:
            if self.ssh_channel is not None and not self.ssh_channel.closed:
                self.ssh_channel.resize_pty(width=cols, height=rows)

    async def resize(self, cols: int, rows: int):
        self.cols = max(40, int(cols or self.cols))
        self.rows = max(12, int(rows or self.rows))
        if not self.is_connected():
            return
        await asyncio.to_thread(self._resize_pty, self.cols, self.rows)

    async def close_session(self, reason: str = ""):
        task = self.reader_task
        channel = self.ssh_channel
        client = self.ssh_client
        clients = list(self.clients)

        self.reader_task = None
        self.ssh_channel = None
        self.ssh_client = None
        self.clients = set()

        if task is not None and task is not asyncio.current_task() and not task.done():
            task.cancel()

        if reason:
            payload = f"\r\n[DSP Dynamic Terminal] {reason}\r\n".encode("utf-8", errors="replace")
            self.recent_output.append(payload)
            await self.broadcast(payload)

        try:
            if channel is not None:
                await asyncio.to_thread(channel.close)
        except Exception:
            pass
        try:
            if client is not None:
                await asyncio.to_thread(client.close)
        except Exception:
            pass
        for websocket in clients:
            try:
                await websocket.close()
            except Exception:
                pass

    async def _pump_output(self):
        try:
            while self.is_connected():
                if self.ssh_channel.recv_ready():
                    chunk = await asyncio.to_thread(self.ssh_channel.recv, 4096)
                    if not chunk:
                        break
                    self.recent_output.append(chunk)
                    await self.broadcast(chunk)
                    continue
                if self.ssh_channel.exit_status_ready() or self.ssh_channel.closed:
                    break
                await asyncio.sleep(0.05)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            await self.close_session(f"Shared VM terminal error: {exc}")
            return

        await self.close_session("Shared VM terminal disconnected.")


class DynamicBackendState:
    def __init__(self):
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.docker_client = None
        self.listener_started = False
        self.listener_lock = threading.Lock()
        self.alert_clients: list[WebSocket] = []
        self.restart_counter = defaultdict(int)
        self.log_watchers = set()
        self.shared_terminal = SharedTerminalSession()
        self.upload_dir = Path(os.environ.get("DYNAMIC_UPLOAD_DIR", Path(tempfile.gettempdir()) / "dsp_dynamic_uploads"))
        self.upload_dir.mkdir(parents=True, exist_ok=True)

    def is_remote_docker_mode(self):
        return _vm_terminal_config()["enabled"]

    def ensure_docker_client(self):
        if self.docker_client is not None:
            return self.docker_client
        if docker is None:
            return None
        try:
            client = docker.from_env()
            client.ping()
            self.docker_client = client
        except Exception as exc:
            print(f"[dynamic] Docker connection failed: {exc}")
            self.docker_client = None
        return self.docker_client

    def ensure_background_threads(self):
        if self.loop is None:
            return
        with self.listener_lock:
            if self.listener_started:
                return
            if self.is_remote_docker_mode():
                threading.Thread(target=self._remote_docker_event_listener, daemon=True).start()
                self.listener_started = True
                print("[dynamic] Remote Docker event listener scheduled.")
                return

            client = self.ensure_docker_client()
            if client is None:
                return
            threading.Thread(target=self._docker_event_listener, daemon=True).start()
            for container in client.containers.list(all=True):
                self.ensure_log_watch(container.name)
            self.listener_started = True
            print("[dynamic] Background listeners started.")

    def ensure_log_watch(self, container_name: str):
        if not container_name or container_name in self.log_watchers:
            return
        self.log_watchers.add(container_name)
        threading.Thread(target=self._watch_logs, args=(container_name,), daemon=True).start()

    def schedule_alert(self, event_type: str, container: str, extra: Optional[dict] = None):
        if self.loop is None:
            return
        future = asyncio.run_coroutine_threadsafe(
            _send_alert(event_type, container, extra or {}),
            self.loop,
        )
        try:
            future.result(timeout=0)
        except Exception:
            pass

    def handle_terminal_command(self, command: str):
        command = (command or "").strip()
        if not command:
            return

        lower = command.lower()
        matched = [cmd for cmd in SUSPICIOUS_COMMANDS if cmd in lower]

        if lower.startswith("docker "):
            self.schedule_alert("docker_command", "terminal", {"command": command})
            return

        if matched:
            self.schedule_alert("terminal_command", "terminal", {"command": command})

    def _docker_event_listener(self):
        client = self.ensure_docker_client()
        if client is None:
            return
        print("[dynamic] Docker event listener started.")
        try:
            for event in client.events(decode=True):
                action_raw = event.get("Action", "")
                actor = event.get("Actor", {})
                attrs = actor.get("Attributes", {})
                container = attrs.get("name") or actor.get("ID", "unknown")[:12]
                extra = {}

                if action_raw.startswith("exec_start"):
                    action = "exec_start"
                    extra["command"] = action_raw.replace("exec_start:", "").strip()
                elif action_raw == "die":
                    action = "die"
                    extra["exit_code"] = attrs.get("exitCode", "0")
                elif action_raw == "start":
                    action = "start"
                    self.ensure_log_watch(container)
                elif action_raw == "restart":
                    action = "restart"
                    self.ensure_log_watch(container)
                else:
                    action = action_raw

                if action in {"start", "exec_start", "die", "restart"}:
                    self.schedule_alert(action, container, extra)
        except Exception as exc:
            print(f"[dynamic] Docker event listener stopped: {exc}")

    def _watch_logs(self, container_name: str):
        client = self.ensure_docker_client()
        if client is None:
            return
        try:
            container = client.containers.get(container_name)
            for line in container.logs(stream=True, follow=True, tail=0):
                log_line = line.decode("utf-8", errors="replace").strip()
                if any(keyword in log_line.lower() for keyword in SUSPICIOUS_LOG_WORDS):
                    self.schedule_alert("log_alert", container_name, {"log_line": log_line})
        except Exception as exc:
            print(f"[dynamic] Log watch ended for {container_name}: {exc}")
        finally:
            self.log_watchers.discard(container_name)

    def _remote_docker_event_listener(self):
        print("[dynamic] Remote Docker event listener started.")
        while True:
            if self.loop is None:
                time.sleep(1)
                continue

            password = (self.shared_terminal.password or "").strip()
            if not password:
                time.sleep(1)
                continue

            client = None
            stdout = None
            stderr = None
            try:
                client = _connect_vm_client(password=password)
                _, stdout, stderr = client.exec_command(
                    _remote_bash_command("docker events --format '{{json .}}'"),
                    get_pty=False,
                )

                while True:
                    raw_line = stdout.readline()
                    if not raw_line:
                        break

                    line = raw_line.strip()
                    if not line:
                        continue

                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    action_raw = event.get("Action", "")
                    actor = event.get("Actor", {}) or {}
                    attrs = actor.get("Attributes", {}) or {}
                    container = attrs.get("name") or actor.get("ID", "unknown")[:12]
                    extra = {}

                    if action_raw.startswith("exec_start"):
                        extra["command"] = attrs.get("exec.command") or attrs.get("command") or ""
                        action = "exec_start"
                    elif action_raw == "die":
                        extra["exit_code"] = attrs.get("exitCode", "0")
                        action = "die"
                    elif action_raw == "start":
                        action = "start"
                    elif action_raw == "restart":
                        action = "restart"
                    else:
                        action = action_raw

                    if action in {"start", "exec_start", "die", "restart"}:
                        self.schedule_alert(action, container, extra)

                err_output = stderr.read().decode("utf-8", errors="replace").strip() if stderr is not None else ""
                if err_output:
                    print(f"[dynamic] Remote Docker event listener stderr: {err_output[:300]}")
            except Exception as exc:
                print(f"[dynamic] Remote Docker event listener stopped: {exc}")
            finally:
                try:
                    if stdout is not None:
                        stdout.channel.close()
                except Exception:
                    pass
                try:
                    if stderr is not None:
                        stderr.channel.close()
                except Exception:
                    pass
                try:
                    if client is not None:
                        client.close()
                except Exception:
                    pass

            time.sleep(2)


STATE = DynamicBackendState()


def _require_vm_password():
    password = (STATE.shared_terminal.password or os.environ.get("DYNAMIC_VM_PASSWORD") or "").strip()
    if not password:
        raise RuntimeError("SSH password is not available yet. Connect the VM terminal first.")
    return password


def _connect_vm_client(password: Optional[str] = None):
    config = _vm_terminal_config()
    if not config["enabled"]:
        raise RuntimeError("VM terminal is not configured.")

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=config["host"],
        port=config["port"],
        username=config["user"],
        password=password or _require_vm_password(),
        look_for_keys=False,
        allow_agent=False,
        timeout=15,
        banner_timeout=15,
        auth_timeout=15,
    )
    transport = client.get_transport()
    if transport:
        transport.set_keepalive(30)
    return client


def _run_remote_command(command: str, timeout: int = 30):
    client = _connect_vm_client()
    try:
        _, stdout, stderr = client.exec_command(
            _remote_bash_command(command),
            timeout=timeout,
            get_pty=False,
        )
        exit_code = stdout.channel.recv_exit_status()
        output = stdout.read().decode("utf-8", errors="replace")
        error = stderr.read().decode("utf-8", errors="replace")
        return exit_code, output, error
    finally:
        client.close()


def _normalize_container_status(status_text: str):
    text = (status_text or "").strip().lower()
    if text.startswith("up"):
        return "running"
    if text.startswith("exited"):
        return "exited"
    if text.startswith("created"):
        return "created"
    if text.startswith("restarting"):
        return "restarting"
    return text or "unknown"


def _list_remote_containers():
    exit_code, output, error = _run_remote_command("docker ps -a --format '{{json .}}'", timeout=30)
    if exit_code != 0:
        raise RuntimeError(error.strip() or output.strip() or "docker ps failed")

    containers = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue

        status_text = item.get("Status", "")
        containers.append(
            {
                "id": (item.get("ID", "") or "")[:12],
                "name": item.get("Names", "") or "",
                "image": item.get("Image", "") or "",
                "status": _normalize_container_status(status_text),
                "status_text": status_text,
            }
        )

    return containers


def _analyze_event(event_type: str, container: str, extra: dict):
    if event_type in {"exec_start", "terminal_command", "docker_command"}:
        command = extra.get("command", "").lower()
        matched = [cmd for cmd in SUSPICIOUS_COMMANDS if cmd in command]
        if matched:
            return {
                "risk": "HIGH",
                "rule": f"Suspicious command detected: {', '.join(matched)}",
                "detail": f"[{container}] {command or '(empty command)'}",
            }
        if event_type == "docker_command":
            return {
                "risk": "LOW",
                "rule": "Docker command observed in terminal",
                "detail": f"[{container}] {command or '(empty command)'}",
            }
        return {
            "risk": "MEDIUM",
            "rule": "Terminal command observed",
            "detail": f"[{container}] {command or '(empty command)'}",
        }
    if event_type == "restart":
        STATE.restart_counter[container] += 1
        count = STATE.restart_counter[container]
        if count >= RESTART_THRESHOLD:
            return {
                "risk": "HIGH",
                "rule": f"Repeated restart detected ({count})",
                "detail": f"[{container}] restarted {count} times",
            }
        return {
            "risk": "MEDIUM",
            "rule": f"Restart detected ({count}/{RESTART_THRESHOLD})",
            "detail": f"[{container}] restart event",
        }
    if event_type == "die":
        exit_code = str(extra.get("exit_code", "0"))
        if exit_code != "0":
            return {
                "risk": "MEDIUM",
                "rule": f"Container exited abnormally (code {exit_code})",
                "detail": f"[{container}] abnormal exit",
            }
        return {
            "risk": "LOW",
            "rule": "Container exited normally",
            "detail": f"[{container}] normal exit",
        }
    if event_type == "log_alert":
        log_line = extra.get("log_line", "")
        matched = [keyword for keyword in SUSPICIOUS_LOG_WORDS if keyword in log_line.lower()]
        return {
            "risk": "MEDIUM",
            "rule": f"Suspicious log detected: {', '.join(matched)}",
            "detail": f"[{container}] {log_line[:160]}",
        }
    return {
        "risk": "LOW",
        "rule": f"Container event: {event_type}",
        "detail": f"[{container}] {event_type}",
    }


async def _broadcast(payload: dict):
    dead_clients = []
    for client in list(STATE.alert_clients):
        try:
            await client.send_json(payload)
        except Exception:
            dead_clients.append(client)
    for client in dead_clients:
        if client in STATE.alert_clients:
            STATE.alert_clients.remove(client)


async def _send_alert(event_type: str, container: str, extra: dict):
    analysis = _analyze_event(event_type, container, extra)
    payload = {
        "type": "alert",
        "event_type": event_type,
        "container": container,
        "extra": extra,
        "analysis": analysis,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    await _broadcast(payload)
    print(f"[dynamic][{analysis['risk']}] {analysis['rule']} | {container}")


def _docker_unavailable_response():
    if STATE.is_remote_docker_mode():
        return {"ok": False, "message": "Docker is not connected on the VM yet. Connect the VM terminal first."}
    return {"ok": False, "message": "Docker is not connected on this host."}


def _remote_bash_command(command: str):
    escaped = command.replace("'", r"'\''")
    return f"bash -lc '{escaped}'"


def _vm_terminal_config():
    # DYNAMIC_MODE 로 실행 대상을 명시적으로 고른다.
    #   local  → VM(SSH) 무시. 이 PC 의 Docker Desktop + 로컬 cmd.exe 터미널 사용.
    #   remote → 아래 VM 정보로 SSH (담당자 환경).
    #   (미설정) → 기존 동작: vm_host·vm_user 가 있으면 원격으로 간주.
    mode = os.environ.get("DYNAMIC_MODE", "").strip().lower()
    vm_host = os.environ.get("DYNAMIC_VM_HOST", "192.168.25.132").strip()
    vm_user = os.environ.get("DYNAMIC_VM_USER", "pro").strip()
    vm_port = int((os.environ.get("DYNAMIC_VM_PORT", "22") or "22").strip())
    vm_init_command = os.environ.get("DYNAMIC_VM_INIT_COMMAND", "").strip()
    if mode == "local":
        enabled = False
    else:
        enabled = bool(vm_host and vm_user)
    return {
        "enabled": enabled,
        "host": vm_host,
        "user": vm_user,
        "port": vm_port,
        "init_command": vm_init_command,
    }


def _local_terminal_command():
    if os.name == "nt":
        command = [os.environ.get("COMSPEC", "cmd.exe"), "/Q", "/K"]
    else:
        command = [os.environ.get("SHELL", "/bin/bash"), "-i"]
    banner = f"[DSP Dynamic Terminal] Connected to local shell: {' '.join(shlex.quote(part) for part in command)}\r\n"
    return command, banner


def attach_dynamic_backend(app: FastAPI):
    if getattr(app.state, "dynamic_backend_attached", False):
        return

    @app.on_event("startup")
    async def _dynamic_backend_startup():
        STATE.loop = asyncio.get_running_loop()
        STATE.ensure_background_threads()

    app.include_router(router)
    app.state.dynamic_backend_attached = True


async def _receive_terminal_auth(websocket: WebSocket, prompt: str):
    password = ""
    cols = 120
    rows = 32
    await websocket.send_bytes(prompt.encode("utf-8", errors="replace"))

    while True:
        try:
            message = await asyncio.wait_for(websocket.receive(), timeout=120)
        except asyncio.TimeoutError as exc:
            raise RuntimeError("SSH authentication timed out before the password was entered.") from exc

        if message.get("type") == "websocket.disconnect":
            raise WebSocketDisconnect()

        raw_bytes = message.get("bytes")
        text = message.get("text")
        chunk = ""

        if raw_bytes is not None:
            chunk = raw_bytes.decode("utf-8", errors="ignore")
        elif text is not None:
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                chunk = text
            else:
                if not isinstance(payload, dict):
                    chunk = text
                    payload = None
                if payload is None:
                    pass
                elif payload.get("type") == "resize":
                    cols = int(payload.get("cols", cols))
                    rows = int(payload.get("rows", rows))
                    continue
                elif payload.get("type") == "auth":
                    password = str(payload.get("password", ""))
                    if password:
                        await websocket.send_bytes(b"\r\n")
                        return password, cols, rows
                    continue
                else:
                    continue

        for char in chunk:
            if char in ("\r", "\n"):
                await websocket.send_bytes(b"\r\n")
                if password:
                    return password, cols, rows
                await websocket.send_bytes(
                    b"[DSP Dynamic Terminal] Empty password. Try again.\r\n"
                )
                await websocket.send_bytes(prompt.encode("utf-8", errors="replace"))
                break

            if char in ("\x08", "\x7f"):
                if password:
                    password = password[:-1]
                    await websocket.send_bytes(b"\b \b")
                continue

            if char == "\x03":
                raise RuntimeError("SSH authentication cancelled.")

            if char.isprintable():
                password += char
                await websocket.send_bytes(b"*")


def _connect_vm_shell(password: str, cols: int = 120, rows: int = 32):
    config = _vm_terminal_config()
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(
        hostname=config["host"],
        port=config["port"],
        username=config["user"],
        password=password,
        look_for_keys=False,
        allow_agent=False,
        timeout=15,
        banner_timeout=15,
        auth_timeout=15,
    )
    transport = client.get_transport()
    if transport:
        transport.set_keepalive(30)

    channel = client.invoke_shell(term="xterm", width=cols, height=rows)
    banner = (
        f"[DSP Dynamic Terminal] Connected to Ubuntu VM {config['user']}@{config['host']}:{config['port']}\r\n"
    )
    if config["init_command"]:
        channel.send(config["init_command"] + "\n")
        banner += f"[DSP Dynamic Terminal] Remote bootstrap: {config['init_command']}\r\n"
    return client, channel, banner


@router.websocket("/ws")
async def alert_ws(websocket: WebSocket):
    await websocket.accept()
    STATE.alert_clients.append(websocket)
    await websocket.send_json(
        {
            "type": "connected",
            "message": "Dynamic alert stream connected",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    )
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in STATE.alert_clients:
            STATE.alert_clients.remove(websocket)


@router.websocket("/ws/terminal")
async def terminal_ws(websocket: WebSocket):
    await websocket.accept()
    vm_config = _vm_terminal_config()

    if vm_config["enabled"]:
        try:
            await STATE.shared_terminal.ensure_connected(websocket)
            STATE.ensure_background_threads()
            await STATE.shared_terminal.register_client(websocket)

            while True:
                message = await websocket.receive()
                if message.get("type") == "websocket.disconnect":
                    break

                raw_bytes = message.get("bytes")
                if raw_bytes is None:
                    text = message.get("text", "")
                    try:
                        payload = json.loads(text)
                        if isinstance(payload, dict) and payload.get("type") == "resize":
                            cols = int(payload.get("cols", STATE.shared_terminal.cols))
                            rows = int(payload.get("rows", STATE.shared_terminal.rows))
                            await STATE.shared_terminal.resize(cols, rows)
                            continue
                        raw_bytes = text.encode("utf-8", errors="ignore")
                    except json.JSONDecodeError:
                        raw_bytes = text.encode("utf-8", errors="ignore")

                if raw_bytes:
                    await STATE.shared_terminal.write(raw_bytes)
        except WebSocketDisconnect:
            pass
        except paramiko.AuthenticationException:
            await websocket.send_bytes(b"[DSP Dynamic Terminal] SSH authentication failed.\r\n")
        except Exception as exc:
            await websocket.send_bytes(f"[DSP Dynamic Terminal] {exc}\r\n".encode("utf-8", errors="replace"))
        finally:
            await STATE.shared_terminal.remove_client(websocket)
            try:
                await websocket.close()
            except Exception:
                pass
        return

    command, banner_text = _local_terminal_command()
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    process = await asyncio.create_subprocess_exec(
        *command,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        creationflags=creationflags,
    )
    banner = banner_text.encode("utf-8", errors="replace")
    await websocket.send_bytes(banner)

    async def _stdout_to_ws():
        while True:
            chunk = await process.stdout.read(1024)
            if not chunk:
                break
            await websocket.send_bytes(chunk)

    async def _ws_to_stdin():
        while True:
            message = await websocket.receive()
            if message.get("type") == "websocket.disconnect":
                break

            raw_bytes = message.get("bytes")
            if raw_bytes is None:
                text = message.get("text", "")
                try:
                    payload = json.loads(text)
                    if isinstance(payload, dict) and payload.get("type") == "resize":
                        continue
                    raw_bytes = text.encode("utf-8", errors="ignore")
                except json.JSONDecodeError:
                    raw_bytes = text.encode("utf-8", errors="ignore")

            if raw_bytes:
                process.stdin.write(raw_bytes)
                await process.stdin.drain()

    try:
        await asyncio.gather(_stdout_to_ws(), _ws_to_stdin())
    except WebSocketDisconnect:
        pass
    finally:
        try:
            if process.returncode is None:
                process.terminate()
                await asyncio.wait_for(process.wait(), timeout=2)
        except Exception:
            if process.returncode is None:
                process.kill()
        await websocket.close()


@router.get("/containers")
async def list_containers():
    STATE.ensure_background_threads()
    if STATE.is_remote_docker_mode():
        try:
            return {"containers": _list_remote_containers()}
        except Exception:
            return {"containers": []}

    client = STATE.ensure_docker_client()
    if client is None:
        return {"containers": []}

    containers = []
    for container in client.containers.list(all=True):
        image = container.image.tags[0] if container.image.tags else container.image.short_id
        containers.append(
            {
                "id": container.short_id,
                "name": container.name,
                "image": image,
                "status": container.status,
            }
        )
    return {"containers": containers}


@router.post("/images/upload")
async def upload_image(file: UploadFile = File(...), memo: str = Form("")):
    del memo
    if not file.filename.lower().endswith(".tar"):
        return {"ok": False, "message": "Only .tar files can be uploaded."}

    unique_name = f"{uuid.uuid4()}_{Path(file.filename).name}"
    save_path = STATE.upload_dir / unique_name
    try:
        with save_path.open("wb") as handle:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                handle.write(chunk)

        if STATE.is_remote_docker_mode():
            remote_name = f"/tmp/{unique_name}"
            client = _connect_vm_client()
            try:
                sftp = client.open_sftp()
                try:
                    sftp.put(str(save_path), remote_name)
                finally:
                    sftp.close()

                _, stdout, stderr = client.exec_command(
                    _remote_bash_command(f"docker load -i {shlex.quote(remote_name)}"),
                    timeout=300,
                    get_pty=False,
                )
                exit_code = stdout.channel.recv_exit_status()
                output = stdout.read().decode("utf-8", errors="replace")
                error = stderr.read().decode("utf-8", errors="replace")
                if exit_code != 0:
                    return {"ok": False, "message": f"docker load failed: {(error or output)[:240]}"}
            finally:
                try:
                    _run_remote_command(f"rm -f {shlex.quote(remote_name)}", timeout=30)
                except Exception:
                    pass
                try:
                    client.close()
                except Exception:
                    pass

            image_name = Path(file.filename).stem
            for line in output.splitlines():
                if "Loaded image:" in line:
                    image_name = line.split("Loaded image:", 1)[1].strip()
                    break

            STATE.schedule_alert("docker_command", "terminal", {"command": f"docker load -i {Path(file.filename).name}"})
            return {"ok": True, "message": f"Image loaded: {image_name}", "image_name": image_name}

        client = STATE.ensure_docker_client()
        if client is None:
            return _docker_unavailable_response()

        result = subprocess.run(
            ["docker", "load", "-i", str(save_path)],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode != 0:
            return {"ok": False, "message": f"docker load failed: {result.stderr[:240]}"}

        image_name = Path(file.filename).stem
        for line in result.stdout.splitlines():
            if "Loaded image:" in line:
                image_name = line.split("Loaded image:", 1)[1].strip()
                break

        return {"ok": True, "message": f"Image loaded: {image_name}", "image_name": image_name}
    except subprocess.TimeoutExpired:
        return {"ok": False, "message": "docker load timed out after 300 seconds."}
    except Exception as exc:
        return {"ok": False, "message": str(exc)}
    finally:
        if save_path.exists():
            save_path.unlink(missing_ok=True)


@router.post("/containers/run")
async def run_container(request: RunRequest):
    STATE.ensure_background_threads()
    if STATE.is_remote_docker_mode():
        name = request.name.strip()
        secure_cmd = [
            "docker", "run", "-d",
            "--network", "none",
            "--memory", "256m",
            "--cpu-period", "100000",
            "--cpu-quota", "50000",
            "--security-opt", "no-new-privileges:true",
            "--cap-drop", "ALL",
            "--pids-limit", "100",
        ]
        if name:
            secure_cmd.extend(["--name", name])
        secure_cmd.append(request.image)

        exit_code, output, error = _run_remote_command(" ".join(shlex.quote(part) for part in secure_cmd), timeout=120)
        fallback_used = False
        if exit_code != 0:
            fallback_cmd = ["docker", "run", "-d"]
            if name:
                fallback_cmd.extend(["--name", name])
            fallback_cmd.append(request.image)
            exit_code, output, error = _run_remote_command(" ".join(shlex.quote(part) for part in fallback_cmd), timeout=120)
            fallback_used = True
            if exit_code != 0:
                return {"ok": False, "message": (error or output).strip() or "docker run failed"}

        container_id = (output.strip().splitlines() or [""])[-1].strip()
        resolve_cmd = f"docker ps -a --filter id={shlex.quote(container_id)} --format '{{{{.Names}}}}'"
        _, name_output, _ = _run_remote_command(resolve_cmd, timeout=30)
        resolved_name = (name_output.strip().splitlines() or [container_id[:12]])[-1].strip() or container_id[:12]
        message = f"Container started: {resolved_name}"
        if fallback_used:
            message += " (fallback mode)"
        return {"ok": True, "message": message, "name": resolved_name}

    client = STATE.ensure_docker_client()
    if client is None:
        return _docker_unavailable_response()

    name = request.name.strip() or None
    secure_run_kwargs = {
        "detach": True,
        "name": name,
        "network_mode": "none",
        "mem_limit": "256m",
        "cpu_period": 100000,
        "cpu_quota": 50000,
        "security_opt": ["no-new-privileges:true"],
        "cap_drop": ["ALL"],
        "pids_limit": 100,
    }

    try:
        container = client.containers.run(request.image, **secure_run_kwargs)
        fallback_used = False
    except Exception as secure_exc:
        try:
            container = client.containers.run(request.image, detach=True, name=name)
            fallback_used = True
            print(f"[dynamic] Secure run options failed, fallback used: {secure_exc}")
        except Exception as exc:
            return {"ok": False, "message": str(exc)}

    STATE.ensure_log_watch(container.name)
    message = f"Container started: {container.name}"
    if fallback_used:
        message += " (fallback mode)"
    return {"ok": True, "message": message, "name": container.name}


@router.post("/containers/action")
async def container_action(request: ActionRequest):
    STATE.ensure_background_threads()
    if STATE.is_remote_docker_mode():
        commands = {
            "start": f"docker start {shlex.quote(request.name)}",
            "stop": f"docker stop {shlex.quote(request.name)}",
            "restart": f"docker restart {shlex.quote(request.name)}",
            "remove": f"docker rm -f {shlex.quote(request.name)}",
        }
        command = commands.get(request.action)
        if not command:
            return {"ok": False, "message": f"Unsupported action: {request.action}"}
        exit_code, output, error = _run_remote_command(command, timeout=120)
        if exit_code != 0:
            return {"ok": False, "message": (error or output).strip() or f"{request.action} failed"}
        return {"ok": True, "message": f"{request.action} completed: {request.name}"}

    client = STATE.ensure_docker_client()
    if client is None:
        return _docker_unavailable_response()

    try:
        container = client.containers.get(request.name)
        if request.action == "start":
            container.start()
            STATE.ensure_log_watch(container.name)
        elif request.action == "stop":
            container.stop()
        elif request.action == "restart":
            container.restart()
            STATE.ensure_log_watch(container.name)
        elif request.action == "remove":
            container.remove(force=True)
        else:
            return {"ok": False, "message": f"Unsupported action: {request.action}"}
        return {"ok": True, "message": f"{request.action} completed: {request.name}"}
    except Exception as exc:
        return {"ok": False, "message": str(exc)}


@router.post("/containers/exec")
async def container_exec(request: ExecRequest):
    STATE.ensure_background_threads()
    if STATE.is_remote_docker_mode():
        command = f"docker exec {shlex.quote(request.name)} sh -lc {shlex.quote(request.command)}"
        exit_code, output, error = _run_remote_command(command, timeout=120)
        if exit_code != 0:
            return {"ok": False, "output": (error or output).strip() or "docker exec failed"}
        return {"ok": True, "output": output or "(no output)"}

    client = STATE.ensure_docker_client()
    if client is None:
        return {"ok": False, "output": "Docker is not connected on this host."}

    try:
        container = client.containers.get(request.name)
        result = container.exec_run(request.command, demux=False)
        output = result.output.decode("utf-8", errors="replace") if result.output else "(no output)"
        return {"ok": True, "output": output}
    except Exception as exc:
        return {"ok": False, "output": str(exc)}


@router.get("/health")
async def health():
    STATE.ensure_background_threads()
    if STATE.is_remote_docker_mode():
        try:
            containers = _list_remote_containers()
            return {
                "status": "ok",
                "docker": True,
                "connections": len(STATE.alert_clients),
                "containers": [container["name"] for container in containers],
                "mode": "remote-vm",
            }
        except Exception as exc:
            return {
                "status": "degraded",
                "docker": False,
                "connections": len(STATE.alert_clients),
                "containers": [],
                "mode": "remote-vm",
                "message": str(exc),
            }

    client = STATE.ensure_docker_client()
    if client is None:
        return {"status": "degraded", "docker": False, "connections": len(STATE.alert_clients), "containers": []}

    return {
        "status": "ok",
        "docker": True,
        "connections": len(STATE.alert_clients),
        "containers": [container.name for container in client.containers.list(all=True)],
    }
