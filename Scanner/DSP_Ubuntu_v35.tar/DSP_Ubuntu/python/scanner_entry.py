import os

from fastapi.middleware.cors import CORSMiddleware

try:
    from .scanner import app as base_app
    from .dynamic_backend import attach_dynamic_backend
except ImportError:
    from scanner import app as base_app
    from dynamic_backend import attach_dynamic_backend


app = base_app

_allowed_origins = [
    origin.strip()
    for origin in os.environ.get(
        "PYTHON_ALLOWED_ORIGINS",
        "http://localhost:8050,http://127.0.0.1:8050,http://localhost:3000,http://127.0.0.1:3000",
    ).split(",")
    if origin.strip()
]

if not getattr(app.state, "dynamic_cors_configured", False):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_allowed_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.state.dynamic_cors_configured = True

attach_dynamic_backend(app)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host=os.environ.get("PYTHON_HOST", "0.0.0.0"),
        port=int(os.environ.get("PYTHON_PORT", "8000")),
    )
