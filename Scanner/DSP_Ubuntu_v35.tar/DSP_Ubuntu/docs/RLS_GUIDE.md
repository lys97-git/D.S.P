# DSP — Row Level Security (RLS) 적용 가이드

`v16` 에서 신규 추가된 **user-scoped Supabase 클라이언트 (`getUserSupabase`)** 와
**`/scan-results`** 라우트가 의도대로 동작하려면 DB 측 4가지 사전 작업이 필요합니다.

이 작업이 누락되면 모든 사용자가 **빈 결과**를 받습니다 (RLS 가 anon 권한을 차단).

---

## 0. 현재 구조 요약

| 라우트 | 사용 클라이언트 | RLS | 비고 |
|---|---|---|---|
| `/scan` (POST) | service_role | 우회 | 스캐너 호출 후 결과 적재 |
| `/save` (POST) | service_role | 우회 | 스캐너→Node 적재 트리거 |
| `/results/:job_id` | service_role | 우회 | 기존 대시보드용 (회귀 방지를 위해 유지) |
| `/pdf` (POST) | service_role | 우회 | PDF 생성·캐시 |
| **`/scan-results`** | **anon + 사용자 JWT** | **적용** | **신규 — 본인 데이터만** |

→ 점진적 마이그레이션. 신규 라우트만 RLS 를 활성화하고, 기존 라우트는 회귀 위험을 피해 그대로 둡니다.

---

## 1. (DB) `grype_only` 테이블에 `user_id` 컬럼 추가

```sql
ALTER TABLE public.grype_only
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

-- 기존 행을 누구의 것으로 둘지 결정. 운영중이 아니라면 NULL 유지 또는 삭제.
-- 데모용 테스트 데이터는 본인 user_id 로 backfill:
-- UPDATE public.grype_only SET user_id = '<your-uuid>' WHERE user_id IS NULL;

-- 빠른 조회를 위한 인덱스
CREATE INDEX IF NOT EXISTS idx_grype_only_user_id
  ON public.grype_only (user_id);
```

> ⚠ 동일 작업을 `application_filtered`, `OS_filtered`, `security_filtered`,
> `trivy_only`, `mismatch`, `scan_jobs`, `scan_reports` 에도 적용해야
> 향후 모든 라우트를 RLS 로 전환할 수 있습니다. 이번 v16 에서는 `grype_only`
> 만 시범 적용합니다.

---

## 2. (DB) RLS Enable + 정책 생성

```sql
-- RLS 활성화
ALTER TABLE public.grype_only ENABLE ROW LEVEL SECURITY;

-- 본인 행만 SELECT
CREATE POLICY "own_rows_select" ON public.grype_only
  FOR SELECT
  USING (auth.uid() = user_id);

-- (선택) INSERT 도 본인만 — save.js 가 service_role 을 쓰므로 지금은 불필요
-- CREATE POLICY "own_rows_insert" ON public.grype_only
--   FOR INSERT
--   WITH CHECK (auth.uid() = user_id);
```

확인:
```sql
SELECT schemaname, tablename, rowsecurity, forcerowsecurity
  FROM pg_tables
 WHERE tablename = 'grype_only';
-- rowsecurity 가 t (true) 여야 함
```

---

## 3. (서버) `save.js` 가 `user_id` 채워 INSERT 하도록 수정 — TODO

현재 `save.js` 는 service_role 로 모든 컬럼을 무필터 INSERT 합니다.
사용자 격리를 완성하려면 INSERT 시 `user_id` 를 채워야 합니다.

대략적인 흐름 (구현 미반영):

```js
// save.js 안에서
const token = req.headers.authorization?.split(' ')[1];
let userId = null;
if (token) {
  const { data: { user } } = await getUserSupabase(token).auth.getUser();
  userId = user?.id || null;
}

// grype_only INSERT 시 user_id 컬럼 추가
await supabase.from('grype_only').insert(rows.map(r => ({ ...r, user_id: userId })));
```

→ 본 가이드의 1·2 단계만 끝내도 신규 데이터에 `user_id` 만 채워 넣으면
`/scan-results` 가 기대대로 동작합니다.

---

## 4. (프런트) 호출 시 Authorization 헤더 첨부 — TODO

`front_end_v11_7.py` 의 `requests.post / get` 들은 현재 토큰을 보내지 않습니다.
RLS 를 사용하려면 다음 패턴이 필요합니다.

```python
# (예시) 헤더에서 localStorage 의 sb-*-auth-token 을 추출해 전송
# Dash 의 callback context 로는 localStorage 접근이 안 되므로
# clientside_callback 으로 토큰을 store 에 미리 떠 놓고 사용:

app.clientside_callback(
    """
    function(pathname) {
        const keys = Object.keys(window.localStorage)
            .filter(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
        for (const k of keys) {
            try {
                const v = JSON.parse(window.localStorage.getItem(k));
                if (v && v.access_token) return v.access_token;
            } catch (e) {}
        }
        return '';
    }
    """,
    Output("auth-token-store", "data"),
    Input("url", "pathname")
)
```

그리고 서버사이드 callback 에서 `State("auth-token-store", "data")` 로 토큰을 받아:

```python
resp = requests.get(
    "http://127.0.0.1:3000/scan-results",
    headers={"Authorization": f"Bearer {token}"} if token else {},
    timeout=60,
)
```

---

## 5. 동작 테스트

1. Supabase 콘솔에 로그인된 계정으로 대시보드 진입 (`/login` 통과)
2. 스캔 1건 수행 → `save.js` 가 적재
3. 단계 1·2 완료 상태에서 단계 3 미완이면 데이터에 `user_id` 가 NULL → 정책 차단 → 0건
4. SQL Editor 에서 본인 UUID 로 backfill 후 재호출 → 본인 행만 반환되는지 확인:
   ```bash
   curl -H "Authorization: Bearer <JWT>" http://localhost:3000/scan-results
   ```
5. 토큰 없이 호출 → 401
6. 만료/위조 토큰으로 호출 → 0건 (RLS 가 차단)

---

## 6. 롤백

문제 발생 시:
```sql
ALTER TABLE public.grype_only DISABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own_rows_select" ON public.grype_only;
```
→ 기존 라우트는 모두 service_role 이라 영향 없음.
