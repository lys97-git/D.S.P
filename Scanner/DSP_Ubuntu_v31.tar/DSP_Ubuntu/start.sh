#!/bin/bash
# ============================================================
# DSP 서비스 시작 (Ubuntu) — 간편 시작 스크립트
# 전체 설치/점검이 필요하면 ./run.sh 사용 권장
# 실행: chmod +x start.sh && ./start.sh
# ============================================================
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVER_DIR="$ROOT_DIR/server"
LOG_DIR="$ROOT_DIR/logs"
PID_DIR="$ROOT_DIR/.pids"

mkdir -p "$LOG_DIR" "$PID_DIR"

SCANNER_WORK="$ROOT_DIR/python/.work"
mkdir -p "$SCANNER_WORK"

# ── Python 스캐너 (port 8000) ────────────────────────────────
if lsof -i:8000 -t >/dev/null 2>&1; then
    echo "[start] Python 스캐너 이미 실행 중 (port 8000) ✓"
else
    echo "[start] Python 스캐너 시작 중..."
    cd "$ROOT_DIR"
    SCANNER_WORK_DIR="$SCANNER_WORK" PYTHONUTF8=1 PYTHONIOENCODING=utf-8 \
        nohup python3 -m uvicorn python.scanner:app \
        --host 0.0.0.0 --port 8000 \
        > "$LOG_DIR/scanner.log" 2>&1 &
    echo $! > "$PID_DIR/scanner.pid"
    echo "[start] Python 스캐너 PID: $(cat $PID_DIR/scanner.pid) ✓"
fi

# ── Node.js API 서버 (port 3000) ─────────────────────────────
if lsof -i:3000 -t >/dev/null 2>&1; then
    echo "[start] Node.js 서버 이미 실행 중 (port 3000) ✓"
else
    echo "[start] Node.js API 서버 시작 중..."
    cd "$SERVER_DIR"
    nohup npm start > "$LOG_DIR/node.log" 2>&1 &
    echo $! > "$PID_DIR/node.pid"
    echo "[start] Node.js 서버 PID: $(cat $PID_DIR/node.pid) ✓"
fi

# ── Dash 대시보드 (port 8050) ─────────────────────────────────
if lsof -i:8050 -t >/dev/null 2>&1; then
    echo "[start] Dash 대시보드 이미 실행 중 (port 8050) ✓"
else
    echo "[start] Dash 대시보드 시작 중..."
    cd "$ROOT_DIR"
    nohup python3 frontend/front_end_v11_4.py \
        > "$LOG_DIR/dash.log" 2>&1 &
    echo $! > "$PID_DIR/dash.pid"
    echo "[start] Dash 대시보드 PID: $(cat $PID_DIR/dash.pid) ✓"
fi

echo ""
echo "✅ DSP 시작 완료"
echo "   대시보드   → http://localhost:8050"
echo "   로그인     → http://localhost:8050/login  (미인증 시 자동 redirect)"
echo "   API        → http://localhost:3000/health"
echo "   스캐너     → http://localhost:8000/health"
echo "   로그       → $LOG_DIR/"
echo "   종료       → ./stop.sh  또는  ./run.sh stop"

# 대시보드 자동 오픈 (헤드리스 환경에선 조용히 실패)
sleep 2
if command -v xdg-open >/dev/null 2>&1; then
    ( xdg-open "http://localhost:8050" >/dev/null 2>&1 & )
elif command -v sensible-browser >/dev/null 2>&1; then
    ( sensible-browser "http://localhost:8050" >/dev/null 2>&1 & )
fi
