﻿# ================================================================
#  DSP  통합 실행 스크립트  (run.ps1)
#  run.bat -> PowerShell 실행 -> 이 파일이 관리자 권한 자체 처리
#
#  STEP 1  포트 정리
#  STEP 2  기술스택 설치 / 확인
#  STEP 3  서비스 시작  (Python 8000 / Node.js 3000 / Dash 8050)
#  STEP 4  자가점검  (도구 . 서버 . 파일 전체 확인)
#  STEP 5  실행 모드 선택
#           [1] 터미널 유지 (모니터링)
#           [2] 백그라운드 실행 (이 창만 닫기)
#           [3] 모든 서비스 종료
# ================================================================

# -- 관리자 권한 자가 확인 및 재실행 ----------------------------
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal   = New-Object Security.Principal.WindowsPrincipal($currentUser)
$isAdmin     = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "  관리자 권한으로 재실행합니다. UAC 창을 수락하세요..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# -- 전역 설정 --------------------------------------------------
$ErrorActionPreference = "SilentlyContinue"
try { $HOST.UI.RawUI.WindowTitle = "DSP 통합 실행기" } catch {}

# -- 콘솔 출력 인코딩을 UTF-8 로 통일 --------------------------
# 한국어 Windows 의 기본 codepage(CP949) 와 외부 도구의 출력 인코딩이 어긋나
# 콘솔에 깨진 글자(?댄벽? 같은) 가 나오는 cosmetic 이슈 방지.
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    [Console]::InputEncoding  = [System.Text.Encoding]::UTF8
    chcp 65001 > $null 2>&1
} catch {}

# -- cmd 콘솔 "빠른 편집 모드(QuickEdit)" 비활성화 ----------------
# QuickEdit 가 켜져 있으면 사용자가 서비스 cmd 창을 클릭하는 순간
# 콘솔 출력이 멈추고(선택 모드), 그 콘솔에 로그를 쓰는 프로세스
# (특히 Dash/Flask dev server)가 통째로 hang 됩니다.
# → 서비스 창을 띄우기 전에 QuickEdit 를 꺼서 클릭해도 멈추지 않게 합니다.
#   (HKCU\Console 는 이후 새로 생성되는 콘솔의 기본값)
reg add "HKCU\Console" /v QuickEdit /t REG_DWORD /d 0 /f 2>$null | Out-Null

$ROOT  = Split-Path -Parent $MyInvocation.MyCommand.Path
$TOOLS = Join-Path $ROOT "tools"
if (-not (Test-Path $TOOLS)) { New-Item -ItemType Directory -Path $TOOLS | Out-Null }
$env:PATH = "$TOOLS;$env:PATH"

# ── (v14) GTK runtime PATH 무조건 보정 ──────────────────────────
# Test-WeasyPrint 가 통과해 GTK 설치 블록이 스킵되는 경우,
# Update-PathFromRegistry 가 호출되지 않아 자식(scanner) 프로세스가
# GTK 를 못 찾아 weasyprint 가 import 시점에 libgobject 못 찾고
# 죽는 시나리오 차단. 디스크에 GTK bin 디렉터리가 존재하면
# 무조건 $env:PATH 에 prepend → 자식 프로세스가 상속.
foreach ($_gtkBin in @(
    "C:\Program Files\GTK3-Runtime Win64\bin",
    "C:\Program Files (x86)\GTK3-Runtime Win64\bin",
    "$env:LOCALAPPDATA\Programs\GTK3-Runtime Win64\bin"
)) {
    if ((Test-Path $_gtkBin) -and ($env:PATH -notlike "*$_gtkBin*")) {
        $env:PATH = "$_gtkBin;$env:PATH"
    }
}

# ── (v14) 로그 디렉터리 생성 (서비스 stdout/stderr 캡처용) ──────
$LOG_DIR = Join-Path $ROOT "logs"
if (-not (Test-Path $LOG_DIR)) { New-Item -ItemType Directory -Path $LOG_DIR | Out-Null }

# -- 컬러 출력 헬퍼 ---------------------------------------------
function cw  { param($t, $c = "White");  Write-Host $t -ForegroundColor $c }
function ok  { param($label); cw "  |  [OK] $label" Green  }
function ng  { param($label); cw "  |  [NG] $label  <- 확인 필요" Red    }
function inf  { param($label); cw "  |       $label"  Gray   }
function war  { param($label); cw "  |  [!!] $label"  Yellow }
# v23: 정보성 알림(설치 진행 등) 전용 — [!!] 위협 톤이 아닌 [..] 중립 톤.
function note { param($label); cw "  |  [..] $label"  Cyan   }

# v26: 한글 = 2칸, ASCII = 1칸 시각 폭 계산 + 박스 줄 자동 정렬.
# cmd 콘솔에서 한글 글자가 ASCII 박스 정렬을 깨뜨리는 회귀 차단.
function Get-VisualWidth {
    param([string]$s)
    $w = 0
    foreach ($c in $s.ToCharArray()) {
        $cp = [int][char]$c
        if (($cp -ge 0x1100 -and $cp -le 0x115F) -or `
            ($cp -ge 0x2E80 -and $cp -le 0x9FFF) -or `
            ($cp -ge 0xAC00 -and $cp -le 0xD7A3) -or `
            ($cp -ge 0xF900 -and $cp -le 0xFAFF) -or `
            ($cp -ge 0xFE30 -and $cp -le 0xFE4F) -or `
            ($cp -ge 0xFF00 -and $cp -le 0xFF60)) {
            $w += 2
        } else {
            $w += 1
        }
    }
    return $w
}

function Format-BoxLine {
    param([string]$text, [int]$innerWidth)
    $w = Get-VisualWidth $text
    $pad = $innerWidth - $w
    if ($pad -lt 0) { $pad = 0 }
    return "|$text$(' ' * $pad)|"
}

function Show-Banner {
    Clear-Host
    $W = 66   # 박스 내부 폭 (| 와 | 사이)
    $bar = '+' + ('=' * $W) + '+'
    cw ""
    cw "  $bar" Cyan
    cw "  $(Format-BoxLine '        DSP  통합 실행기  [관리자 모드]' $W)" Cyan
    cw "  $(Format-BoxLine '     Python(8000)  .  Node.js(3000)  .  Dash(8050)' $W)" Cyan
    cw "  $bar" Cyan
    cw ""
}

# -- TCP 포트 응답 확인 ------------------------------------------
function Test-Port {
    param([int]$port)
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $tcp.BeginConnect("127.0.0.1", $port, $null, $null)
        $ok = $ar.AsyncWaitHandle.WaitOne(800, $false)
        if ($ok) { try { $tcp.EndConnect($ar) } catch {} }
        $tcp.Close()
        return $ok
    } catch { return $false }
}

# -- 포트 점유 프로세스 종료 ------------------------------------
function Stop-Port {
    param([int]$port)
    netstat -ano 2>$null |
        Select-String "\s:$port\s" |
        ForEach-Object {
            if ($_.Line -match '\s(\d+)\s*$') {
                $p = [int]$Matches[1]
                if ($p -gt 4) { Stop-Process -Id $p -Force -ErrorAction SilentlyContinue }
            }
        }
}

# -- 환경 변수 PATH를 레지스트리에서 다시 읽어와 현재 세션에 반영 ----
# winget / msi 설치 후 PATH 가 현재 PowerShell 세션에 즉시 반영되지 않으므로
# Machine + User PATH를 명시적으로 재로딩합니다.
function Update-PathFromRegistry {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath    = [Environment]::GetEnvironmentVariable("Path", "User")
    $combined = @($TOOLS)
    if ($machinePath) { $combined += $machinePath.Split(';') | Where-Object { $_ } }
    if ($userPath)    { $combined += $userPath.Split(';')    | Where-Object { $_ } }
    $env:PATH = ($combined -join ';')
}

# -- Python 실행파일 절대 경로 탐지 ---------------------------------
# python.exe 가 PATH 우선순위에 따라 Windows Store 스텁(앱 실행 별칭)으로
# 잡히는 흔한 함정을 회피하고, 실제 설치된 인터프리터를 찾아 반환합니다.
function Resolve-PythonExe {
    # 1) py 런처 (Python 공식 인스톨러가 설치하는 안정된 진입점)
    $pyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        $exe = & py.exe -3 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $exe -and (Test-Path $exe.Trim())) {
            return $exe.Trim()
        }
    }
    # 2) PATH 의 python.exe (Windows Store 스텁 제외)
    $cmd = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notmatch 'WindowsApps') {
        $exe = & $cmd.Source -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $exe -and (Test-Path $exe.Trim())) {
            return $exe.Trim()
        }
    }
    # 3) 표준 설치 경로 후보 (machine / user 스코프 둘 다)
    $candidates = @(
        "C:\Program Files\Python313\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        "C:\Program Files (x86)\Python313\python.exe",
        "C:\Program Files (x86)\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe"
    )
    foreach ($p in $candidates) {
        if (Test-Path $p) { return $p }
    }
    return $null
}

# -- Node.js 실행파일 절대 경로 탐지 ---------------------------------
function Resolve-NodeExe {
    $cmd = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @(
        "C:\Program Files\nodejs\node.exe",
        "C:\Program Files (x86)\nodejs\node.exe",
        "$env:LOCALAPPDATA\Programs\nodejs\node.exe"
    )
    foreach ($p in $candidates) {
        if (Test-Path $p) { return $p }
    }
    return $null
}

# -- npm 명령 경로 탐지 (.cmd) --------------------------------------
function Resolve-NpmCmd {
    $cmd = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $node = Resolve-NodeExe
    if ($node) {
        $dir = Split-Path -Parent $node
        $npm = Join-Path $dir "npm.cmd"
        if (Test-Path $npm) { return $npm }
    }
    return $null
}

# -- 서비스 시작 (임시 bat 방식 - 인용 부호 충돌 방지) ----------
# 띄운 cmd 의 PID 를 $script:ServicePids 에 저장 -> Stop-AllServices 에서 종료
$script:ServicePids = @()

# -- 경로의 8.3 short name 변환 (유니코드/공백 회피용) --------------
# cmd.exe 가 한글/공백/특수문자가 포함된 경로를 다룰 때 가장 안전한 형태입니다.
# NTFS 의 8dot3 생성이 비활성화된 경우에는 원본 경로를 그대로 반환합니다.
function Get-ShortPath {
    param([string]$path)
    if (-not (Test-Path $path)) { return $path }
    try {
        $fso = New-Object -ComObject Scripting.FileSystemObject
        $item = Get-Item -LiteralPath $path -ErrorAction Stop
        if ($item.PSIsContainer) {
            $short = $fso.GetFolder($path).ShortPath
        } else {
            $short = $fso.GetFile($path).ShortPath
        }
        if ($short -and $short -notmatch '^\s*$') { return $short }
    } catch {}
    return $path
}

function Start-Service {
    param(
        [string]$title,
        [string]$workDir,
        [string]$cmd,
        [hashtable]$envVars = @{}
    )

    # ── 작업 디렉터리(cwd) 처리 ──────────────────────────────────────
    # [핵심] cmd 의 `cd /d` 를 .bat 안에서 쓰지 않습니다.
    #   - 한글 경로를 .bat 에 적으면 chcp 65001 후 인코딩이 어긋나
    #     "지정된 경로를 찾을 수 없습니다" 가 발생했습니다.
    #   - 대신 Start-Process 의 -WorkingDirectory 로 cwd 를 지정합니다.
    #     PowerShell 이 유니코드 경로를 정확히 cmd 프로세스에 전달합니다.

    # ── 환경 변수: 현재 PowerShell 프로세스에 설정 → 자식 cmd 가 상속 ──
    #   (.bat 의 `set` 줄로 한글 값을 쓰던 방식 폐기 — 인코딩 안전)
    foreach ($k in $envVars.Keys) {
        Set-Item -Path "env:$k" -Value $envVars[$k] -ErrorAction SilentlyContinue
    }
    $env:PYTHONUTF8        = "1"
    $env:PYTHONIOENCODING  = "utf-8"
    $env:PYTHONUNBUFFERED  = "1"   # v9_2: PowerShell Tee 파이프와 결합 시 실시간 라인 출력 보장
    # PATH 는 run.ps1 메인에서 이미 $TOOLS 를 prepend 했고 자식이 상속함

    # ── .bat 본문 ────────────────────────────────────────────────────
    # (v14) 변경 2건:
    #   ① set PATH=...  — 부모(PowerShell)의 $env:PATH 를 .bat 안에 명시적으로
    #      박아 자식 cmd 가 확실히 동일 PATH 로 실행되도록 보장 (PATH 누락 안전망).
    #   ② (v9_2/v20 변경) cmd 창 + 파일 동시 출력 — `> $logFile 2>&1` 로 cmd
    #      창이 비어 있던 v14 동작을 PowerShell Tee-Object 파이프로 교체.
    #      `<cmd> 2>&1 | powershell ... Tee-Object` 구조로 cmd 창에 실시간
    #      출력 + logs\<title>.log 파일에도 동시 기록.
    #      ※ v20 핫픽스: Windows PowerShell 5.1 의 `Tee-Object` 는 `-Encoding`
    #         파라미터를 지원하지 않음 (PowerShell 7+ 에서만 추가됨). v19 의
    #         `-Encoding utf8` 로 모든 서비스가 ParameterBindingException 으로
    #         즉사하던 회귀를 해당 파라미터 제거로 해결. 인코딩은 자식
    #         프로세스 출력 측에서 보장 ([Console]::OutputEncoding = UTF8 +
    #         PYTHONIOENCODING=utf-8).
    #      PYTHONUNBUFFERED=1 로 python 서비스(Scanner/Dash)의 라인 버퍼링 끔.
    $tmp = Join-Path $env:TEMP "$title.bat"
    $logFile = Join-Path $LOG_DIR "$title.log"

    # PATH 값에 `&`, `^`, `>` 같은 cmd 특수문자가 있으면 escape 필요.
    # 일반적인 PATH 엔 잘 안 나오지만 만약 있으면 cmd 가 죽으니 안전망.
    $pathSafe = $env:PATH -replace '\^','^^' -replace '&','^&' -replace '\|','^|' -replace '<','^<' -replace '>','^>'

    # PowerShell single-quoted 안에서 single-quote 는 '' 로 escape (logFile 경로 안전망)
    $logFileForPs = $logFile -replace "'", "''"

    # PowerShell 명령 본문: Console 인코딩 UTF-8 강제 + 입력 파이프를 Tee-Object 로
    # 화면(stdout) + 파일 동시 출력. `-Encoding` 없이도 OutputEncoding 강제로
    # 한글 한글 처리. Tee-Object 기본 인코딩(UTF-16 LE with BOM)으로 파일 저장됨.
    $psBody = "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; `$input | Tee-Object -FilePath '$logFileForPs'"

    $lines = @(
        '@echo off',
        'chcp 65001 > nul',
        "title $title",
        "set PATH=$pathSafe",
        "$cmd 2>&1 | powershell -NoProfile -Command `"$psBody`""
    )
    $body = ($lines -join "`r`n") + "`r`n"

    # 본문이 ASCII 라 인코딩 무관하지만 UTF-8(BOM 없음)으로 통일
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($tmp, $body, $utf8NoBom)

    $tmpShort = Get-ShortPath $tmp

    # -WorkingDirectory 로 cwd 지정 (cmd 의 cd 불필요, 유니코드 경로 안전)
    $proc = Start-Process "cmd.exe" -ArgumentList "/k", "`"$tmpShort`"" `
        -WorkingDirectory $workDir -WindowStyle Normal -PassThru
    if ($proc) { $script:ServicePids += $proc.Id }
}

# ================================================================
#  STEP 1  포트 정리
# ================================================================
function Invoke-PortCleanup {
    cw "  +-- STEP 1/3  포트 정리 ----------------------------------------" DarkGray
    inf "기존 node / python 프로세스 종료..."
    # v23: Stop-Process 에도 -ErrorAction SilentlyContinue 추가.
    # 부족했을 때 권한 거부/이미 종료 등의 케이스에서 PowerShell 이 confirm
    # 프롬프트로 멈춰서 STEP 1 이 사용자 엔터까지 무한 대기하던 회귀 차단.
    Get-Process -Name "node"   -ErrorAction SilentlyContinue |
        Stop-Process -Force -ErrorAction SilentlyContinue
    Get-Process -Name "python" -ErrorAction SilentlyContinue |
        Stop-Process -Force -ErrorAction SilentlyContinue
    foreach ($p in @(3000, 8000, 8050)) { Stop-Port $p }
    Start-Sleep -Milliseconds 800
    inf "포트 3000 / 8000 / 8050 해제 완료"
    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  STEP 2  기술스택 설치 / 확인
# ================================================================
function Invoke-StackSetup {
    cw "  +-- STEP 2/3  기술스택 설치 / 확인 ----------------------------" DarkGray

    $useWinget = $null -ne (Get-Command winget -ErrorAction SilentlyContinue)
    if (-not $useWinget) {
        war "[winget]   없음 - MSI 직다운로드 폴백 사용"
    }

    # ── Node.js 설치 ──────────────────────────────────────────────
    if (-not (Resolve-NodeExe)) {
        war "[Node.js]  없음 -> 설치 중 (수 분 소요)..."
        if ($useWinget) {
            winget install OpenJS.NodeJS.LTS --silent --scope machine `
                --accept-source-agreements --accept-package-agreements
        }
        Update-PathFromRegistry
        if (-not (Resolve-NodeExe)) {
            war "[Node.js]  winget 실패 -> MSI 다운로드 시도..."
            try {
                $msi = "$env:TEMP\node_lts.msi"
                Invoke-WebRequest "https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi" `
                    -OutFile $msi -UseBasicParsing
                Start-Process msiexec -ArgumentList "/i `"$msi`" /quiet /norestart ADDLOCAL=ALL" -Wait
                Remove-Item $msi -Force -ErrorAction SilentlyContinue
            } catch { ng "[Node.js]  MSI 다운로드 실패: $_" }
            Update-PathFromRegistry
        }
    }
    $script:NODE_EXE = Resolve-NodeExe
    $script:NPM_CMD  = Resolve-NpmCmd
    if ($script:NODE_EXE) {
        $v = & $script:NODE_EXE --version 2>$null
        ok "[Node.js]   $v  ($script:NODE_EXE)"
    } else {
        ng "[Node.js]   설치 실패 - 수동 설치 후 재실행 필요"
    }

    # ── Python 설치 ──────────────────────────────────────────────
    $script:PYTHON_EXE = Resolve-PythonExe
    if (-not $script:PYTHON_EXE) {
        war "[Python]   없음 -> 설치 중 (수 분 소요)..."
        if ($useWinget) {
            # 3.12 우선, 실패 시 3.13 시도
            winget install Python.Python.3.12 --silent --scope machine `
                --accept-source-agreements --accept-package-agreements
            Update-PathFromRegistry
            if (-not (Resolve-PythonExe)) {
                winget install Python.Python.3.13 --silent --scope machine `
                    --accept-source-agreements --accept-package-agreements
                Update-PathFromRegistry
            }
        }
        if (-not (Resolve-PythonExe)) {
            war "[Python]   winget 실패 -> 공식 인스톨러 직다운로드 시도..."
            try {
                $py = "$env:TEMP\python_installer.exe"
                Invoke-WebRequest "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe" `
                    -OutFile $py -UseBasicParsing
                # /quiet, all-users, PATH 등록, py 런처 등록
                Start-Process $py -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_launcher=1" -Wait
                Remove-Item $py -Force -ErrorAction SilentlyContinue
            } catch { ng "[Python]   인스톨러 다운로드 실패: $_" }
            Update-PathFromRegistry
        }
        $script:PYTHON_EXE = Resolve-PythonExe
    }
    if ($script:PYTHON_EXE) {
        $v = & $script:PYTHON_EXE --version 2>&1
        ok "[Python]    $v  ($script:PYTHON_EXE)"
    } else {
        ng "[Python]    설치 실패 - 수동 설치 후 재실행 필요"
        throw "Python 인터프리터를 찾지 못했습니다. https://www.python.org 에서 수동 설치 후 재실행하세요."
    }

    # ── pip 동봉 확인 (바닐라 Windows 대응) ───────────────────────
    # 표준 python.org / winget Python 은 pip 가 동봉돼 있지만, 비표준 빌드나
    # 스트립된 배포는 pip 가 누락돼 있을 수 있다. Resolve-PythonExe 가
    # python.exe 만 통과시키는 케이스에서 pip 부재로 뒤늦게 실패하는 것을
    # 막기 위해, 여기서 명시적으로 점검하고 ensurepip 으로 부트스트랩한다.
    # (Ubuntu run.sh 의 python3-pip 별도 점검과 동일 취지)
    & $script:PYTHON_EXE -m pip --version > $null 2>&1
    if ($LASTEXITCODE -ne 0) {
        war "[pip]      Python 에 pip 미동봉 -> ensurepip 부트스트랩 중..."
        & $script:PYTHON_EXE -m ensurepip --upgrade 2>&1 | ForEach-Object { inf $_ }
    }
    $pipVer = (& $script:PYTHON_EXE -m pip --version 2>$null)
    if ($pipVer) { ok "[pip]       $pipVer" }
    else         { ng "[pip]       사용 불가 - 수동 복구 필요" }

    # ── Trivy ────────────────────────────────────────────────────
    if (-not (Get-Command trivy -ErrorAction SilentlyContinue)) {
        war "[Trivy]    없음 -> 다운로드 중..."
        try {
            $tag = (Invoke-WebRequest "https://api.github.com/repos/aquasecurity/trivy/releases/latest" `
                -UseBasicParsing | ConvertFrom-Json).tag_name
            $ver = $tag.TrimStart("v")
            Invoke-WebRequest "https://github.com/aquasecurity/trivy/releases/download/$tag/trivy_${ver}_windows-64bit.zip" `
                -OutFile "$env:TEMP\trivy.zip" -UseBasicParsing
            Expand-Archive "$env:TEMP\trivy.zip" -DestinationPath $TOOLS -Force
            Remove-Item "$env:TEMP\trivy.zip" -Force
        } catch { ng "[Trivy]    다운로드 실패: $_" }
    }
    $v = (trivy --version 2>$null | Select-Object -First 1)
    if ($v) { ok "[Trivy]     $v" } else { ng "[Trivy]     설치 실패" }

    # ── Grype ────────────────────────────────────────────────────
    if (-not (Get-Command grype -ErrorAction SilentlyContinue)) {
        war "[Grype]    없음 -> 다운로드 중..."
        try {
            $tag = (Invoke-WebRequest "https://api.github.com/repos/anchore/grype/releases/latest" `
                -UseBasicParsing | ConvertFrom-Json).tag_name
            $ver = $tag.TrimStart("v")
            Invoke-WebRequest "https://github.com/anchore/grype/releases/download/$tag/grype_${ver}_windows_amd64.zip" `
                -OutFile "$env:TEMP\grype.zip" -UseBasicParsing
            Expand-Archive "$env:TEMP\grype.zip" -DestinationPath $TOOLS -Force
            Remove-Item "$env:TEMP\grype.zip" -Force
        } catch { ng "[Grype]    다운로드 실패: $_" }
    }
    if (Get-Command grype -ErrorAction SilentlyContinue) { ok "[Grype]     설치됨" } else { ng "[Grype]     설치 실패" }

    # ── npm 패키지 ───────────────────────────────────────────────
    $serverDir = Join-Path $ROOT "server"
    if (-not (Test-Path (Join-Path $serverDir "node_modules"))) {
        if (-not $script:NPM_CMD) {
            ng "[npm]       npm.cmd 를 찾지 못함 - Node.js 설치 확인 필요"
        } else {
            note "[npm]       node_modules 없음 -> 설치 중 (수 분 소요)..."
            Push-Location $serverDir
            try {
                & $script:NPM_CMD install 2>&1 | ForEach-Object { inf $_ }
                if ($LASTEXITCODE -ne 0) { ng "[npm]       npm install 실패 (exit=$LASTEXITCODE)" }
            } finally { Pop-Location }
        }
    }
    if (Test-Path (Join-Path $serverDir "node_modules")) {
        ok "[npm]       패키지 준비됨"
    } else {
        ng "[npm]       node_modules 없음"
    }

    # ── pip 패키지 (가장 자주 실패하는 단계 - 출력 그대로 보여줌) ──
    # FastAPI 공식 권장: "fastapi[standard]" 한 줄로 uvicorn[standard] +
    # python-multipart + httpx 가 자동으로 함께 설치됩니다.
    $pyPkgs = @(
        "fastapi[standard]",
        "requests",
        "dash", "dash-mantine-components", "dash-iconify",
        "pandas", "plotly", "deep-translator",
        "supabase",                                  # PDF: Supabase Storage 업로드용 클라이언트
        "weasyprint"                                 # PDF: HTML → PDF 변환 (GTK runtime 별도 설치 필요)
    )
    $importProbe = "import fastapi, uvicorn, requests, dash, dash_mantine_components, dash_iconify, pandas, plotly, deep_translator, supabase, weasyprint"

    # ensurepip 안전망: 일부 배포판에서 pip 가 미동봉되어 있을 때 부트스트랩
    inf "[pip]       ensurepip 부트스트랩 (필요 시)..."
    & $script:PYTHON_EXE -m ensurepip --upgrade 2>&1 | ForEach-Object { inf $_ }

    inf "[pip]       pip 자체 업그레이드..."
    & $script:PYTHON_EXE -m pip install --upgrade pip 2>&1 | ForEach-Object { inf $_ }

    & $script:PYTHON_EXE -c $importProbe 2>$null
    if ($LASTEXITCODE -eq 0) {
        ok "[pip]       모든 패키지 이미 설치됨"
    } else {
        war "[pip]       패키지 설치 중 (수 분 소요)..."
        & $script:PYTHON_EXE -m pip install --upgrade @pyPkgs 2>&1 | ForEach-Object { inf $_ }
        $exit1 = $LASTEXITCODE
        if ($exit1 -ne 0) {
            war "[pip]       1차 설치 실패 (exit=$exit1) -> --user 모드 재시도..."
            & $script:PYTHON_EXE -m pip install --user --upgrade @pyPkgs 2>&1 | ForEach-Object { inf $_ }
        }
        # 검증
        $verify = & $script:PYTHON_EXE -c "$importProbe; print('OK')" 2>&1
        if ($verify -match 'OK') {
            ok "[pip]       패키지 검증 성공"
        } else {
            ng "[pip]       패키지 검증 실패 - 다음을 수동 설치 시도하세요:"
            inf "  & `"$script:PYTHON_EXE`" -m pip install $($pyPkgs -join ' ')"
            inf "검증 출력: $verify"
        }
    }

    # ── GTK runtime (WeasyPrint 시스템 의존성) ───────────────────
    # WeasyPrint 는 Cairo / Pango / GDK-PixBuf 등 GTK 3 라이브러리 필요.
    # pip 만으론 절대 설치 안 됨 — Windows 용 GTK runtime 별도 설치해야 함.
    #
    # 전략 (v12 부터 winget 의존성 제거):
    #   1) WeasyPrint 가 이미 동작하면 통과
    #   2) GitHub releases 에서 GTK3 Runtime installer 직접 다운로드 (~24MB)
    #   3) /S (silent) 모드로 자동 설치 (NSIS installer 지원)
    #   4) PATH 에 GTK bin 강제 추가 + 재검증
    #   5) 그래도 실패 시 명확한 수동 안내
    inf "[GTK]       WeasyPrint 시스템 의존성 확인 중..."
    $gtkTestPath = Join-Path $env:TEMP "dsp_gtk_test.pdf"
    function Test-WeasyPrint {
        $probe = & $script:PYTHON_EXE -c "from weasyprint import HTML; HTML(string='<p>x</p>').write_pdf(r'$gtkTestPath'); print('OK')" 2>&1
        return ($probe -match 'OK')
    }
    if (Test-WeasyPrint) {
        ok "[GTK]       WeasyPrint 동작 확인 (GTK runtime 이미 사용 가능)"
        Remove-Item -ErrorAction SilentlyContinue $gtkTestPath
    } else {
        war "[GTK]       WeasyPrint 가 GTK 못 찾음 -> 자동 다운로드/설치 시작..."

        $gtkUrl       = "https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases/download/2022-01-04/gtk3-runtime-3.24.31-2022-01-04-ts-win64.exe"
        $gtkInstaller = Join-Path $env:TEMP "gtk3-runtime-dsp.exe"

        # ── (1/3) GitHub releases 에서 installer 직접 다운로드 ──
        inf "[GTK]       (1/3) GitHub releases 에서 installer 다운로드 (약 24MB)..."
        $downloaded = $false
        try {
            # .NET WebClient 가 Invoke-WebRequest 보다 빠름 (PowerShell 5.1 기본)
            $wc = New-Object System.Net.WebClient
            $wc.Headers.Add('User-Agent','DSP-Installer')
            $wc.DownloadFile($gtkUrl, $gtkInstaller)
            $wc.Dispose()
            $sizeMB = [math]::Round((Get-Item $gtkInstaller).Length / 1MB, 1)
            inf "[GTK]       다운로드 완료 ($sizeMB MB)"
            $downloaded = $true
        } catch {
            ng "[GTK]       다운로드 실패: $($_.Exception.Message)"
            # 폴백: winget 도 한번 시도
            if (Get-Command winget -ErrorAction SilentlyContinue) {
                war "[GTK]       폴백: winget 으로 시도..."
                winget install --silent --accept-package-agreements --accept-source-agreements --id "tschoonj.GTKForWindows" 2>&1 | ForEach-Object { inf $_ }
            }
        }

        # ── (2/3) silent install — UI 완전 숨김 ──
        # WindowStyle Hidden + /S 조합으로 NSIS 의 짧은 진행 다이얼로그도
        # 표시되지 않게 한다. (한국어 Windows 의 CP949 ↔ 인스톨러 ANSI 충돌로
        # 깨진 글자 나오는 cosmetic 이슈 제거 목적.)
        # 인스톨러 stdout/stderr 는 임시 로그로 격리.
        if ($downloaded -and (Test-Path $gtkInstaller)) {
            inf "[GTK]       (2/3) Silent install 실행 (약 30초 소요, UI 숨김)..."
            $instLog = Join-Path $env:TEMP "dsp_gtk_install.log"
            try {
                $proc = Start-Process -FilePath $gtkInstaller `
                                      -ArgumentList "/S" `
                                      -Wait -PassThru `
                                      -WindowStyle Hidden `
                                      -RedirectStandardOutput $instLog `
                                      -RedirectStandardError "$instLog.err" `
                                      -ErrorAction Stop
                if ($proc.ExitCode -eq 0) {
                    ok "[GTK]       installer 정상 종료 (exit 0)"
                } else {
                    war "[GTK]       installer exit code $($proc.ExitCode) — 검증으로 동작 확인"
                }
            } catch {
                # WindowStyle/Redirect 옵션이 일부 환경에서 실패하면 폴백
                war "[GTK]       hidden 모드 실패 — 폴백 (UI 일시 표시 가능): $($_.Exception.Message)"
                try {
                    $proc = Start-Process -FilePath $gtkInstaller -ArgumentList "/S" -Wait -PassThru -ErrorAction Stop
                    if ($proc.ExitCode -eq 0) { ok "[GTK]       installer 정상 종료 (폴백)" }
                } catch {
                    ng "[GTK]       silent install 실패: $($_.Exception.Message)"
                }
            } finally {
                Remove-Item -ErrorAction SilentlyContinue $gtkInstaller, $instLog, "$instLog.err"
            }
        }

        # ── (3/3) PATH 갱신 + 재검증 ──
        inf "[GTK]       (3/3) PATH 갱신 + 동작 재검증..."
        # GTK 기본 설치 경로 PATH 에 강제 추가 (PATH 갱신 실패 안전망)
        $gtkBinCandidates = @(
            "C:\Program Files\GTK3-Runtime Win64\bin",
            "C:\Program Files (x86)\GTK3-Runtime Win64\bin"
        )
        foreach ($p in $gtkBinCandidates) {
            if (Test-Path $p) {
                $env:PATH = "$p;$env:PATH"
                inf "[GTK]       PATH 에 추가: $p"
                break
            }
        }
        Update-PathFromRegistry

        if (Test-WeasyPrint) {
            ok "[GTK]       설치 + 검증 성공 ✓ PDF 추출 사용 가능"
            Remove-Item -ErrorAction SilentlyContinue $gtkTestPath
        } else {
            ng "[GTK]       검증 실패 — 수동 설치 필요"
            inf "  ┌─ 수동 설치 절차 ─────────────────────────────────────────"
            inf "  │ 1) 브라우저로 다음 URL 접속:"
            inf "  │    https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases"
            inf "  │ 2) 'gtk3-runtime-...-win64.exe' 클릭해 다운로드"
            inf "  │ 3) 다운받은 .exe 더블클릭 → Next 만 클릭하면 기본 설치"
            inf "  │ 4) 새 PowerShell/cmd 창 열고 run.bat 재실행"
            inf "  │ (참고) PDF 추출 외 다른 기능은 GTK 없어도 정상 동작"
            inf "  └────────────────────────────────────────────────────────"
        }
    }

    # ── .env ─────────────────────────────────────────────────────
    $envFile = Join-Path $serverDir ".env"
    if (-not (Test-Path $envFile)) {
        $ex = Join-Path $serverDir ".env.example"
        if (Test-Path $ex) { Copy-Item $ex $envFile }
        war "[.env]      생성됨 - Supabase 키를 입력하세요!"
    } else {
        ok "[.env]      확인됨"
    }

    # ── uploads 디렉터리 ─────────────────────────────────────────
    $upDir = Join-Path $serverDir "uploads"
    if (-not (Test-Path $upDir)) { New-Item -ItemType Directory -Path $upDir | Out-Null }
    ok "[uploads]   디렉터리 준비됨"

    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  STEP 3  서비스 시작
# ================================================================
function Invoke-StartServices {
    cw "  +-- STEP 3/3  서비스 시작 --------------------------------------" DarkGray

    # 스캐너 임시 작업 디렉터리 (분석 산출물 .json 들이 여기 쌓임 — 프로젝트 루트 오염 방지)
    $scannerWork = Join-Path $ROOT "python\.work"
    if (-not (Test-Path $scannerWork)) {
        New-Item -ItemType Directory -Path $scannerWork -Force | Out-Null
    }

    # Python 절대경로 - StackSetup 에서 미리 탐지/설치 완료된 인터프리터 사용
    if (-not $script:PYTHON_EXE) { $script:PYTHON_EXE = Resolve-PythonExe }
    if (-not $script:NPM_CMD)    { $script:NPM_CMD    = Resolve-NpmCmd }
    $pyq  = "`"$script:PYTHON_EXE`""
    $npmq = if ($script:NPM_CMD) { "`"$script:NPM_CMD`"" } else { "npm" }

    inf "[1/3] Python 스캐너     (port 8000) 시작..."
    # 'uvicorn' 명령 대신 'python -m uvicorn' 으로 가상환경/PATH 미반영 문제 회피
    Start-Service "DSP-Scanner" $ROOT "$pyq -m uvicorn python.scanner:app --host 0.0.0.0 --port 8000" `
        @{ SCANNER_WORK_DIR = $scannerWork }
    Start-Sleep -Seconds 2

    inf "[2/3] Node.js API 서버  (port 3000) 시작..."
    Start-Service "DSP-Node" "$ROOT\server" "$npmq start"
    Start-Sleep -Seconds 2

    inf "[3/3] Dash 대시보드     (port 8050) 시작..."
    Start-Service "DSP-Dash" $ROOT "$pyq frontend\front_end_v11_4.py"

    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  STEP 4  자가점검
# ================================================================
function Invoke-SelfCheck {
    cw "  +-- STEP 4  자가점검 (서비스 기동 대기 5초...) -----------------" DarkGray
    Start-Sleep -Seconds 5

    # v21: scope 일관 사용 — 기존엔 $allOk 가 function-local 이라
    # 내부 Check 함수가 $script:allOk = $false 를 써도 이 함수의 마지막
    # `if ($allOk)` 가 로컬 변수만 봐서 NG 가 있어도 항상 ALL OK 로 분기하던
    # 회귀가 있었음. 두 곳 모두 $script:allOk 로 통일.
    $script:allOk = $true

    function Check {
        param([string]$label, [bool]$result)
        if ($result) { ok $label }
        else         { ng $label; $script:allOk = $false }
    }

    Check "[도구] Trivy                " ($null -ne (Get-Command trivy -EA SilentlyContinue))
    Check "[도구] Grype                " ($null -ne (Get-Command grype -EA SilentlyContinue))
    Check "[서버] Python 스캐너 :8000  " (Test-Port 8000)
    Check "[서버] Node.js API   :3000  " (Test-Port 3000)
    Check "[서버] Dash 대시보드 :8050  " (Test-Port 8050)
    Check "[파일] server/.env          " (Test-Path "$ROOT\server\.env")
    Check "[파일] server/node_modules  " (Test-Path "$ROOT\server\node_modules")
    Check "[파일] python/scanner.py    " (Test-Path "$ROOT\python\scanner.py")
    Check "[파일] frontend/front_end   " (Test-Path "$ROOT\frontend\front_end_v11_4.py")
    Check "[폴더] server/uploads/      " (Test-Path "$ROOT\server\uploads")

    cw "  |" DarkGray
    if ($script:allOk) {
        cw "  |  [ALL OK] 모든 항목 정상입니다." Green
    } else {
        cw "  |  [!!] [NG] 항목을 확인하세요. 서비스가 뜨는 중일 수 있습니다." Yellow
    }
    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  서비스 전체 종료
# ================================================================
function Stop-AllServices {
    cw ""
    cw "  서비스 종료 중..." Yellow

    # 1. 우리가 띄운 cmd 창 + 자식 프로세스 트리 통째로 종료 (PID 기반 - 가장 확실)
    foreach ($id in $script:ServicePids) {
        cmd /c "taskkill /T /F /PID $id" 2>$null | Out-Null
    }
    $script:ServicePids = @()

    # 2. 혹시 남아있는 node / python / uvicorn 프로세스 정리
    Get-Process -Name "node"    -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name "python"  -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name "uvicorn" -ErrorAction SilentlyContinue | Stop-Process -Force

    # 3. 포트 점유 프로세스 정리 (마지막 안전망)
    foreach ($p in @(3000, 8000, 8050)) { Stop-Port $p }

    cw "  서비스 / 창 종료 완료." Green
    cw "  (브라우저 탭은 직접 닫아주세요)" Gray
    Start-Sleep -Seconds 2
}

# ================================================================
#  상태 바
# ================================================================
function Show-StatusBar {
    $t  = Get-Date -Format "HH:mm:ss"
    $r1 = Test-Port 8000; $r2 = Test-Port 3000; $r3 = Test-Port 8050
    $s1 = if ($r1) { "(*) ON " } else { "( ) OFF" }
    $s2 = if ($r2) { "(*) ON " } else { "( ) OFF" }
    $s3 = if ($r3) { "(*) ON " } else { "( ) OFF" }
    cw "  +-- 서비스 상태  $t ----------------------------------------" DarkGray
    Write-Host "  |  Python  스캐너  :8000  " -NoNewline; cw $s1 $(if ($r1){"Green"}else{"Red"})
    Write-Host "  |  Node.js API     :3000  " -NoNewline; cw $s2 $(if ($r2){"Green"}else{"Red"})
    Write-Host "  |  Dash   대시보드 :8050  " -NoNewline; cw $s3 $(if ($r3){"Green"}else{"Red"})
    cw "  +----------------------------------------------------------------" DarkGray
}

# ================================================================
#  STEP 5  실행 모드 선택 메뉴
# ================================================================
function Show-Menu {
    # v26: Format-BoxLine 으로 한글 폭 자동 보정
    $W = 66
    $bar = '+' + ('=' * $W) + '+'
    cw "  $bar" Cyan
    cw "  $(Format-BoxLine '  DSP 실행 중' $W)" Cyan
    cw "  $(Format-BoxLine '  대시보드 : http://localhost:8050' $W)" Cyan
    cw "  $(Format-BoxLine '  로그인   : http://localhost:8050/login (자동 redirect)' $W)" Cyan
    cw "  $(Format-BoxLine '  API      : http://localhost:3000/health' $W)" Cyan
    cw "  $(Format-BoxLine '  스캐너   : http://localhost:8000/health' $W)" Cyan
    cw "  $bar" Cyan
    cw ""
    cw "  실행 모드를 선택하세요:" White
    cw ""
    cw "    [1]  모니터링 유지     - 이 창에서 서비스 상태 실시간 확인" White
    cw "    [2]  이 창만 닫기      - 서비스 창 3개는 그대로 유지" White
    cw "    [3]  모든 서비스 종료  - 서비스 창 3개 + 이 창 모두 종료" White
    cw ""

    while ($true) {
        $choice = (Read-Host "  선택 (1 / 2 / 3)").Trim()
        switch ($choice) {

            "1" {
                cw ""
                cw "  [모니터링]  Enter = 상태 갱신 / q = 종료 메뉴" DarkGray
                cw ""
                while ($true) {
                    Show-StatusBar
                    $key = (Read-Host "  > Enter 갱신 . q 종료메뉴").Trim()
                    if ($key -match '^[qQ]$') { break }
                }
                cw ""
                $yn = (Read-Host "  서비스를 종료하시겠습니까? (y / n)").Trim()
                if ($yn -match '^[yY]$') { Stop-AllServices; return }
                cw ""; Show-Menu; return
            }

            "2" {
                cw ""
                cw "  이 창만 닫습니다. 서비스 창 3개는 계속 실행됩니다." Green
                cw "  (작업표시줄에 Scanner / Node / Dash 창이 그대로 남음)" Gray
                cw "  나중에 종료하려면 run.bat 재실행 -> [3] 선택" DarkGray
                cw ""
                Read-Host "  Enter 키를 누르면 이 창이 닫힙니다" | Out-Null
                return
            }

            "3" {
                Stop-AllServices
                return
            }

            default {
                cw "  1, 2, 3 중 하나를 입력하세요." Yellow
            }
        }
    }
}

# ================================================================
#  메인 - 전체를 try-catch로 감싸서 오류 시 창이 닫히지 않음
# ================================================================
try {
    Show-Banner
    Invoke-PortCleanup

    Show-Banner
    Invoke-StackSetup

    Show-Banner
    Invoke-StartServices

    Show-Banner
    Invoke-SelfCheck

    # 대시보드 자동 오픈 — v4 계열은 자체 webbrowser 호출 코드가 없으므로
    # 런처가 기본 브라우저로 http://localhost:8050 을 띄웁니다.
    # 포트가 아직 안 떠 있으면 잠시 대기 후 시도합니다.
    if (Test-Port 8050) {
        cw "  대시보드를 기본 브라우저로 엽니다: http://localhost:8050" Green
        Start-Process "http://localhost:8050"
    } else {
        Start-Sleep -Seconds 3
        if (Test-Port 8050) {
            cw "  대시보드를 기본 브라우저로 엽니다: http://localhost:8050" Green
            Start-Process "http://localhost:8050"
        } else {
            war "Dash 가 아직 기동 중 — 브라우저를 수동으로 여세요: http://localhost:8050"
        }
    }

    Show-Menu

} catch {
    cw ""
    cw "  ==========================================" Red
    cw "  오류 발생:" Red
    cw "  $($_.Exception.Message)" Red
    cw "  위치: $($_.InvocationInfo.PositionMessage)" Red
    cw "  ==========================================" Red
    cw ""
    Read-Host "  오류 내용을 확인하고 Enter 를 누르세요"
}
