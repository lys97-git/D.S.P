# ================================================================
# DSP Integrated Security Dashboard
# ================================================================

import subprocess
import sys
import os                                    
import json
import datetime
import base64
import io
import re

# ================================================================
# [BOOTSTRAP] 사용자 라이브러리 자동 설치 보장
# ================================================================
_REQUIRED = {
    "requests": "requests",
    "pandas": "pandas",
    "plotly": "plotly",
    "dash": "dash",
    "dash_mantine_components": "dash-mantine-components",
    "dash_iconify": "dash-iconify",
    "deep_translator": "deep-translator",
    "flask": "flask",                        
}

def _ensure_pkg(pkg):
    for extra in (["--break-system-packages"], ["--user"], []):
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-q", pkg, *extra],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            continue
    return False

for _mod, _pkg in _REQUIRED.items():
    try:
        __import__(_mod)
    except ImportError:
        if not _ensure_pkg(_pkg):
            print(f"[BOOTSTRAP] '{_pkg}' 자동설치 실패 — 수동 설치 필요:", file=sys.stderr)

import requests
import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html, Input, Output, State, callback, ALL, no_update, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
from flask import Response, request as flask_request, send_from_directory, redirect  
from deep_translator import GoogleTranslator

_translation_cache = {}

def translate_to_korean(text):
    if not text or not str(text).strip():
        return text
    if text in _translation_cache:
        return _translation_cache[text]
    try:
        translated = GoogleTranslator(source="auto", target="ko").translate(str(text)[:4900])
        result = translated or text
    except Exception:
        result = text
    _translation_cache[text] = result
    return result

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
LOGIN_DIR = os.path.join(ROOT_DIR, "login")
DYNAMIC_DIR = os.path.join(ROOT_DIR, "dynamic")
SCANNER_API_BASE = os.environ.get("DSP_SCANNER_URL", "http://127.0.0.1:8000").rstrip("/")
NODE_API_BASE = os.environ.get("DSP_API_SERVER_URL", "http://127.0.0.1:3000").rstrip("/")
DYNAMIC_PUBLIC_API_BASE = os.environ.get("DSP_DYNAMIC_PUBLIC_API_BASE", "").rstrip("/")
DYNAMIC_PUBLIC_API_PORT = os.environ.get("DSP_DYNAMIC_PUBLIC_API_PORT", "8000").strip()
STATIC_VERSION = os.environ.get("DSP_STATIC_VERSION", datetime.datetime.now().strftime("%Y%m%d%H%M%S"))

app = dash.Dash(__name__, suppress_callback_exceptions=True)

# ================================================================
# [LOGIN-INTEGRATION] 정적 서빙 및 인증 게이트
# ================================================================
server = app.server  


def _load_supabase_web_config():
    url = (os.environ.get("SUPABASE_URL") or "").strip()
    anon_key = (os.environ.get("SUPABASE_ANON_KEY") or "").strip()
    if url and anon_key:
        return url, anon_key

    config_path = os.path.join(LOGIN_DIR, "config.js")
    if not os.path.exists(config_path):
        return "", ""

    try:
        with open(config_path, "r", encoding="utf-8") as handle:
            source = handle.read()
    except UnicodeDecodeError:
        with open(config_path, "r", encoding="utf-8-sig") as handle:
            source = handle.read()

    def _extract(name):
        match = re.search(rf"{name}\s*=\s*[\"']([^\"']+)[\"']", source)
        return match.group(1).strip() if match else ""

    return _extract("SUPABASE_URL"), _extract("SUPABASE_ANON_KEY")


def _infer_dynamic_public_api_base():
    if DYNAMIC_PUBLIC_API_BASE:
        return DYNAMIC_PUBLIC_API_BASE

    host = (flask_request.headers.get("X-Forwarded-Host") or flask_request.host).split(",")[0].strip()
    scheme = (flask_request.headers.get("X-Forwarded-Proto") or flask_request.scheme or "http").split(",")[0].strip()

    if host.startswith("["):
        hostname = host.split("]")[0] + "]"
    else:
        hostname = host.split(":", 1)[0]

    if DYNAMIC_PUBLIC_API_PORT:
        netloc = f"{hostname}:{DYNAMIC_PUBLIC_API_PORT}"
    else:
        netloc = host

    return f"{scheme}://{netloc}/dynamic-api"


def _safe_json(response):
    try:
        return response.json()
    except ValueError:
        return {"ok": False, "error": response.text[:300] or f"HTTP {response.status_code}"}

@server.route('/login')
def _serve_login_redirect():
    return redirect('/login/', code=302)

@server.route('/login/')
def _serve_login_index():
    return send_from_directory(LOGIN_DIR, 'index.html')

@server.route('/login/<path:filename>')
def _serve_login_assets(filename):
    return send_from_directory(LOGIN_DIR, filename)


@server.route("/style.css")
def _serve_style_css():
    return send_from_directory(ROOT_DIR, "style.css")


@server.route("/dynamic")
def _serve_dynamic_redirect():
    return redirect("/dynamic/", code=302)


@server.route("/dynamic/")
def _serve_dynamic_index():
    return send_from_directory(DYNAMIC_DIR, "dynamic_page.html")


@server.route("/dynamic/config.js")
def _serve_dynamic_config():
    supabase_url, supabase_anon_key = _load_supabase_web_config()
    payload = {
        "apiBase": _infer_dynamic_public_api_base(),
        "supabaseUrl": supabase_url,
        "supabaseAnonKey": supabase_anon_key,
        "vmHost": os.environ.get("DYNAMIC_VM_HOST", "192.168.25.132").strip(),
        "vmUser": os.environ.get("DYNAMIC_VM_USER", "pro").strip(),
        "vmPort": os.environ.get("DYNAMIC_VM_PORT", "22").strip(),
    }
    body = f"window.DSP_DYNAMIC_CONFIG = {json.dumps(payload, ensure_ascii=False)};"
    return Response(body, mimetype="application/javascript")


@server.route("/dynamic/<path:filename>")
def _serve_dynamic_assets(filename):
    if filename == "config.js":
        return _serve_dynamic_config()
    return send_from_directory(DYNAMIC_DIR, filename)

app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <link rel="stylesheet" href="/style.css?v=''' + STATIC_VERSION + '''">
        <script>
            (function () {
                if (window.location.pathname.startsWith('/login')) return;
                const keys = Object.keys(window.localStorage)
                    .filter(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
                let authed = false;
                for (const k of keys) {
                    try {
                        const v = JSON.parse(window.localStorage.getItem(k));
                        if (v && v.access_token && v.expires_at && v.expires_at * 1000 > Date.now()) {
                            authed = true;
                            break;
                        }
                    } catch (e) { }
                }
                if (!authed) {
                    window.location.replace('/login/');
                }
            })();
        </script>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# [Plotly 내부 및 색상 계산에만 사용할 색상 상수 유지 - HTML style용이 아님]
THEME_TEXT_MAIN = "#ccd6f6"
SEVERITY_COLORS = {
    "CRITICAL": "#ff4d4d",
    "HIGH": "#ff944d",
    "MEDIUM": "#ffd11a",
    "LOW": "#4da6ff",
    "UNKNOWN": "#a6a6a6"
}

def create_title_with_popover(title_text, popover_content, position="right"):
    return dmc.Group(gap="xs", children=[
        dmc.Text(title_text, fw=700, className="text-accent"),
        dmc.Popover(
            width=280, position=position, withArrow=True, shadow="md",
            children=[
                dmc.PopoverTarget(
                    dmc.ActionIcon(
                        DashIconify(icon="tabler:info-circle", width=18), 
                        size="sm", variant="transparent", color="teal"
                    )
                ),
                dmc.PopoverDropdown(
                    dmc.Text(popover_content, size="sm", className="text-main"),
                    className="paper-panel"
                )
            ]
        )
    ])

# ================================================================
# [레이아웃 구성]
# ================================================================
app.layout = dmc.MantineProvider(
    forceColorScheme="dark",
    children=[
        html.Div(
            className="main-layout", # 스타일 분리 완료
            children=[
                dmc.LoadingOverlay(id="loading-overlay", visible=False, overlayProps={"blur": 2}, zIndex=1000),

                # [네비게이션 바 섹션]
                dmc.Paper(
                    withBorder=True, p="md", radius="md", mb="xl",
                    className="paper-panel",
                    children=[
                        dmc.Group(justify="space-between", children=[
                            dmc.Group(gap="xl", children=[
                                dmc.Group(gap="sm", children=[
                                    DashIconify(icon="material-symbols:shield-lock", width=36, className="text-accent"),
                                    dmc.Title("DSP Integrated Security Dashboard", order=3, className="text-accent"),
                                ]),
                                dmc.Group(gap="sm", children=[
                                    dmc.Button("이미지 분석", id="nav-image-btn", variant="light", color="teal", size="sm"),
                                    dmc.Button("동적 분석", id="nav-dynamic-btn", variant="subtle", color="gray", size="sm"),
                                ])
                            ]),
                            dmc.Group([
                                dmc.Text(id="user-email-display", size="sm", fw=600, className="text-accent"),
                                dmc.Button("PDF 추출", id="btn-export-pdf", variant="outline", color="teal", leftSection=DashIconify(icon="tabler:file-download")),
                                dmc.Button("로그아웃", id="btn-logout", variant="subtle", color="red", leftSection=DashIconify(icon="tabler:logout"))
                            ], gap="sm")
                        ])
                    ]
                ),

                # [1. 이미지 분석 페이지]
                html.Div(
                    id="page-image-analysis",
                    className="display-block", 
                    children=[
                        dmc.Grid(gutter="md", children=[
                            dmc.GridCol(span=4, className="flex-col", children=[
                                dmc.Paper(withBorder=True, p="md", radius="md", mb="md", className="paper-panel", children=[
                                    create_title_with_popover("이미지 분석 설정", "확장자가 .tar 인 Docker 이미지 파일만 업로드할 수 있습니다. 파일을 박스에 넣은 후 '스캔 시작'을 누르세요."),
                                    dmc.Space(h="md"),
                                    dcc.Loading(id="loading-upload", type="circle", color="teal", children=[
                                        dcc.Upload(
                                            id='upload-data', accept=".tar",
                                            children=html.Div([
                                                DashIconify(id="upload-icon", icon="tabler:upload", width=30),
                                                dmc.Text("파일을 드래그하세요 (.tar 전용)", id="upload-text")
                                            ], className="text-center"),
                                            className="upload-box"
                                        )
                                    ]),
                                    dmc.Space(h=15),
                                    dmc.Button("스캔 시작", id="btn-start-scan", fullWidth=True, color="teal")
                                ]),
                                dmc.Paper(withBorder=True, p="md", radius="md", className="paper-panel flex-1 flex-col", children=[
                                    dmc.Text("시스템 진행 로그", fw=700, mb="xs", className="text-accent"),
                                    html.Div(id="system-log-container", className="flex-1 overflow-auto text-xs min-h-200")
                                ])
                            ]),

                            dmc.GridCol(span=8, className="flex-row", children=[
                                dmc.Paper(withBorder=True, p="md", radius="md", className="paper-panel w-full flex-col", children=[
                                    dmc.Group(justify="space-between", mb="md", children=[
                                        create_title_with_popover("취약점 분포", "그래프의 조각을 클릭하면 아래 표가 해당 위험도로 필터링됩니다. 해제하려면 중앙 숫자를 누르세요.", position="bottom"),
                                        dmc.SegmentedControl(
                                            id="pie-tool-filter-toggle",
                                            data=[{"label": "전체", "value": "ALL"}, {"label": "Trivy", "value": "trivy"}, {"label": "Grype", "value": "grype"}],
                                            value="ALL", size="sm"
                                        )
                                    ]),
                                    html.Div(
                                        className="relative-container",
                                        children=[
                                            dcc.Graph(id="severity-pie-chart", className="h-full", config={'displaylogo': False, 'modeBarButtonsToRemove': ['toImage']}),
                                            html.Div(id="pie-center-text", title="클릭하여 필터 해제", className="pie-center")
                                        ]
                                    )
                                ])
                            ])
                        ]),

                        dmc.Space(h="xl"),

                        # [메인 취약점 테이블]
                        dmc.Paper(withBorder=True, p="md", radius="md", className="paper-panel", children=[
                            dmc.Group(justify="space-between", mb="md", children=[
                                create_title_with_popover("취약점 상세 리스트", "우측 끝의 눈동자 아이콘을 클릭하면 세부 설명과 한국어 번역 기능을 이용할 수 있습니다."),
                                dmc.SegmentedControl(
                                    id="tool-filter-toggle",
                                    data=[{"label": "전체", "value": "ALL"}, {"label": "Trivy", "value": "trivy"}, {"label": "Grype", "value": "grype"}],
                                    value="ALL"
                                )
                            ]),
                            html.Div(id="vulnerability-table-container", className="max-h-500")
                        ]),
                        
                        dmc.Space(h="xl"),

                        # [미스매치 테이블]
                        dmc.Paper(withBorder=True, p="md", radius="md", className="paper-panel", children=[
                            dmc.Group(justify="space-between", mb="md", children=[
                                create_title_with_popover("미스매치 분석 리스트", "Trivy와 Grype 간에 서로 탐지된 심각도가 다르게 나타난 내역만 추출하여 비교합니다.")
                            ]),
                            html.Div(id="mismatch-table-container", className="max-h-500")
                        ])
                    ]
                ),

                # [2. 동적 분석 페이지]
                html.Div(
                    id="page-dynamic-analysis",
                    className="display-none", 
                    children=[
                        dmc.Paper(
                            withBorder=True, p="xl", radius="md", ta="center", className="paper-panel mt-100",
                            children=[
                                DashIconify(icon="tabler:activity", width=64, className="text-dimmed mb-20"),
                                dmc.Title("동적 분석 페이지", order=2, className="text-accent", mb="sm"),
                                dmc.Text("현재 이 기능은 준비 중입니다.", size="lg", className="text-dimmed")
                            ]
                        ),
                        html.Iframe(
                            id="dynamic-analysis-frame",
                            src=f"/dynamic/?embedded=1&v={STATIC_VERSION}",
                            title="DSP Dynamic Analysis",
                            className="dynamic-iframe",
                        )
                    ]
                ),

                dcc.Location(id="url", refresh=False),
                dcc.Store(id="analysis-result-store"),
                dcc.Store(id="upload-log-store"),
                dcc.Store(id="selected-severity-store", data=None),
                dcc.Store(id="current-vuln-id", data=None),
                dcc.Store(id="sort-state", data={"column": "id", "ascending": True}),
                dcc.Store(id="mismatch-sort-state", data={"column": "id", "ascending": True}), # 미스매치 정렬 스토어
                dcc.Store(id="scan-status-store", data="idle"),
                dcc.Store(id="pdf-url-store"),
                dcc.Store(id="auth-token-store"), 
                html.Div(id="_logout-dummy", className="display-none"),
                html.Div(id="_pdf-trigger-dummy", className="display-none"),  

                dmc.Modal(
                    id="detail-modal", title="취약점 상세 분석 결과", size="xl",
                    children=[
                        dmc.Group(justify="flex-end", mb="sm", children=[
                            dmc.SegmentedControl(id="lang-toggle", data=[{"label": "English", "value": "EN"}, {"label": "한국어", "value": "KR"}], value="EN")
                        ]),
                        html.Div(id="modal-content")
                    ],
                    className="paper-panel"
                )
            ]
        )
    ]
)

# ================================================================
# [콜백] 화면 네비게이션 전환
# 역할: 네비게이션 바 버튼 클릭 시 표시할 페이지(CSS 클래스명)를 전환하고 버튼 색상을 변경합니다.
# 입력: 이미지 분석 버튼 클릭 수, 동적 분석 버튼 클릭 수
# 출력: 각 페이지의 표시 유무 클래스, 각 버튼의 디자인 형태 및 색상
# ================================================================
@callback(
    Output("page-image-analysis", "className"),
    Output("page-dynamic-analysis", "className"),
    Output("nav-image-btn", "variant"),
    Output("nav-image-btn", "color"),
    Output("nav-dynamic-btn", "variant"),
    Output("nav-dynamic-btn", "color"),
    Input("nav-image-btn", "n_clicks"),
    Input("nav-dynamic-btn", "n_clicks"),
    prevent_initial_call=True
)
def switch_pages(btn_image, btn_dynamic):
    trigger = ctx.triggered_id
    if trigger == "nav-dynamic-btn":
        return "display-none", "display-block", "subtle", "gray", "light", "teal"
    else:
        return "display-block", "display-none", "light", "teal", "subtle", "gray"

# ================================================================
# [콜백] 업로드 파일명 텍스트 표시
# 역할: 파일이 업로드 박스에 드롭되면 화면에 파일명을 표시합니다.
# ================================================================
@callback(
    Output("upload-text", "children"),
    Input("upload-data", "contents"),
    State("upload-data", "filename"),
    prevent_initial_call=True
)
def show_uploaded_file(contents, filename):
    if contents and filename:
        return [f"업로드됨: {filename}", html.Br(), " —  '스캔 시작' 클릭"]
    return no_update

# ================================================================
# [콜백] 스캔 시작 및 시스템 로그 전처리
# 역할: 파일이 존재하는지 검증한 뒤, API 호출 전 사전 로그를 남기고 스캔 트리거를 활성화합니다.
# ================================================================
@callback(
    Output("upload-log-store", "data", allow_duplicate=True),
    Output("scan-status-store", "data", allow_duplicate=True),
    Output("loading-overlay", "visible", allow_duplicate=True),
    Output("btn-start-scan", "disabled", allow_duplicate=True),
    Input("btn-start-scan", "n_clicks"),
    State("upload-data", "contents"),
    State("upload-data", "filename"),
    State("upload-log-store", "data"),
    prevent_initial_call=True
)
def trigger_scan_log(n_clicks, contents, filename, current_logs):
    if not n_clicks or not contents:
        return no_update, no_update, no_update, no_update

    logs = current_logs or []
    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"파일 업로드 확인 완료: {filename}"})
    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "API 서버로 전송 준비 중..."})
    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "분석 요청 전송 중 (Target: Trivy & Grype)..."})

    return logs, "trigger", True, True

# ================================================================
# [콜백] 백엔드 스캔 API 호출 및 DB 결과 적재
# 역할: 트리거된 상태일 때 JWT 토큰을 첨부하여 Node.js API 서버로 분석을 요청하고,
#       결과를 받아와 로컬 스토어에 저장합니다.
# ================================================================
@callback(
    Output("analysis-result-store", "data"),
    Output("upload-log-store", "data"),
    Output("scan-status-store", "data"),
    Output("loading-overlay", "visible"),
    Output("btn-start-scan", "disabled"),
    Input("scan-status-store", "data"),
    State("upload-data", "contents"),
    State("upload-data", "filename"),
    State("upload-log-store", "data"),
    State("auth-token-store", "data"),
    prevent_initial_call=True
)
def perform_scan(status, contents, filename, current_logs, token):
    if status != "trigger" or not contents:
        return no_update, no_update, no_update, no_update, no_update

    headers = {"Authorization": f"Bearer {token}"} if token else {}
    logs = current_logs or []
    try:
        content_type, content_string = contents.split(',')
        decoded = base64.b64decode(content_string)

        response = requests.post(
            f"{SCANNER_API_BASE}/scan",
            files={'file': (filename, io.BytesIO(decoded), 'application/x-tar')},
            data={'user_id': 'admin'},
            headers=headers,
            timeout=1800
        )

        if response.status_code == 200:
            scan_data = _safe_json(response)
            logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "스캐너 분석 완료 — DB 적재 확인 중..."})

            job_id = scan_data.get("job_id")
            final_data = scan_data
            if job_id:
                try:
                    db_resp = requests.get(f"{NODE_API_BASE}/results/{job_id}", headers=headers, timeout=60)
                    if db_resp.status_code == 200:
                        final_data = _safe_json(db_resp)
                        vuln_cnt = len(final_data.get("vulnerabilities", []))
                        logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"DB 결과 조회 완료 (API 경유 · 취약점 {vuln_cnt}건)"})
                    else:
                        logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"DB 조회 실패({db_resp.status_code}) — 스캐너 응답으로 대체"})
                except Exception as db_err:
                    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"DB 조회 통신 장애 — 스캐너 응답으로 대체: {str(db_err)[:80]}"})
            else:
                logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "job_id 미수신 — 스캐너 응답을 그대로 사용"})

            return final_data, logs, "idle", False, False
        else:
            logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"서버 에러 발생: {response.status_code}"})
            return no_update, logs, "idle", False, False
    except Exception as e:
        logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"통신 장애 발생: {str(e)}"})
        return no_update, logs, "idle", False, False

# ================================================================
# [콜백] 심각도 파이 차트 렌더링
# 역할: 스캔 결과 데이터를 취합해 심각도 기준 도넛 차트를 생성합니다.
# ================================================================
@callback(
    Output("severity-pie-chart", "figure"),
    Output("pie-center-text", "children"),
    Input("analysis-result-store", "data"),
    Input("pie-tool-filter-toggle", "value")
)
def update_pie_chart(data, tool_filter):
    def get_empty_state(msg="데이터 없음"):
        fig = px.pie(title=msg, hole=0.4).update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white")
        fig.update_traces(domain=dict(x=[0, 1], y=[0, 1]))
        center = [html.Div("0건", style={"fontSize": "24px", "fontWeight": "bold", "color": "#64ffda"})]
        return fig, center

    if not data or "vulnerabilities" not in data or not data["vulnerabilities"]:
        return get_empty_state()

    df = pd.DataFrame(data["vulnerabilities"])
    if df.empty or 'severity' not in df.columns:
        return get_empty_state()

    # 1. 도구 필터 적용
    if tool_filter != "ALL":
        df = df[df['source'] == tool_filter]
        if df.empty: return get_empty_state(f"{tool_filter.upper()} 결과 없음")

    # 2. [추가] 중복 CVE 제거 (가장 높은 심각도만 유지)
    severity_map = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    df['_temp_rank'] = df['severity'].map(severity_map).fillna(5)
    df = df.sort_values(by=["vulnerability_id", "_temp_rank"])
    df = df.drop_duplicates(subset=["vulnerability_id"], keep="first") # 중복 시 첫 번째(가장 높은 심각도) 유지
    df = df.drop(columns=["_temp_rank"])

    total_count = len(df)
    counts = df['severity'].value_counts().reset_index()
    counts.columns = ['severity', 'count']

    fig = px.pie(
        counts, values='count', names='severity',
        color='severity', color_discrete_map=SEVERITY_COLORS,
        hole=0.4
    )

    fig.update_traces(
        domain=dict(x=[0, 1], y=[0, 1]),
        hovertemplate="<b>%{label}</b><br>탐지 수: %{value}건",
        textinfo='label+percent'
    )

    fig.update_layout(
        showlegend=True,
        legend=dict(orientation="h", x=0.5, xanchor="center", y=-0.05),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=THEME_TEXT_MAIN),
        margin=dict(t=5, b=5, l=5, r=5)
    )

    center_html = [
        html.Div(f"{total_count}건", style={"fontSize": "24px", "fontWeight": "bold", "color": "#64ffda"})
    ]
    return fig, center_html

# ================================================================
# [콜백] 파이 차트 조각 클릭 감지 및 필터링 상태 저장
# 역할: 차트의 특정 조각을 눌렀을 때 해당 심각도를 저장하여 표를 연동 필터링합니다.
# ================================================================
@callback(
    Output("selected-severity-store", "data"),
    Input("severity-pie-chart", "clickData"),
    Input("pie-center-text", "n_clicks"),
    prevent_initial_call=True
)
def manage_severity_filter(click_data, center_clicks):
    trigger = ctx.triggered_id
    if trigger == "pie-center-text":
        return None
    elif trigger == "severity-pie-chart" and click_data:
        return click_data['points'][0]['label']
    return no_update

# ================================================================
# [콜백] 메인 취약점 상세 리스트 렌더링
# 역할: 분석 결과를 표 형태로 구성하고 오름차순/내림차순 정렬 및 필터링을 수행합니다.
# ================================================================
@callback(
    Output("vulnerability-table-container", "children"),
    Output("sort-state", "data"),
    Input("analysis-result-store", "data"),
    Input("tool-filter-toggle", "value"),
    Input("selected-severity-store", "data"),
    Input({"type": "sort-btn", "index": ALL}, "n_clicks"),
    State("sort-state", "data")
)
def update_table(data, tool_filter, selected_severity, sort_clicks, sort_state):
    sort_state = sort_state or {"column": "id", "ascending": True}

    if not data or "vulnerabilities" not in data or not data["vulnerabilities"]:
        return dmc.Text("분석 결과가 없습니다.", className="text-dimmed text-center", py=50), sort_state

    df = pd.DataFrame(data["vulnerabilities"])
    if df.empty:
        return dmc.Text("분석 결과가 없습니다.", className="text-dimmed text-center", py=50), sort_state

    OS_PKG_TYPES = {'deb', 'dpkg', 'rpm', 'apk', 'apkg', 'portage', 'alpm', 'nix'}
    OS_DISTROS   = {'debian', 'ubuntu', 'alpine', 'centos', 'redhat', 'amazon',
                    'amzn', 'oracle', 'photon', 'suse', 'rocky', 'alma', 'fedora'}

    def classify_row(row):
        rc = str(row.get('result_class', '')).lower()
        rt = str(row.get('result_type', '')).lower()
        if 'secret' in rc or 'secret' in rt: return 'SECRET'
        if rc == 'os-pkgs': return 'OS'
        if rc == 'lang-pkgs': return 'APP'
        if rt in OS_PKG_TYPES or rt in OS_DISTROS: return 'OS'
        return 'APP'

    df['class'] = df.apply(classify_row, axis=1)

    if ctx.triggered_id and isinstance(ctx.triggered_id, dict) and ctx.triggered_id.get("type") == "sort-btn":
        if sort_clicks and any(sort_clicks):
            clicked_col = ctx.triggered_id["index"]
            if sort_state.get("column") == clicked_col:
                sort_state["ascending"] = not sort_state.get("ascending", True)
            else:
                sort_state["column"] = clicked_col
                sort_state["ascending"] = True

    if tool_filter != "ALL":
        df = df[df['source'] == tool_filter]

    # 중복 CVE 제거 (가장 높은 심각도만 유지)
    severity_map = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    df['_temp_rank'] = df['severity'].map(severity_map).fillna(5)
    df = df.sort_values(by=["vulnerability_id", "_temp_rank"])
    df = df.drop_duplicates(subset=["vulnerability_id"], keep="first")
    df = df.drop(columns=["_temp_rank"])

    if selected_severity:
        df = df[df['severity'] == selected_severity]

    if sort_state.get("column") == "severity" and "severity" in df.columns:
        df['_sev_rank'] = df['severity'].map(severity_map).fillna(5)
        df = df.sort_values(by=["_sev_rank", "vulnerability_id"], ascending=[sort_state["ascending"], True])
        df = df.drop(columns=['_sev_rank'])
    elif sort_state.get("column") == "class":
        df = df.sort_values(by=["class", "vulnerability_id"], ascending=[sort_state["ascending"], True])
    elif "vulnerability_id" in df.columns:
        df = df.sort_values(by="vulnerability_id", ascending=sort_state["ascending"])

    id_icon = " ▲" if sort_state.get("column") == "id" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "id" else "")
    class_icon = " ▲" if sort_state.get("column") == "class" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "class" else "")
    sev_icon = " ▲" if sort_state.get("column") == "severity" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "severity" else "")

    header = html.Thead(
        html.Tr([
            html.Th("No.", className="text-center col-5"), # 넘버링 컬럼 추가
            html.Th(html.Div([f"ID{id_icon}"], id={"type": "sort-btn", "index": "id"}, className="cursor-pointer"), className="text-center col-15"),
            html.Th("패키지", className="text-center col-25"), # 30 -> 25 조절
            html.Th(html.Div([f"클래스{class_icon}"], id={"type": "sort-btn", "index": "class"}, className="cursor-pointer"), className="text-center col-10"),
            html.Th(html.Div([f"심각도{sev_icon}"], id={"type": "sort-btn", "index": "severity"}, className="cursor-pointer"), className="text-center col-15"),
            html.Th("도구", className="text-center col-10"),
            html.Th("고정 여부", className="text-center col-10"),
            html.Th("상세", className="text-center col-10")
        ]),
        className="sticky-header"
    )

    rows = []
    # enumerate를 사용하여 정렬된 최종 결과물에 1번부터 차례로 번호를 매김
    for idx, (_, row) in enumerate(df.iterrows(), start=1):
        sev_color = SEVERITY_COLORS.get(row['severity'], "#fff")
        rows.append(html.Tr([
            html.Td(str(idx), className="text-center font-bold text-dimmed"), # 넘버링 데이터 
            html.Td(row['vulnerability_id'], className="text-center"),
            html.Td(row['package_name'], className="text-center"),
            html.Td(row['class'], className="text-center font-bold"),
            html.Td(dmc.Badge(row['severity'], color=sev_color, variant="filled"), className="text-center"),
            html.Td(row['source'].upper(), className="text-center"),
            html.Td("Available" if row['is_fixed_available'] else "-", className="text-center"),
            html.Td(
                dmc.Center(
                    dmc.ActionIcon(DashIconify(icon="mdi:eye"),
                                   id={"type": "view-detail", "index": row['vulnerability_id'], "source": row['source']},
                                   variant="subtle")
                ),
                className="text-center"
            )
        ]))

    return dmc.Table(children=[header, html.Tbody(rows)], className="table-fixed", withColumnBorders=True, highlightOnHover=True), sort_state

# ================================================================
# [콜백] 미스매치 전용 테이블 렌더링
# 역할: Trivy와 Grype의 탐지 결과가 엇갈리는 항목만 추출해 '클래스' 포함 및 다중 정렬 표 제공.
# ================================================================
@callback(
    Output("mismatch-table-container", "children"),
    Output("mismatch-sort-state", "data"),
    Input("analysis-result-store", "data"),
    Input({"type": "mismatch-sort-btn", "index": ALL}, "n_clicks"),
    State("mismatch-sort-state", "data")
)
def update_mismatch_table(data, sort_clicks, sort_state):
    sort_state = sort_state or {"column": "id", "ascending": True}

    if not data or "vulnerabilities" not in data or not data["vulnerabilities"]:
        return dmc.Text("미스매치 분석 결과가 없습니다.", className="text-dimmed text-center", py=50), sort_state

    df = pd.DataFrame(data["vulnerabilities"])
    if df.empty:
        return dmc.Text("미스매치 분석 결과가 없습니다.", className="text-dimmed text-center", py=50), sort_state

    mismatch_vids = {m.get("vulnerability_id") for m in (data.get("mismatch_meta") or [])}
    if not mismatch_vids:
        dup_ids = df.groupby('vulnerability_id')['severity'].nunique()
        mismatch_vids = dup_ids[dup_ids > 1].index

    df_mis = df[df['vulnerability_id'].isin(mismatch_vids)]
    if df_mis.empty:
        return dmc.Text("분석된 미스매치 내역이 없습니다.", className="text-dimmed text-center", py=50), sort_state

    OS_PKG_TYPES = {'deb', 'dpkg', 'rpm', 'apk', 'apkg', 'portage', 'alpm', 'nix'}
    OS_DISTROS   = {'debian', 'ubuntu', 'alpine', 'centos', 'redhat', 'amazon',
                    'amzn', 'oracle', 'photon', 'suse', 'rocky', 'alma', 'fedora'}

    def classify_row(row):
        rc = str(row.get('result_class', '')).lower()
        rt = str(row.get('result_type', '')).lower()
        if 'secret' in rc or 'secret' in rt: return 'SECRET'
        if rc == 'os-pkgs': return 'OS'
        if rc == 'lang-pkgs': return 'APP'
        if rt in OS_PKG_TYPES or rt in OS_DISTROS: return 'OS'
        return 'APP'

    df_mis['class'] = df_mis.apply(classify_row, axis=1)

    if ctx.triggered_id and isinstance(ctx.triggered_id, dict) and ctx.triggered_id.get("type") == "mismatch-sort-btn":
        if sort_clicks and any(sort_clicks):
            clicked_col = ctx.triggered_id["index"]
            if sort_state.get("column") == clicked_col:
                sort_state["ascending"] = not sort_state.get("ascending", True)
            else:
                sort_state["column"] = clicked_col
                sort_state["ascending"] = True

    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    mismatch_data = []

    for vid, group in df_mis.groupby('vulnerability_id'):
        group = group.copy()
        group['_rank'] = group['severity'].map(severity_rank).fillna(5)
        group_sorted = group.sort_values(by='_rank')

        higher = group_sorted.iloc[0]
        lower = group_sorted.iloc[-1]

        mismatch_data.append({
            "vulnerability_id": vid,
            "class": higher['class'],
            "package_name": higher['package_name'],
            "high_severity": higher['severity'],
            "high_rank": higher['_rank'],
            "high_source": higher['source'],
            "low_severity": lower['severity'],
            "low_rank": lower['_rank'],
            "low_source": lower['source'],
            "is_fixed": higher['is_fixed_available'] or lower['is_fixed_available']
        })

    df_compiled = pd.DataFrame(mismatch_data)

    if sort_state.get("column") == "id":
        df_compiled = df_compiled.sort_values(by="vulnerability_id", ascending=sort_state["ascending"])
    elif sort_state.get("column") == "class":
        df_compiled = df_compiled.sort_values(by=["class", "vulnerability_id"], ascending=[sort_state["ascending"], True])
    elif sort_state.get("column") == "high_severity":
        df_compiled = df_compiled.sort_values(by=["high_rank", "vulnerability_id"], ascending=[sort_state["ascending"], True])
    elif sort_state.get("column") == "low_severity":
        df_compiled = df_compiled.sort_values(by=["low_rank", "vulnerability_id"], ascending=[sort_state["ascending"], True])

    id_icon = " ▲" if sort_state.get("column") == "id" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "id" else "")
    class_icon = " ▲" if sort_state.get("column") == "class" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "class" else "")
    high_icon = " ▲" if sort_state.get("column") == "high_severity" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "high_severity" else "")
    low_icon = " ▲" if sort_state.get("column") == "low_severity" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "low_severity" else "")

    header = html.Thead(
        html.Tr([
            html.Th("No.", className="text-center col-5"), # 넘버링 추가
            html.Th(html.Div([f"ID{id_icon}"], id={"type": "mismatch-sort-btn", "index": "id"}, className="cursor-pointer"), className="text-center col-15"),
            html.Th("패키지", className="text-center col-20"), # 25 -> 20 조절
            html.Th(html.Div([f"클래스{class_icon}"], id={"type": "mismatch-sort-btn", "index": "class"}, className="cursor-pointer"), className="text-center col-10"),
            html.Th(html.Div([f"심각도 (높음){high_icon}"], id={"type": "mismatch-sort-btn", "index": "high_severity"}, className="cursor-pointer"), className="text-center col-15"),
            html.Th(html.Div([f"심각도 (낮음){low_icon}"], id={"type": "mismatch-sort-btn", "index": "low_severity"}, className="cursor-pointer"), className="text-center col-15"),
            html.Th("고정 여부", className="text-center col-10"),
            html.Th("상세", className="text-center col-10")
        ]),
        className="sticky-header"
    )

    rows = []
    # enumerate를 사용하여 정렬된 최종 결과물에 1번부터 차례로 번호를 매김
    for idx, (_, row) in enumerate(df_compiled.iterrows(), start=1):
        high_element = dmc.Group([
            dmc.Badge(row['high_severity'], color=SEVERITY_COLORS.get(row['high_severity'], "#fff"), variant="filled"),
            dmc.Text(row['high_source'].upper(), size="xs", fw=600)
        ], gap="xs", justify="center")
        
        low_element = dmc.Group([
            dmc.Badge(row['low_severity'], color=SEVERITY_COLORS.get(row['low_severity'], "#fff"), variant="filled"),
            dmc.Text(row['low_source'].upper(), size="xs", fw=600)
        ], gap="xs", justify="center")

        rows.append(html.Tr([
            html.Td(str(idx), className="text-center font-bold text-dimmed"), # 넘버링 데이터
            html.Td(row['vulnerability_id'], className="text-center"),
            html.Td(row['package_name'], className="text-center"),
            html.Td(row['class'], className="text-center font-bold"),
            html.Td(high_element, className="text-center"),
            html.Td(low_element, className="text-center"),
            html.Td("Available" if row['is_fixed'] else "-", className="text-center"),
            html.Td(
                dmc.Center(
                    dmc.ActionIcon(DashIconify(icon="mdi:eye"), id={"type": "view-detail-mismatch", "index": row['vulnerability_id']}, variant="subtle")
                ),
                className="text-center"
            )
        ]))

    return dmc.Table(children=[header, html.Tbody(rows)], className="table-fixed", withColumnBorders=True, highlightOnHover=True), sort_state

# ================================================================
# [콜백] 취약점 상세 정보 모달 제어 및 언어 번역
# 역할: 눈동자 아이콘 클릭 시 취약점 세부 정보를 모달에 표시하고 영/한 번역을 전환합니다.
# ================================================================
@callback(
    Output("detail-modal", "opened"),
    Output("modal-content", "children"),
    Output("current-vuln-id", "data"),
    Input({"type": "view-detail", "index": ALL, "source": ALL}, "n_clicks"),
    Input({"type": "view-detail-mismatch", "index": ALL}, "n_clicks"),
    Input("lang-toggle", "value"),
    State("analysis-result-store", "data"),
    State("current-vuln-id", "data"),
    prevent_initial_call=True
)
def open_modal(n_clicks_main, n_clicks_mismatch, lang, data, current_id):
    if not ctx.triggered or not data or not data.get("vulnerabilities"):
        return no_update, no_update, no_update

    trigger_id = ctx.triggered_id
    triggered_val = ctx.triggered[0]['value']

    if isinstance(trigger_id, dict) and trigger_id.get("type") in ("view-detail", "view-detail-mismatch"):
        if not triggered_val:
            return False, no_update, no_update
        vuln_id = trigger_id["index"]
        is_open = True
    elif trigger_id == "lang-toggle":
        if current_id is None:
            return False, no_update, no_update
        vuln_id = current_id
        is_open = no_update
    else:
        return no_update, no_update, no_update

    v = next((item for item in data["vulnerabilities"] if item["vulnerability_id"] == vuln_id), None)
    if not v:
        return no_update, no_update, no_update

    description = v.get('description', 'No Description')
    title_val   = v.get('title', 'No Title')
    if lang == "KR":
        description = translate_to_korean(description)
        title_val   = translate_to_korean(title_val)
    display_desc = description

    fields = [
        ("Source", v['source']), ("Target", v.get('target','-')), ("Class", v.get('result_class','-')),
        ("Type", v.get('result_type','-')), ("Vulnerability ID", v['vulnerability_id']),
        ("Package", v['package_name']), ("Path", v.get('package_path','-')),
        ("Installed", v['installed_version']), ("Fixed", v.get('fixed_version','-')),
        ("Fix Available", str(v['is_fixed_available'])), ("Severity", v['severity']),
        ("Primary URL", html.A(v['primary_url'], href=v['primary_url'], target="_blank", className="text-accent") if v.get('primary_url') else "-"),
        ("Title", title_val)
    ]

    content = dmc.Stack([
        dmc.Text(f"상세 정보: {vuln_id}", fw=700, size="lg", className="text-accent"),
        dmc.Grid([
            dmc.GridCol([dmc.Text(label, fw=600, size="sm", className="text-dimmed"), dmc.Text(str(val), size="md")], span=4)
            for label, val in fields
        ]),
        dmc.Divider(label="Description"),
        dmc.Text(display_desc, size="sm", className="line-height-1-6")
    ], gap="md")

    return is_open, content, vuln_id

# ================================================================
# [콜백] 시스템 로그 출력
# 역할: 시스템 로그 데이터를 받아 실시간 스크롤 가능한 텍스트 뷰로 렌더링합니다.
# ================================================================
@callback(Output("system-log-container", "children"), Input("upload-log-store", "data"))
def render_logs(logs):
    if not logs: return dmc.Text("로그가 없습니다.", className="text-dimmed")
    return [html.Div(f"[{l['time']}] {l['content']}", className="mb-4") for l in logs]

# ================================================================
# [클라이언트 콜백] 로그인 상태 검증, UI 표시 및 로그아웃
# 역할: 브라우저 캐시에 저장된 Supabase 토큰을 이용해 보안 통신을 연계하고, 이메일 표시 등 사용자 UX를 제어합니다.
# ================================================================
app.clientside_callback(
    """
    function(pathname, scanClicks, pdfClicks) {
        const keys = Object.keys(window.localStorage)
            .filter(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
        for (const k of keys) {
            try {
                const v = JSON.parse(window.localStorage.getItem(k));
                if (v && v.access_token && v.expires_at) {
                    if (v.expires_at * 1000 > Date.now()) return v.access_token;
                    if (!window.location.pathname.startsWith('/login')) {
                        window.location.replace('/login/');
                    }
                    return null;
                }
            } catch (e) {}
        }
        return null;
    }
    """,
    Output("auth-token-store", "data"),
    Input("url", "pathname"),
    Input("btn-start-scan", "n_clicks"),
    Input("btn-export-pdf", "n_clicks")
)

app.clientside_callback(
    """
    function(pathname) {
        const keys = Object.keys(window.localStorage).filter(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
        for (const k of keys) {
            try {
                const v = JSON.parse(window.localStorage.getItem(k));
                if (v && v.user && v.user.email) return '👤 ' + v.user.email;
            } catch (e) {}
        }
        return '';
    }
    """,
    Output("user-email-display", "children"),
    Input("url", "pathname")
)

app.clientside_callback(
    """
    function(n_clicks) {
        if (!n_clicks) return window.dash_clientside.no_update;
        const keys = Object.keys(window.localStorage).filter(k => k.startsWith('sb-'));
        keys.forEach(k => window.localStorage.removeItem(k));
        window.location.href = '/login/';
        return '';
    }
    """,
    Output("_logout-dummy", "children"),
    Input("btn-logout", "n_clicks"),
    prevent_initial_call=True
)

# ================================================================
# [콜백] PDF 레포트 요청 및 다운로드 연동
# 역할: 백엔드 API에 요약 및 상세 두 개의 PDF 생성을 요청한 뒤,
#       클라이언트 자바스크립트로 전송하여 다운로드를 강제 실행시킵니다.
# ================================================================
@callback(
    Output("pdf-url-store", "data"),
    Output("upload-log-store", "data", allow_duplicate=True),
    Input("btn-export-pdf", "n_clicks"),
    State("analysis-result-store", "data"),
    State("upload-log-store", "data"),
    State("auth-token-store", "data"),
    prevent_initial_call=True
)
def request_pdf(n_clicks, analysis, current_logs, token):
    def _ts():
        return datetime.datetime.now().strftime("%H:%M:%S")
    if not n_clicks:
        return no_update, no_update
    logs = list(current_logs or [])
    if not analysis or not analysis.get("job_id"):
        logs.insert(0, {"time": _ts(), "content": "PDF 추출 실패 — 먼저 이미지 스캔을 실행해 주세요."})
        return no_update, logs
    job_id = analysis["job_id"]
    logs.insert(0, {"time": _ts(), "content": f"PDF 추출 요청 중 (요약 + 상세, job {job_id[:8]}...)"})

    headers = {"Authorization": f"Bearer {token}"} if token else {}

    try:
        resp = requests.post(
            f"{NODE_API_BASE}/pdf/all",
            json={"job_id": job_id},
            headers=headers,
            timeout=300,
        )
        data = _safe_json(resp)
        if not data.get("ok"):
            logs.insert(0, {"time": _ts(), "content": f"PDF 생성 실패: {data.get('error') or resp.status_code}"})
            return no_update, logs

        summary = data.get("summary") or {}
        detail  = data.get("detail")  or {}
        summary_url = summary.get("url")
        detail_url  = detail.get("url")

        if not summary_url or not detail_url:
            logs.insert(0, {"time": _ts(), "content": "PDF URL 누락 — 응답 형식 확인 필요"})
            return no_update, logs

        s_label = "캐시" if summary.get("cached") else "신규"
        d_label = "캐시" if detail.get("cached")  else "신규"
        logs.insert(0, {"time": _ts(), "content": f"PDF 2종 다운로드 시작 (요약: {s_label} / 상세: {d_label})"})

        # store 에 두 URL 저장 → clientside callback 이 순차 다운로드
        return {
            "summary_url": summary_url,
            "detail_url":  detail_url,
            "ts": _ts(),
        }, logs
    except Exception as e:
        logs.insert(0, {"time": _ts(), "content": f"PDF 통신 장애: {str(e)[:120]}"})
        return no_update, logs



# [PDF] clientside — store 에 두 URL 들어오면 순차 다운로드 트리거.
# 첫 PDF 는 location.assign 으로 즉시 다운로드.
# 두 번째 PDF 는 800ms 뒤 동적 <a> 태그 click 으로 다운로드.
# (브라우저 팝업 차단 회피 + 두 다운로드가 충돌 안 나도록)
app.clientside_callback(
    """
    function(payload) {
        if (!payload || !payload.summary_url || !payload.detail_url) {
            return window.dash_clientside.no_update;
        }
        try {
            // 1번째: 요약 PDF — 동적 <a> 태그 click 으로 다운로드 (페이지 이동 없음)
            var a1 = document.createElement('a');
            a1.href = payload.summary_url;
            a1.style.display = 'none';
            document.body.appendChild(a1);
            a1.click();
            document.body.removeChild(a1);

            // 2번째: 상세 PDF — 800ms 딜레이 후 다운로드 (브라우저 팝업 차단 회피)
            setTimeout(function() {
                var a2 = document.createElement('a');
                a2.href = payload.detail_url;
                a2.style.display = 'none';
                document.body.appendChild(a2);
                a2.click();
                document.body.removeChild(a2);
            }, 800);
        } catch (e) {
            console.error('PDF 다운로드 트리거 실패:', e);
        }
        return '';
    }
    """,
    Output("_pdf-trigger-dummy", "children"),
    Input("pdf-url-store", "data"),
    prevent_initial_call=True
)

if __name__ == "__main__":
    app.run(
        debug=False,
        host="0.0.0.0",
        port=int(os.environ.get("DASH_PORT", "8050")),
    )
