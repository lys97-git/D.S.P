/**
 * GET /results/:job_id
 *
 * ── 데이터 흐름 2단계 ───────────────────────────────────────────────────
 * 1단계: 스캐너(:8000) → POST /save → Supabase DB 적재 (save.js)
 * 2단계: 대시보드(:8050) → GET /results/:job_id → Node API 가 DB 에서
 *        결과를 읽어 대시보드 렌더링 규격으로 가공해 반환  ← 이 파일
 *
 * 즉, 대시보드가 스캐너의 직접 응답이 아니라 "DB 에 적재된 값"을 본다.
 * 이렇게 해야 scanner.py 의 v4 호환 어댑터에서 누락된 secret 항목까지
 * (security_filtered 테이블에 저장되어 있으므로) 화면에 정상 노출된다.
 *
 * ── 반환 규격 (front_end_v5_1.py 가 직접 사용) ──────────────────────────
 *   {
 *     job_id, status,
 *     summary:         { CRITICAL, HIGH, MEDIUM, LOW, UNKNOWN },
 *     vulnerabilities: [ {14개 필드}, ... ],   // Trivy + Grype + Secret 통합
 *     scan_job:        scan_jobs 원본 레코드
 *   }
 */

const express  = require('express');
const supabase = require('../db/index');

const router = express.Router();

// ── 헬퍼: severity 안전 정규화 (UPPERCASE) ──────────────────────
function normSev(s) {
  const u = String(s || 'UNKNOWN').toUpperCase();
  return ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'UNKNOWN'].includes(u) ? u : 'UNKNOWN';
}

// ── GET /results/:job_id ────────────────────────────────────────
router.get('/:job_id', async (req, res) => {
  const jobId = req.params.job_id;

  try {
    // DB 4개 테이블 동시 조회
    const [jobRes, appRes, grypeRes, secRes] = await Promise.all([
      supabase.from('scan_jobs').select('*').eq('id', jobId).maybeSingle(),
      supabase.from('application_filtered').select('*').eq('scan_job_id', jobId),
      supabase.from('grype_filtered').select('*').eq('scan_job_id', jobId),
      supabase.from('security_filtered').select('*').eq('scan_job_id', jobId),
    ]);

    if (jobRes.error) throw new Error(`scan_jobs 조회 실패: ${jobRes.error.message}`);
    if (!jobRes.data) {
      return res.status(404).json({ error: `해당 job_id 없음: ${jobId}` });
    }
    if (appRes.error)   throw new Error(`application_filtered 조회 실패: ${appRes.error.message}`);
    if (grypeRes.error) throw new Error(`grype_filtered 조회 실패: ${grypeRes.error.message}`);
    if (secRes.error)   throw new Error(`security_filtered 조회 실패: ${secRes.error.message}`);

    const vulnerabilities = [];
    const seen = new Set();   // vulnerability_id 중복 제거 (Grype 우선)

    // ── Grype → 14필드 스키마 ─────────────────────────────────
    for (const v of (grypeRes.data || [])) {
      const vid = v.vulnerability_id;
      if (!vid || seen.has(vid)) continue;
      seen.add(vid);
      vulnerabilities.push({
        vulnerability_id:   vid,
        package_name:       v.package_name || '',
        package_path:       v.install_path || '',
        installed_version:  '',
        fixed_version:      v.fix_version || '',
        severity:           normSev(v.severity),
        source:             'grype',
        is_fixed_available: !!v.is_fixed_available,
        target:             '',
        result_class:       '',
        result_type:        v.package_type || '',
        primary_url:        '',
        title:              '',
        description:        v.description || '',
      });
    }

    // ── Trivy → application_filtered ──────────────────────────
    for (const v of (appRes.data || [])) {
      const vid = v.vulnerability_id;
      if (!vid || seen.has(vid)) continue;
      seen.add(vid);
      vulnerabilities.push({
        vulnerability_id:   vid,
        package_name:       v.package_name || '',
        package_path:       v.package_path || '',
        installed_version:  v.installed_version || '',
        fixed_version:      v.fixed_version || '',
        severity:           normSev(v.severity),
        source:             'trivy',
        is_fixed_available: !!v.is_fixed_available,
        target:             v.target || '',
        result_class:       v.result_class || '',
        result_type:        v.result_type || '',
        primary_url:        v.primary_url || '',
        title:              v.title || '',
        description:        v.description || '',
      });
    }

    // ── Secret → security_filtered ────────────────────────────
    // result_class/result_type 에 'secret' 을 넣어 대시보드 분류 필터가
    // 이 행을 SECRET 으로 인식하도록 한다 (front_end_v5_1 classify_row).
    for (const s of (secRes.data || [])) {
      vulnerabilities.push({
        vulnerability_id:   s.rule_id || `secret-${s.id}`,
        package_name:       s.category || 'Secret',
        package_path:       s.created_by || '',
        installed_version:  '',
        fixed_version:      '',
        severity:           normSev(s.severity || 'HIGH'),
        source:             'trivy',
        is_fixed_available: false,
        target:             '',
        result_class:       'secret',
        result_type:        'secret',
        primary_url:        '',
        title:              s.rule_id || 'Secret',
        description:        s.match_text || '',
      });
    }

    // ── summary 집계 (도넛차트용) ─────────────────────────────
    const summary = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, UNKNOWN: 0 };
    for (const v of vulnerabilities) summary[v.severity]++;

    res.json({
      job_id:          jobId,
      status:          jobRes.data.status,
      summary,
      vulnerabilities,
      scan_job:        jobRes.data,
    });

    console.log(
      `[Results] job ${jobId} 조회 — trivy:${appRes.data?.length || 0} ` +
      `grype:${grypeRes.data?.length || 0} secret:${secRes.data?.length || 0} ` +
      `→ 통합 ${vulnerabilities.length}건`
    );

  } catch (e) {
    console.error('[Results] 조회 실패:', e.message);
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
