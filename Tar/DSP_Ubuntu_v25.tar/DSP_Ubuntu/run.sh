#!/usr/bin/env bash
# ================================================================
#  DSP  통합 실행 스크립트 (Ubuntu 24.04 LTS)
#  실행: chmod +x run.sh && ./run.sh
#
#  STEP 1  포트 정리
#  STEP 2  기술스택 설치 / 확인
#  STEP 3  서비스 시작 (Python 8000 / Node.js 3000 / Dash 8050)
#  STEP 4  자가점검
#  STEP 5  실행 모드 선택
#
#  부가 명령:
#    ./run.sh stop     - 모든 서비스 종료만
#    ./run.sh status   - 현재 상태 확인만
# ================================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$ROOT/logs"
PID_DIR="$ROOT/.pids"
mkdir -p "$LOG_DIR" "$PID_DIR"

# --- 컬러 ---
RED=$'\033[0;31m'; GRN=$'\033[0;32m'; YLW=$'\033[0;33m'
CYN=$'\033[0;36m'; GRY=$'\033[0;90m'; NC=$'\033[0m'

ok()  { printf "  | ${GRN}[OK]${NC}  %s\n" "$1"; }
ng()  { printf "  | ${RED}[NG]${NC}  %s\n" "$1"; }
inf() { printf "  |       %s\n" "$1"; }
war() { printf "  | ${YLW}[!!]${NC}  %s\n" "$1"; }

banner() {
  clear
  printf "${CYN}"
  echo "  +========================================================+"
  echo "  |        DSP  통합 실행기  (Ubuntu 24.04 LTS)            |"
  echo "  |   Python(8000)  .  Node.js(3000)  .  Dash(8050)        |"
  echo "  +========================================================+"
  printf "${NC}\n"
}

# --- 포트 점유 PID 종료 ---
kill_port() {
  local port=$1
  if command -v lsof >/dev/null 2>&1; then
    local pids
    pids=$(lsof -ti:"$port" 2>/dev/null || true)
    [ -n "${pids:-}" ] && kill -9 $pids 2>/dev/null || true
  elif command -v fuser >/dev/null 2>&1; then
    fuser -k "${port}/tcp" 2>/dev/null || true
  fi
}

# --- TCP 포트 응답 확인 ---
test_port() {
  (echo > "/dev/tcp/127.0.0.1/$1") >/dev/null 2>&1
}

# ================================================================
# STEP 1  포트 정리
# ================================================================
step_cleanup() {
  printf "  ${GRY}+-- STEP 1/3  포트 정리 ----------------------------${NC}\n"
  inf "기존 node / python 프로세스 종료..."
  pkill -f "uvicorn python.scanner" 2>/dev/null || true
  pkill -f "node.*src/index.js"     2>/dev/null || true
  pkill -f "front_end_v9_4.py"        2>/dev/null || true
  for p in 3000 8000 8050; do kill_port "$p"; done
  sleep 1
  inf "포트 3000 / 8000 / 8050 해제 완료"
  printf "  ${GRY}+--------------------------------------------------${NC}\n\n"
}

# ================================================================
# STEP 2  기술스택 설치 / 확인
# ================================================================
SUDO=""
if [ "$EUID" -ne 0 ]; then SUDO="sudo"; fi

apt_updated=false
apt_update_once() {
  $apt_updated && return
  $SUDO apt-get update -qq
  apt_updated=true
}

step_setup() {
  printf "  ${GRY}+-- STEP 2/3  기술스택 설치 / 확인 ----------------${NC}\n"

  # --- Node.js (NodeSource LTS) ---
  if ! command -v node >/dev/null 2>&1; then
    war "[Node.js]  없음 -> 설치 중 (NodeSource LTS)..."
    apt_update_once
    $SUDO apt-get install -y -qq curl ca-certificates >/dev/null
    curl -fsSL https://deb.nodesource.com/setup_lts.x | $SUDO -E bash - >/dev/null 2>&1
    $SUDO apt-get install -y -qq nodejs >/dev/null
  fi
  ok "[Node.js]   $(node --version 2>/dev/null || echo 'FAIL')"

  # --- Python 3 ---
  if ! command -v python3 >/dev/null 2>&1; then
    war "[Python]   없음 -> 설치 중..."
    apt_update_once
    $SUDO apt-get install -y -qq python3 python3-pip python3-venv >/dev/null
  fi
  ok "[Python]    $(python3 --version 2>/dev/null || echo 'FAIL')"

  # --- python3-pip (바닐라 Ubuntu 24.04 대응) ---
  # 24.04 는 python3 는 기본 포함이지만 python3-pip 는 별도. 위 블록의
  # `command -v python3` 가 통과해 버려 pip 가 누락되는 케이스를 잡는다.
  # ensurepip 도 Debian/Ubuntu 에선 비활성이라 apt 로 직접 설치해야 한다.
  if ! python3 -m pip --version >/dev/null 2>&1; then
    war "[pip]      python3-pip 미설치 -> apt 로 설치 중..."
    apt_update_once
    $SUDO apt-get install -y -qq python3-pip python3-venv >/dev/null
  fi
  ok "[pip]       $(python3 -m pip --version 2>/dev/null | awk '{print $1,$2}' || echo 'FAIL')"

  # --- Trivy (공식 APT 저장소) ---
  if ! command -v trivy >/dev/null 2>&1; then
    war "[Trivy]    없음 -> 설치 중..."
    apt_update_once
    $SUDO apt-get install -y -qq wget gnupg lsb-release >/dev/null
    wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key \
      | $SUDO gpg --dearmor -o /usr/share/keyrings/trivy.gpg
    echo "deb [signed-by=/usr/share/keyrings/trivy.gpg] https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main" \
      | $SUDO tee /etc/apt/sources.list.d/trivy.list >/dev/null
    $SUDO apt-get update -qq
    $SUDO apt-get install -y -qq trivy >/dev/null
  fi
  ok "[Trivy]     $(trivy --version 2>/dev/null | head -1 || echo 'FAIL')"

  # --- Grype (anchore 공식 install.sh) ---
  if ! command -v grype >/dev/null 2>&1; then
    war "[Grype]    없음 -> 설치 중..."
    curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh \
      | $SUDO sh -s -- -b /usr/local/bin >/dev/null 2>&1
  fi
  if command -v grype >/dev/null 2>&1; then ok "[Grype]     설치됨"; else ng "[Grype]     설치 실패"; fi

  # --- npm 패키지 ---
  if [ ! -d "$ROOT/server/node_modules" ]; then
    war "[npm]      node_modules 없음 -> 설치 중..."
    (cd "$ROOT/server" && npm install --silent >/dev/null 2>&1)
  fi
  ok "[npm]       패키지 준비됨"

  # --- pip 패키지 (Ubuntu 24.04: PEP 668 -> --break-system-packages 필요) ---
  # FastAPI 공식 권장: "fastapi[standard]" 한 줄로 uvicorn[standard] +
  # python-multipart + httpx 가 자동으로 함께 설치됩니다.
  PROBE='import fastapi, uvicorn, requests, dash, dash_mantine_components, dash_iconify, pandas, plotly, deep_translator, supabase, weasyprint'
  PKGS='fastapi[standard] requests dash dash-mantine-components dash-iconify pandas plotly deep-translator supabase weasyprint'

  # --- WeasyPrint 시스템 의존성 (Cairo / Pango / GDK-PixBuf 등) ---
  # WeasyPrint 는 pip 만으로 안 됨 — apt 로 GTK 관련 라이브러리 + 한글 폰트 설치.
  # fonts-noto-cjk 는 한글 PDF 가 깨지지 않게 폴백 폰트로 보장.
  WP_DEPS='libpango-1.0-0 libpangoft2-1.0-0 libcairo2 libcairo-gobject2 libgdk-pixbuf-2.0-0 libffi-dev shared-mime-info fonts-noto-cjk'
  if ! dpkg -s libpango-1.0-0 >/dev/null 2>&1 || ! dpkg -s fonts-noto-cjk >/dev/null 2>&1; then
    war "[GTK]      WeasyPrint 시스템 의존성 (Cairo/Pango/Noto CJK) 설치 중..."
    apt_update_once
    $SUDO apt-get install -y -qq $WP_DEPS 2>&1 | sed 's/^/  |       /' || \
      ng "[GTK]      apt 설치 실패 — 수동: sudo apt install $WP_DEPS"
  fi
  ok "[GTK]       WeasyPrint 시스템 의존성 확인됨"

  # ensurepip 안전망 + pip 자체 업그레이드
  python3 -m ensurepip --upgrade >/dev/null 2>&1 || true
  python3 -m pip install --break-system-packages --upgrade pip >/dev/null 2>&1 || \
    python3 -m pip install --user --upgrade pip >/dev/null 2>&1 || true

  if ! python3 -c "$PROBE" 2>/dev/null; then
    war "[pip]      패키지 없음 -> 설치 중 (수 분 소요)..."
    python3 -m pip install --break-system-packages --upgrade $PKGS 2>&1 | sed 's/^/  |       /' \
    || python3 -m pip install --user --upgrade $PKGS 2>&1 | sed 's/^/  |       /'
    if python3 -c "$PROBE" 2>/dev/null; then
      ok "[pip]       패키지 검증 성공"
    else
      ng "[pip]       패키지 검증 실패 - 수동 설치 필요:"
      inf "  python3 -m pip install --break-system-packages $PKGS"
    fi
  else
    ok "[pip]       모든 패키지 이미 설치됨"
  fi

  # --- .env ---
  if [ ! -f "$ROOT/server/.env" ]; then
    [ -f "$ROOT/server/.env.example" ] && cp "$ROOT/server/.env.example" "$ROOT/server/.env"
    war "[.env]     생성됨 - Supabase 키를 입력하세요!"
  else
    ok "[.env]      확인됨"
  fi

  mkdir -p "$ROOT/server/uploads"
  ok "[uploads]   디렉터리 준비됨"

  printf "  ${GRY}+--------------------------------------------------${NC}\n\n"
}

# ================================================================
# STEP 3  서비스 시작 (백그라운드 nohup, PID 저장)
# ================================================================
# 프론트엔드 진입점: frontend/front_end_v9_4.py (이전 버전 모두 폐기, v4 원본만 보존)
frontend_entry() {
  if [ -f "$ROOT/frontend/front_end_v9_4.py" ]; then
    echo "frontend/front_end_v9_4.py"
  else
    echo "front_end_v9_4.py"
  fi
}

step_start() {
  printf "  ${GRY}+-- STEP 3/3  서비스 시작 -------------------------${NC}\n"

  local scanner_work="$ROOT/python/.work"
  mkdir -p "$scanner_work"
  local fe; fe=$(frontend_entry)

  inf "[1/3] Python 스캐너     (port 8000) 시작..."
  ( cd "$ROOT" \
    && SCANNER_WORK_DIR="$scanner_work" \
       PYTHONUTF8=1 PYTHONIOENCODING=utf-8 \
       nohup python3 -m uvicorn python.scanner:app --host 0.0.0.0 --port 8000 \
       >"$LOG_DIR/scanner.log" 2>&1 & echo $! >"$PID_DIR/scanner.pid" )
  sleep 2

  inf "[2/3] Node.js API 서버  (port 3000) 시작..."
  ( cd "$ROOT/server" \
    && nohup npm start \
       >"$LOG_DIR/node.log" 2>&1 & echo $! >"$PID_DIR/node.pid" )
  sleep 2

  inf "[3/3] Dash 대시보드     (port 8050) 시작..."
  ( cd "$ROOT" \
    && PYTHONUTF8=1 PYTHONIOENCODING=utf-8 \
       nohup python3 "$fe" \
       >"$LOG_DIR/dash.log" 2>&1 & echo $! >"$PID_DIR/dash.pid" )

  printf "  ${GRY}+--------------------------------------------------${NC}\n\n"
}

# ================================================================
# STEP 4  자가점검
# ================================================================
step_check() {
  printf "  ${GRY}+-- STEP 4  자가점검 (5초 대기...) ----------------${NC}\n"
  sleep 5

  local all_ok=true
  check() {
    if eval "$2"; then ok "$1"; else ng "$1"; all_ok=false; fi
  }

  check "[도구] Trivy                " "command -v trivy >/dev/null"
  check "[도구] Grype                " "command -v grype >/dev/null"
  check "[서버] Python 스캐너 :8000  " "test_port 8000"
  check "[서버] Node.js API   :3000  " "test_port 3000"
  check "[서버] Dash 대시보드 :8050  " "test_port 8050"
  check "[파일] server/.env          " "[ -f '$ROOT/server/.env' ]"
  check "[파일] server/node_modules  " "[ -d '$ROOT/server/node_modules' ]"
  check "[파일] python/scanner.py    " "[ -f '$ROOT/python/scanner.py' ]"
  check "[파일] frontend             " "[ -f '$ROOT/frontend/front_end_v9_4.py' ]"
  check "[폴더] server/uploads/      " "[ -d '$ROOT/server/uploads' ]"

  echo "  |"
  if $all_ok; then
    printf "  | ${GRN}[ALL OK]${NC} 모든 항목 정상입니다.\n"
  else
    printf "  | ${YLW}[!!]${NC} [NG] 항목을 확인하세요. 서비스가 뜨는 중일 수 있습니다.\n"
    printf "  |       로그: %s/{scanner,node,dash}.log\n" "$LOG_DIR"
  fi
  printf "  ${GRY}+--------------------------------------------------${NC}\n\n"
}

# ================================================================
# 서비스 전체 종료
# ================================================================
stop_all() {
  printf "${YLW}  서비스 종료 중...${NC}\n"
  for f in "$PID_DIR"/*.pid; do
    [ -f "$f" ] || continue
    local pid; pid=$(cat "$f" 2>/dev/null || true)
    if [ -n "${pid:-}" ] && kill -0 "$pid" 2>/dev/null; then
      kill -TERM "$pid" 2>/dev/null || true
      sleep 0.3
      kill -KILL "$pid" 2>/dev/null || true
    fi
    rm -f "$f"
  done
  pkill -f "uvicorn python.scanner" 2>/dev/null || true
  pkill -f "node.*src/index.js"     2>/dev/null || true
  pkill -f "front_end_v9_4.py"        2>/dev/null || true
  for p in 3000 8000 8050; do kill_port "$p"; done
  printf "${GRN}  서비스 종료 완료.${NC}\n"
}

# ================================================================
# 상태 바
# ================================================================
status_bar() {
  local t; t=$(date +%H:%M:%S)
  local s1 s2 s3
  test_port 8000 && s1="${GRN}(*) ON ${NC}" || s1="${RED}( ) OFF${NC}"
  test_port 3000 && s2="${GRN}(*) ON ${NC}" || s2="${RED}( ) OFF${NC}"
  test_port 8050 && s3="${GRN}(*) ON ${NC}" || s3="${RED}( ) OFF${NC}"
  printf "  ${GRY}+-- 서비스 상태  %s ----------------------------${NC}\n" "$t"
  printf "  | Python  스캐너  :8000  %b\n" "$s1"
  printf "  | Node.js API     :3000  %b\n" "$s2"
  printf "  | Dash   대시보드 :8050  %b\n" "$s3"
  printf "  ${GRY}+--------------------------------------------------${NC}\n"
}

# ================================================================
# 메뉴
# ================================================================
menu() {
  printf "${CYN}"
  echo "  +========================================================+"
  echo "  | DSP 실행 중                                            |"
  echo "  | 대시보드 : http://localhost:8050                       |"
  echo "  | 로그인   : http://localhost:8050/login (자동 redirect) |"
  echo "  | API      : http://localhost:3000/health                |"
  echo "  | 스캐너   : http://localhost:8000/health                |"
  echo "  +========================================================+"
  printf "${NC}\n"
  echo "  실행 모드를 선택하세요:"
  echo
  echo "    [1]  모니터링 유지     - 이 창에서 서비스 상태 실시간 확인"
  echo "    [2]  이 창만 닫기      - 백그라운드에서 서비스 계속 실행"
  echo "    [3]  모든 서비스 종료  - 서비스 + 이 창 모두 종료"
  echo
  while true; do
    read -rp "  선택 (1 / 2 / 3): " choice
    case "$choice" in
      1)
        echo
        echo "  [모니터링]  Enter = 상태 갱신 / q = 종료 메뉴"
        echo
        while true; do
          status_bar
          read -rp "  > Enter 갱신 . q 종료메뉴 : " key
          [[ "$key" =~ ^[qQ]$ ]] && break
        done
        echo
        read -rp "  서비스를 종료하시겠습니까? (y / n): " yn
        if [[ "$yn" =~ ^[yY]$ ]]; then stop_all; return; fi
        echo; menu; return
        ;;
      2)
        echo
        printf "${GRN}  서비스는 백그라운드에서 계속 실행됩니다.${NC}\n"
        printf "${GRY}  로그: %s/{scanner,node,dash}.log${NC}\n" "$LOG_DIR"
        printf "${GRY}  종료하려면: ./run.sh stop${NC}\n"
        return
        ;;
      3)
        stop_all
        return
        ;;
      *)
        printf "${YLW}  1, 2, 3 중 하나를 입력하세요.${NC}\n"
        ;;
    esac
  done
}

# ================================================================
# 인자 처리 (./run.sh stop / status)
# ================================================================
case "${1:-}" in
  stop)   stop_all; exit 0 ;;
  status) status_bar; exit 0 ;;
esac

# ================================================================
# 메인
# ================================================================
banner
step_cleanup

banner
step_setup

banner
step_start

banner
step_check

# 대시보드 자동 오픈 — v4 계열은 자체 webbrowser 호출 코드가 없으므로
# 런처가 기본 브라우저로 http://localhost:8050 을 띄웁니다.
# 헤드리스 서버(브라우저 없음)에서는 조용히 실패하므로 안전합니다.
DASH_URL="http://localhost:8050"
open_browser() {
  if ! test_port 8050; then
    printf "  ${YLW}Dash 미기동${NC} — 수동 접속: %s\n" "$DASH_URL"
    return
  fi
  # xdg-open 이 silent fail 하는 케이스(기본 브라우저 미설정 등)를 위해
  # 여러 브라우저 명령을 순서대로 시도. 처음 성공하는 것 사용.
  for cmd in xdg-open sensible-browser firefox google-chrome chromium-browser chromium epiphany-browser; do
    if command -v "$cmd" >/dev/null 2>&1; then
      ( "$cmd" "$DASH_URL" >/dev/null 2>&1 & )
      printf "  ${GRN}대시보드 자동 오픈 (%s):${NC} %s\n" "$cmd" "$DASH_URL"
      return
    fi
  done
  printf "  ${YLW}브라우저 도구 없음${NC} — 수동 접속: %s\n" "$DASH_URL"
}
sleep 1
open_browser

menu
