/**
 * POST /save
 *
 * python/scanner.py 의 /scan 엔드포인트가 스캔 완료 후 호출합니다.
 * multipart/form-data 형식으로 payload JSON + 원시 JSON 파일들을 전송합니다.
 *
 * ── 파일 저장 정책 ──────────────────────────────────────────────────────
 * DB(Supabase)에 이미 저장되는 정제 데이터와 중복을 피하기 위해
 * 스캐너 원시 출력(RAW)만 디스크에 저장합니다.
 *
 *   저장 O (RAW — DB에 없는 원본):
 *     grype.json   — Grype 원시 JSON 출력 전체
 *     trivy.json   — Trivy 원시 JSON 출력 전체
 *
 *   저장 X (이미 DB에 있는 정제 데이터):
 *     result_grype_vulnerabilities.json  → grype_filtered 테이블
 *     result_trivy_vulnerabilities.json  → application_filtered 테이블
 *     result_secrets.json                → security_filtered 테이블
 *     result_scan_report.json            → scan_reports 테이블
 *     result_cross_analysis.json         → scan_reports 테이블
 *
 * ── 저장 경로 ──────────────────────────────────────────────────────────
 *   server/uploads/{user_id}/{job_id}_{YYYYMMDD_HHMMSS}/
 *     ├── grype.json
 *     └── trivy.json
 *
 *   같은 이미지를 여러 번 분석해도 타임스탬프로 구분됩니다.
 *   나중에 계정관리 도입 시 user_id → 실제 계정명으로 교체합니다.
 *
 * ── Supabase 스키마 (실제 검증 완료, 2026-05) ───────────────────────────
 *   - application_filtered.is_fixed_available: GENERATED 컬럼 → INSERT 불가
 *   - grype_filtered.is_fixed_available:       GENERATED 컬럼 → INSERT 불가
 *   - application_filtered.severity: CHECK enum {CRITICAL/HIGH/MEDIUM/LOW/UNKNOWN}
 *   - grype_filtered.severity:       CHECK 제약 없음 (자유 텍스트)
 *   - security_filtered.severity:    CHECK 제약 없음 (자유 텍스트)
 *   - application_filtered.source:   CHECK enum {'trivy' only}
 *   - grype_filtered.source:         CHECK enum {'grype' only}
 *   - security_filtered.source:      CHECK enum {'trivy' only}
 *   - scan_jobs.status CHECK: {pending/uploaded/running/completed/failed/cancelled}
 *   - scan_jobs.trivy_status/grype_status CHECK: {pending/running/completed/failed/skipped}
 *   - scan_jobs.file_type CHECK: {image_tar/dockerfile/sbom}
 *   - user_id FK → profiles.id (profiles.id FK → auth.users.id). auth 미도입 시 NULL 권장
 *   - job_id: scanner.py 가 생성하지 않으므로 Node.js 에서 UUID 생성
 */

const express        = require('express');
const multer         = require('multer');
const fs             = require('fs');
const path           = require('path');
const { v4: uuidv4 } = require('uuid');
const supabase       = require('../db/index');

const router     = express.Router();
const CHUNK_SIZE = 500;

// RAW 파일만 디스크에 저장 (grype / trivy)
const RAW_FILES = new Set(['grype.json', 'trivy.json']);

// 업로드 루트: server/uploads/
const UPLOAD_BASE = path.resolve(__dirname, '../../uploads');

// multipart/form-data 파싱 — 메모리에 받은 뒤 직접 경로 결정 후 저장
const upload = multer({ storage: multer.memoryStorage() });

// ── 헬퍼: 타임스탬프 생성 (YYYYMMDD_HHMMSS) ────────────────────
function makeTimestamp() {
  const d   = new Date();
  const pad = n => String(n).padStart(2, '0');
  return (
    `${d.getFullYear()}` +
    `${pad(d.getMonth() + 1)}` +
    `${pad(d.getDate())}_` +
    `${pad(d.getHours())}` +
    `${pad(d.getMinutes())}` +
    `${pad(d.getSeconds())}`
  );
}

// ── 헬퍼: user_id → 파일시스템 안전 문자열 ──────────────────────
function safeId(id) {
  return String(id || 'anonymous').replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 64);
}

// ── 헬퍼: Supabase 청크 삽입 ────────────────────────────────────
async function insertChunked(table, rows) {
  for (let i = 0; i < rows.length; i += CHUNK_SIZE) {
    const chunk = rows.slice(i, i + CHUNK_SIZE);
    const { error } = await supabase.from(table).insert(chunk);
    if (error) {
      console.error(`[Save] ${table} INSERT 실패: ${error.message}`);
      console.error(`[Save] ${table} 첫 행 샘플:`, JSON.stringify(chunk[0]).slice(0, 200));
    }
  }
}

// (참고) toGrypeSev() 함수는 제거됨.
// 이유: grype_filtered.severity 컬럼에 CHECK 제약이 없어 변환 불필요.
//       application_filtered (UPPERCASE) 와 형식을 통일하기 위해 UPPERCASE 그대로 사용.

// ── POST /save ──────────────────────────────────────────────────
router.post('/', upload.any(), async (req, res) => {

  // ── 0. payload 파싱 ──────────────────────────────────────────
  const payloadStr = req.body.payload;
  if (!payloadStr) {
    return res.status(400).json({ error: 'payload 필드 필요' });
  }

  let payload;
  try {
    payload = JSON.parse(payloadStr);
  } catch (e) {
    return res.status(400).json({ error: `payload JSON 파싱 실패: ${e.message}` });
  }

  const scanJob      = payload.scan_job      || {};
  const scanReport   = payload.scan_report   || {};
  const filteredData = payload.filtered_data || {};

  // job_id + 타임스탬프 — 동일 이미지 반복 분석 시에도 고유한 경로 보장
  const job_id    = uuidv4();
  const timestamp = makeTimestamp();
  const now       = new Date().toISOString();

  // ── 1. RAW 파일 디스크 저장 ──────────────────────────────────
  // uploads/{user_id}/{job_id}_{YYYYMMDD_HHMMSS}/grype.json 등
  const userId  = safeId(scanJob.user_id);
  const dirName = `${job_id}_${timestamp}`;
  const scanDir = path.join(UPLOAD_BASE, userId, dirName);

  // 디렉터리 생성 (없으면 자동 생성)
  fs.mkdirSync(scanDir, { recursive: true });

  const savedFiles = [];
  for (const file of (req.files || [])) {
    const fname = path.basename(file.originalname); // 경로 인젝션 방지
    if (!RAW_FILES.has(fname)) continue;            // RAW 3종만 저장

    const dest = path.join(scanDir, fname);
    fs.writeFileSync(dest, file.buffer);
    savedFiles.push(fname);
    console.log(`[Save] RAW 저장: ${dest} (${(file.size / 1024).toFixed(1)} KB)`);
  }

  // DB에 기록할 상대 경로 (OS 구분자 → 슬래시 통일)
  const uploadPath = `${userId}/${dirName}`.replace(/\\/g, '/');

  // ── 즉시 응답 — 디스크 저장 완료 단계에서 스캐너에게 201 반환
  // DB INSERT 는 백그라운드로 처리 (Supabase 응답 지연이 클라이언트 타임아웃에 영향 X)
  res.status(201).json({
    ok: true,
    job_id,
    upload_path: uploadPath,
    message: 'Files saved. DB processing in background.',
  });
  console.log(`[Save] 201 응답 전송 — job: ${job_id} | DB 작업은 백그라운드 진행 중...`);

  // ── 백그라운드 DB 작업 (응답 후 비동기 처리) ────────────────
  ;(async () => {
  try {
    // ── 2. scan_jobs 레코드 생성 ──────────────────────────────
    const { error: jobErr } = await supabase.from('scan_jobs').insert({
      id:                    job_id,
      scan_name:             scanJob.scan_name    || null,  // scanner.py 가 보내는 값 보존
      file_name:             scanJob.file_name    || '',
      file_type:             scanJob.file_type    || 'image_tar',
      image_name:            scanJob.image_name   || null,
      upload_path:           uploadPath,           // RAW 저장 경로 기록
      status:                'running',
      trivy_status:          scanJob.trivy_status || 'pending',
      grype_status:          scanJob.grype_status || 'pending',
      started_at:            scanJob.started_at   || now,
      total_vulnerabilities: 0,
      critical_count:        0,
      high_count:            0,
      medium_count:          0,
      low_count:             0,
      unknown_count:         0,
      // user_id 는 profiles → auth.users 외래키 제약이 있고 v4 의 'admin' 같은
      // 임의 문자열은 uuid 가 아니므로 INSERT 에서 제외. Supabase auth 도입 후 추가.
    });
    if (jobErr) {
      console.warn('[Save] (BG) scan_jobs insert 실패:', jobErr.message);
      return; // 응답은 이미 보냈음 — 백그라운드 종료
    }

    // ── 3. Trivy 취약점 → application_filtered ────────────────
    // ※ is_fixed_available: GENERATED ALWAYS (fixed_version IS NOT NULL) → INSERT 제외
    const trivyVulns = filteredData.trivy_vulnerabilities || [];
    if (trivyVulns.length > 0) {
      const rows = trivyVulns
        .filter(v => v.vulnerability_id && v.package_name)
        .map(v => ({
          scan_job_id:       job_id,
          // 실제 컬럼명은 'source' (이전 'scanner' 키는 PGRST204 차단)
          // CHECK 제약: 'trivy' 만 허용. v.source 가 'trivy' 가 아니면 fallback
          source:            v.source === 'trivy' ? v.source : 'trivy',
          target:            v.target            || null,
          result_class:      v.result_class      || null,
          result_type:       v.result_type       || null,
          vulnerability_id:  v.vulnerability_id,
          package_name:      v.package_name,
          package_path:      v.package_path      || null,
          installed_version: v.installed_version || null,
          fixed_version:     v.fixed_version     || null,
          severity:          v.severity          || 'UNKNOWN',  // CHECK: CRITICAL/HIGH/MEDIUM/LOW/UNKNOWN
          title:             v.title             || null,
          description:       v.description       || null,
          primary_url:       v.primary_url       || null,
        }));
      await insertChunked('application_filtered', rows);
    }

    // ── 4. Grype 취약점 → grype_filtered ──────────────────────
    // ※ is_fixed_available: GENERATED ALWAYS (state = 'fixed') → INSERT 제외
    // ※ severity: CHECK 제약 없음 → UPPERCASE 그대로 사용 (application_filtered 와 통일)
    const grypeVulns = filteredData.grype_vulnerabilities || [];
    if (grypeVulns.length > 0) {
      const rows = grypeVulns
        .filter(v => v.vulnerability_id && v.package_name)
        .map(v => ({
          scan_job_id:              job_id,
          // 실제 컬럼명은 'source' (이전 'scanner' 키는 PGRST204 차단)
          // CHECK 제약: 'grype' 만 허용
          source:                   v.source === 'grype' ? v.source : 'grype',
          vulnerability_id:         v.vulnerability_id,
          data_source:              v.data_source              || null,
          severity:                 v.severity                 || 'UNKNOWN',  // CHECK 없음, UPPERCASE 통일
          description:              v.description              || null,
          fix_version:              v.fix_version              || null,
          state:                    v.state                    || null,
          risk:                     v.risk != null ? String(v.risk) : null,
          artifact_id:              v.artifact_id              || null,
          package_name:             v.package_name,
          package_type:             v.package_type             || null,
          install_path:             v.install_path             || null,
          related_vulnerability_id: v.related_vulnerability_id || null,
        }));
      await insertChunked('grype_filtered', rows);
    }

    // ── 5. 시크릿 → security_filtered ─────────────────────────
    const secrets = filteredData.secrets || [];
    if (secrets.length > 0) {
      const rows = secrets
        .filter(s => s.rule_id)
        .map(s => ({
          scan_job_id:  job_id,
          // 실제 컬럼명은 'source' (CHECK: 'trivy' 만)
          source:       s.source === 'trivy' ? s.source : 'trivy',
          rule_id:      s.rule_id,
          category:     s.category     || null,
          severity:     s.severity     || 'HIGH',  // CHECK 없음
          match_text:   s.match_text   || null,
          layer_digest: s.layer_digest || null,
          diff_id:      s.diff_id      || null,
          created_by:   s.created_by   || null,
        }));
      await insertChunked('security_filtered', rows);
    }

    // ── 6. 교차 분석 → scan_reports ───────────────────────────
    if (scanReport.total_count != null) {
      const { error: reportErr } = await supabase.from('scan_reports').insert({
        scan_jobs_id:   job_id,
        image_tag:      scanReport.image_tag      || scanJob.file_name || null,
        total_count:    scanReport.total_count    || 0,
        common_count:   scanReport.common_count   || 0,
        grype_only:     scanReport.grype_only     || 0,
        trivy_only:     scanReport.trivy_only     || 0,
        mismatch_count: scanReport.mismatch_count || 0,
        // 참고: scan_reports.scan_job_id 외래키는 실제로 비활성 (검증됨)
        //       scan_jobs_id 컬럼이 정상 작동하는 외래키이므로 그쪽만 사용
      });
      if (reportErr) console.warn('[Save] scan_reports insert 실패:', reportErr.message);
    }

    // ── 7. scan_jobs 카운트 + 상태 최종 업데이트 ──────────────
    const { error: updErr } = await supabase.from('scan_jobs').update({
      status:                scanJob.status                || 'completed',
      total_vulnerabilities: scanJob.total_vulnerabilities || 0,
      critical_count:        scanJob.critical_count        || 0,
      high_count:            scanJob.high_count            || 0,
      medium_count:          scanJob.medium_count          || 0,
      low_count:             scanJob.low_count             || 0,
      unknown_count:         scanJob.unknown_count         || 0,
      finished_at:           scanJob.finished_at           || now,
      updated_at:            now,
    }).eq('id', job_id);
    if (updErr) console.warn('[Save] scan_jobs update 실패:', updErr.message);

    console.log(
      `[Save] (BG) DB 작업 완료 — job: ${job_id} | path: uploads/${uploadPath} | ` +
      `raw파일: [${savedFiles.join(', ')}] | ` +
      `trivy: ${trivyVulns.length} | grype: ${grypeVulns.length} | secrets: ${secrets.length}`
    );

  } catch (e) {
    console.error('[Save] (BG) 예외:', e.message);
    await supabase.from('scan_jobs').update({
      status:        'failed',
      error_message: e.message.slice(0, 500),
      updated_at:    now,
    }).eq('id', job_id).catch(() => {});
  }
  })(); // 백그라운드 IIFE 종료
});

module.exports = router;
