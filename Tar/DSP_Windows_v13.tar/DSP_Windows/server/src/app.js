const express = require('express');
const cors = require('cors');
const path = require('path');

const scanRouter     = require('./routes/scan');
const filesRouter    = require('./routes/files');
const saveRouter     = require('./routes/save');
const resultsRouter  = require('./routes/results');
const pdfRouter      = require('./routes/pdf');
const { ALLOWED_ORIGINS } = require('./config');

const app = express();

const isProd = process.env.NODE_ENV === 'production';

// ── CORS ──────────────────────────────────────────────────
// 프론트엔드는 Dash(:8050) 단독 — Node 는 API 전용 서버이다.
// (구 client/ 정적 HTML 프론트엔드는 폐기됨)
if (!isProd) {
  app.use(cors({
    origin: ALLOWED_ORIGINS,
    methods: ['GET', 'POST', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  }));
}

app.use(express.json());

// 업로드된 파일 정적 제공
app.use('/files', express.static(path.join(__dirname, '../uploads')));

// ── 라우터 ────────────────────────────────────────────────
app.use('/scan',      scanRouter);
app.use('/save',      saveRouter);
app.use('/results',   resultsRouter);
app.use('/pdf',       pdfRouter);
app.use('/files-manage', filesRouter);

// ── 헬스체크 ──────────────────────────────────────────────
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'DSP' });
});

// ── 404 핸들러 (API 전용) ────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: '요청한 경로를 찾을 수 없습니다.' });
});

// ── 글로벌 에러 핸들러 ────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('[Error]', err);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

module.exports = app;
