# ================================================================
# DSP Integrated Security Dashboard — v7 (v6 + 로그인 통합)
#
# v7 변경 요약 (v6 대비):
#   [LOGIN-INTEGRATION] ① /login 정적 라우트 (Flask) — frontend/login/* 서빙
#   [LOGIN-INTEGRATION] ② 인증 게이트 — index_string 의 <script> 가 진입 시
#                          localStorage 의 Supabase 토큰을 검사 → 미인증이면
#                          즉시 /login 으로 redirect
#   [LOGIN-INTEGRATION] ③ 헤더에 사용자 이메일 + 로그아웃 버튼 추가
#   [LOGIN-INTEGRATION] ④ 사용자 이메일 표시 clientside callback
#   [LOGIN-INTEGRATION] ⑤ 로그아웃 clientside callback
#
# 기능적 동작은 v6 와 동일. 위 5곳만 추가됨.
# 보안 주의: 이 게이트는 클라이언트사이드(UX 게이트). 토큰 위조 우회 가능.
# 실제 보호는 Node API(:3000) 에서 Supabase JWT 검증 추가 필요 (별도 작업).
# ================================================================

import subprocess
import sys
import os                                    # [LOGIN-INTEGRATION] Flask 정적서빙 경로 구성용
import json
import datetime
import base64
import io

# ================================================================
# [BOOTSTRAP] 사용자 라이브러리 import 이전에 의존성 확보 (PEP 668 대응)
# ----------------------------------------------------------------
# v5_1 까지의 자동설치는 (a) pandas 등 import 뒤에 위치해서 누락 시
# ModuleNotFoundError 로 즉사, (b) `pip install` 에 PEP 668 우회 플래그가
# 없어 Ubuntu 24.04 같은 externally-managed 환경에선 항상 실패했다.
# v7 부터: ① import 이전에 _REQUIRED 보장, ② --break-system-packages →
# --user → 기본 의 폴백 체인으로 환경별 차이를 흡수한다.
# ================================================================
_REQUIRED = {
    "requests": "requests",
    "pandas": "pandas",
    "plotly": "plotly",
    "dash": "dash",
    "dash_mantine_components": "dash-mantine-components",
    "dash_iconify": "dash-iconify",
    "deep_translator": "deep-translator",
    "flask": "flask",                        # Dash 의존성이지만 명시 (안전망)
}

def _ensure_pkg(pkg):
    """PEP 668 환경 우회 + 일반 환경 호환. 성공하면 True 반환."""
    for extra in (["--break-system-packages"], ["--user"], []):
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-q", pkg, *extra],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            continue
    return False

for _mod, _pkg in _REQUIRED.items():
    try:
        __import__(_mod)
    except ImportError:
        if not _ensure_pkg(_pkg):
            print(f"[BOOTSTRAP] '{_pkg}' 자동설치 실패 — 수동 설치 필요:", file=sys.stderr)
            print(f"  python3 -m pip install --break-system-packages {_pkg}", file=sys.stderr)

# ── 위 블록이 보장한 뒤 사용자 라이브러리 import ────────────────────
import requests
import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html, Input, Output, State, callback, ALL, no_update, ctx
import dash_mantine_components as dmc
from dash_iconify import DashIconify
from flask import send_from_directory, redirect  # [LOGIN-INTEGRATION] /login 라우트 + redirect
from deep_translator import GoogleTranslator

_translation_cache = {}

def translate_to_korean(text):
    if not text or not str(text).strip():
        return text
    if text in _translation_cache:
        return _translation_cache[text]
    try:
        translated = GoogleTranslator(source="auto", target="ko").translate(str(text)[:4900])
        result = translated or text
    except Exception:
        result = text
    _translation_cache[text] = result
    return result

app = dash.Dash(__name__, suppress_callback_exceptions=True)

# ================================================================
# [LOGIN-INTEGRATION] ① 로그인 페이지 정적 서빙 (Flask 라우트)
# ----------------------------------------------------------------
# Dash 의 underlying Flask 서버(app.server) 에 라우트를 직접 등록한다.
#   GET /login              → frontend/login/index.html
#   GET /login/<filename>   → frontend/login/* (app.js, styles.css, config.js, ...)
#
# 왜 frontend/login/ 별도 폴더?
#   Dash 는 assets/ 폴더의 모든 .css / .js 를 "메인 페이지" 에 자동 인젝션한다.
#   로그인용 styles.css / app.js 가 메인 대시보드에도 로드되면 충돌하므로,
#   assets 가 아닌 별도 폴더에 두고 Flask 라우트로 명시적으로 서빙한다.
# ================================================================
server = app.server  # underlying Flask
_LOGIN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'login')

# /login (슬래시 없음) → /login/ 으로 강제 리다이렉트.
# 이유: index.html 의 <script type="module" src="./app.js"> 가 ./app.js 를
# 현재 URL 기준 상대경로로 해석하는데, URL 이 /login (파일로 취급) 이면
# ./ 가 / 로 풀려서 브라우저가 /app.js 를 요청 → 우리 라우트 X →
# Dash catch-all 이 HTML 응답 → MIME 'text/html' 로 모듈 로드 차단.
# /login/ (디렉터리) 이면 ./ 가 /login/ 으로 풀려서 /login/app.js 요청 → OK.
@server.route('/login')
def _serve_login_redirect():
    return redirect('/login/', code=302)

@server.route('/login/')
def _serve_login_index():
    return send_from_directory(_LOGIN_DIR, 'index.html')

@server.route('/login/<path:filename>')
def _serve_login_assets(filename):
    return send_from_directory(_LOGIN_DIR, filename)

# ================================================================
# [LOGIN-INTEGRATION] ② 인증 게이트 (index_string 인젝션)
# ----------------------------------------------------------------
# Dash 의 HTML 템플릿에 <script> 를 끼워 넣어, 모든 페이지 로드 직후
# (Dash 앱 부트스트랩 전) localStorage 에서 Supabase 세션 토큰을 검사한다.
# 토큰 없음/만료 → 즉시 /login 으로 replace (back 버튼으로도 못 돌아옴)
# 토큰 유효     → Dash 정상 로드
#
# Supabase JS v2 의 localStorage 키 패턴: sb-<projectid>-auth-token
# projectid 는 anon key 마다 다르므로 sb-*-auth-token 패턴 매칭으로 처리.
#
# ⚠ 보안 한계:
#   이건 UX 게이트(첫 진입 차단)이지 진짜 인증 방어가 아니다. 토큰 위조나
#   localStorage 조작으로 우회 가능. 실제 보호가 필요한 데이터/액션은
#   Node API(:3000) 라우트에서 Supabase JWT 검증을 추가해야 한다.
# ================================================================
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <script>
            (function () {
                // /login 으로 시작하는 모든 경로는 게이트 통과 (무한 redirect 방지)
                // /login, /login/, /login/app.js 등 모두 매칭
                if (window.location.pathname.startsWith('/login')) return;
                // Supabase JS v2 localStorage 키 탐색
                const keys = Object.keys(window.localStorage)
                    .filter(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
                let authed = false;
                for (const k of keys) {
                    try {
                        const v = JSON.parse(window.localStorage.getItem(k));
                        // access_token 존재 + expires_at(초 단위) 가 현재 이후면 유효
                        if (v && v.access_token && v.expires_at && v.expires_at * 1000 > Date.now()) {
                            authed = true;
                            break;
                        }
                    } catch (e) { /* 손상된 항목은 무시 */ }
                }
                if (!authed) {
                    window.location.replace('/login/');
                }
            })();
        </script>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# [디자인 및 색상 정의]
THEME_BG_MAIN = "#0a192f"
THEME_BG_PAPER = "#112240"
THEME_BORDER = "#233554"
THEME_TEXT_ACCENT = "#64ffda"
THEME_TEXT_MAIN = "#ccd6f6"

SEVERITY_COLORS = {
    "CRITICAL": "#ff4d4d",
    "HIGH": "#ff944d",
    "MEDIUM": "#ffd11a",
    "LOW": "#4da6ff",
    "UNKNOWN": "#a6a6a6"
}

# [레이아웃]
app.layout = dmc.MantineProvider(
    forceColorScheme="dark",
    children=[
        html.Div(
            style={"backgroundColor": THEME_BG_MAIN, "minHeight": "100vh", "color": THEME_TEXT_MAIN, "padding": "20px"},
            children=[
                dmc.LoadingOverlay(id="loading-overlay", visible=False, overlayProps={"blur": 2}, zIndex=1000),

                # 헤더
                dmc.Group(justify="space-between", mb="xl", children=[
                    dmc.Group([
                        DashIconify(icon="material-symbols:shield-lock", width=40, color=THEME_TEXT_ACCENT),
                        dmc.Title("DSP Integrated Security Dashboard", order=1, style={"color": THEME_TEXT_ACCENT}),
                        # [추가 5] 대시보드 설명 버튼 (물음표)
                        # dmc 2.7.0: ActionIcon 은 title prop 미지원 → 제거.
                        # (네이티브 툴팁이 필요하면 dmc.Tooltip 으로 감싸야 함)
                        dmc.ActionIcon(
                            DashIconify(icon="tabler:help", width=24),
                            id="btn-help", size="lg", variant="outline", color="teal", radius="xl"
                        )
                    ]),
                    # [LOGIN-INTEGRATION] ③ 헤더 우측에 사용자 이메일 + PDF + 로그아웃 묶음
                    dmc.Group([
                        dmc.Text(id="user-email-display", size="sm", c=THEME_TEXT_ACCENT, fw=600),
                        # [추가 2] PDF 추출 버튼 (기능은 향후 API 연동을 위해 UI만 생성)
                        dmc.Button("PDF 추출", id="btn-export-pdf", variant="outline", color="teal", leftSection=DashIconify(icon="tabler:file-download")),
                        # [LOGIN-INTEGRATION] 로그아웃 버튼
                        dmc.Button("로그아웃", id="btn-logout", variant="subtle", color="red", leftSection=DashIconify(icon="tabler:logout"))
                    ], gap="sm")
                ]),

                dmc.Grid(children=[
                    # 왼쪽: 업로드 및 로그
                    dmc.GridCol(span=4, children=[
                        dmc.Paper(withBorder=True, p="md", radius="md", mb="md", style={"backgroundColor": THEME_BG_PAPER, "borderColor": THEME_BORDER}, children=[
                            dmc.Text("이미지 분석 설정", fw=700, mb="md", style={"color": THEME_TEXT_ACCENT}),
                            dcc.Loading(id="loading-upload", type="circle", color=THEME_TEXT_ACCENT, children=[
                                dcc.Upload(
                                    id='upload-data',
                                    accept=".tar", # [추가 4] tar 확장자만 업로드 가능하도록 제한
                                    children=html.Div([
                                        DashIconify(id="upload-icon", icon="tabler:upload", width=30),
                                        dmc.Text("파일을 드래그하세요 (.tar 전용)", id="upload-text")
                                    ], style={"textAlign": "center"}),
                                    style={'width': '100%', 'height': '100px', 'borderWidth': '2px', 'borderStyle': 'dashed', 'borderColor': THEME_BORDER, 'borderRadius': '8px', 'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center', 'cursor': 'pointer'}
                                )
                            ]),
                            dmc.Space(h=15),
                            dmc.Button("스캔 시작", id="btn-start-scan", fullWidth=True, color="teal")
                        ]),
                        # 실시간 시스템 로그
                        dmc.Paper(withBorder=True, p="md", radius="md", style={"backgroundColor": THEME_BG_PAPER, "borderColor": THEME_BORDER}, children=[
                            dmc.Text("시스템 진행 로그", fw=700, mb="xs", style={"color": THEME_TEXT_ACCENT}),
                            html.Div(id="system-log-container", style={"height": "200px", "overflowY": "auto", "fontSize": "12px"})
                        ])
                    ]),

                    # 오른쪽: 원형 그래프
                    dmc.GridCol(span=8, children=[
                        dmc.Paper(withBorder=True, p="md", radius="md", style={"backgroundColor": THEME_BG_PAPER, "borderColor": THEME_BORDER}, children=[
                            dmc.Group(justify="space-between", mb="md", children=[
                                dmc.Text("취약점 분포 (심각도)", fw=700, style={"color": THEME_TEXT_ACCENT}),
                                dmc.SegmentedControl(
                                    id="pie-tool-filter-toggle",
                                    # [추가 3] 미스매치 필터 추가
                                    data=[{"label": "전체", "value": "ALL"}, {"label": "Trivy", "value": "trivy"}, {"label": "Grype", "value": "grype"}, {"label": "미스매치", "value": "mismatch"}],
                                    value="ALL",
                                    size="sm"
                                )
                            ]),
                            html.Div(
                                style={"position": "relative", "width": "100%", "height": "100%"},
                                children=[
                                    dcc.Graph(id="severity-pie-chart", style={"height": "100%"}, config={'displaylogo': False, 'modeBarButtonsToRemove': ['toImage']}),
                                    html.Div(
                                        id="pie-center-text",
                                        title="클릭하여 전체 심각도 보기 (필터 해제)",
                                        style={
                                            "position": "absolute", "top": "45%", "left": "50%",
                                            "transform": "translate(-50%, -50%)", "cursor": "pointer",
                                            "textAlign": "center", "zIndex": 10,
                                            "display": "flex", "flexDirection": "column", "justifyContent": "center", "alignItems": "center",
                                            "width": "130px", "height": "130px", "borderRadius": "50%"
                                        }
                                    )
                                ]
                            )
                        ])
                    ])
                ]),

                dmc.Space(h="xl"),

                # 결과 테이블 및 다중 필터 섹션
                dmc.Paper(withBorder=True, p="md", radius="md", style={"backgroundColor": THEME_BG_PAPER, "borderColor": THEME_BORDER}, children=[
                    dmc.Group(justify="space-between", mb="md", children=[
                        dmc.Text("취약점 상세 리스트", fw=700, style={"color": THEME_TEXT_ACCENT}),
                        dmc.Group([
                            dmc.SegmentedControl(
                                id="tool-filter-toggle",
                                # [추가 3] 미스매치 필터 추가
                                data=[{"label": "전체", "value": "ALL"}, {"label": "Trivy", "value": "trivy"}, {"label": "Grype", "value": "grype"}, {"label": "미스매치", "value": "mismatch"}],
                                value="ALL"
                            ),
                            dmc.SegmentedControl(
                                id="class-filter-toggle",
                                data=[{"label": "전체", "value": "ALL"}, {"label": "APP", "value": "APP"}, {"label": "OS", "value": "OS"}, {"label": "Secret", "value": "SECRET"}],
                                value="ALL"
                            )
                        ], gap="sm")
                    ]),
                    html.Div(id="vulnerability-table-container", style={"maxHeight": "500px", "overflowY": "auto"})
                ]),

                # [LOGIN-INTEGRATION] dcc.Location — 헤더 이메일 표시 콜백의 트리거.
                # refresh=False : 클라이언트사이드 라우팅(페이지 리로드 없음)
                dcc.Location(id="url", refresh=False),

                dcc.Store(id="analysis-result-store"),
                dcc.Store(id="upload-log-store"),
                dcc.Store(id="selected-severity-store", data=None),
                dcc.Store(id="current-vuln-id", data=None),
                dcc.Store(id="sort-state", data={"column": "id", "ascending": True}),
                dcc.Store(id="scan-status-store", data="idle"),
                dcc.Store(id="pdf-url-store"),                          # [PDF] Node /pdf 응답 URL 저장 — clientside 가 받아 다운로드 트리거

                # [LOGIN-INTEGRATION] 로그아웃 콜백용 더미 Output (보이지 않음)
                html.Div(id="_logout-dummy", style={"display": "none"}),
                html.Div(id="_pdf-trigger-dummy", style={"display": "none"}),  # [PDF] clientside 다운로드 트리거 더미 Output

                # 상세 분석 모달
                dmc.Modal(
                    id="detail-modal", title="취약점 상세 분석 결과", size="xl",
                    children=[
                        dmc.Group(justify="flex-end", mb="sm", children=[
                            dmc.SegmentedControl(id="lang-toggle", data=[{"label": "English", "value": "EN"}, {"label": "한국어", "value": "KR"}], value="EN")
                        ]),
                        html.Div(id="modal-content")
                    ],
                    styles={"content": {"backgroundColor": THEME_BG_PAPER}}
                ),

                # [추가 5] 도움말 모달
                dmc.Modal(
                    id="help-modal", title="💡 대시보드 사용 가이드", size="lg", centered=True,
                    children=[
                        dmc.Stack([
                            dmc.Text("1. 이미지 분석 설정", fw=700, c=THEME_TEXT_ACCENT),
                            dmc.Text("• 확장자가 .tar 인 Docker 이미지 파일만 업로드할 수 있습니다.", size="sm"),
                            dmc.Text("• 파일을 드래그 앤 드롭한 후, '스캔 시작' 버튼을 눌러야 분석이 진행됩니다.", size="sm"),

                            dmc.Divider(),
                            dmc.Text("2. 취약점 분포 및 필터링", fw=700, c=THEME_TEXT_ACCENT),
                            dmc.Text("• Trivy, Grype 개별 탐지 결과 또는 두 도구의 심각도가 엇갈린 '미스매치' 결과를 선택해 볼 수 있습니다.", size="sm"),
                            dmc.Text("• 원형 차트의 조각(예: CRITICAL)을 클릭하면 하단 테이블이 해당 위험도로 자동 필터링됩니다. 정중앙 숫자를 누르면 필터가 해제됩니다.", size="sm"),

                            dmc.Divider(),
                            dmc.Text("3. 상세 리스트 확인", fw=700, c=THEME_TEXT_ACCENT),
                            dmc.Text("• 테이블 우측의 눈동자 아이콘을 클릭하면 취약점의 세부 설명과 해결 패치 버전을 확인할 수 있습니다.", size="sm"),
                            dmc.Text("• 상세보기 창에서 한국어/영어 번역 기능을 지원합니다.", size="sm")
                        ])
                    ],
                    styles={"content": {"backgroundColor": THEME_BG_PAPER, "color": THEME_TEXT_MAIN}}
                )
            ]
        )
    ]
)

# [콜백 함수]

@callback(
    Output("upload-text", "children"),
    Input("upload-data", "contents"),
    State("upload-data", "filename"),
    prevent_initial_call=True
)
def show_uploaded_file(contents, filename):
    if contents and filename:
        return f"업로드됨: {filename}  —  '스캔 시작' 클릭"
    return no_update

# [개선 1] 파일 안 넣고 스캔 눌렀을 때 무한 로딩 및 스캐너 동작 방지
@callback(
    Output("upload-log-store", "data", allow_duplicate=True),
    Output("scan-status-store", "data", allow_duplicate=True),
    Output("loading-overlay", "visible", allow_duplicate=True),
    Output("btn-start-scan", "disabled", allow_duplicate=True),
    Input("btn-start-scan", "n_clicks"),
    State("upload-data", "contents"),
    State("upload-data", "filename"),
    State("upload-log-store", "data"),
    prevent_initial_call=True
)
def trigger_scan_log(n_clicks, contents, filename, current_logs):
    if not n_clicks or not contents:
        return no_update, no_update, no_update, no_update

    logs = current_logs or []

    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"파일 업로드 확인 완료: {filename}"})
    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "API 서버로 전송 준비 중..."})
    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "분석 요청 전송 중 (Target: Trivy & Grype)..."})

    return logs, "trigger", True, True

@callback(
    Output("analysis-result-store", "data"),
    Output("upload-log-store", "data"),
    Output("scan-status-store", "data"),
    Output("loading-overlay", "visible"),
    Output("btn-start-scan", "disabled"),
    Input("scan-status-store", "data"),
    State("upload-data", "contents"),
    State("upload-data", "filename"),
    State("upload-log-store", "data"),
    prevent_initial_call=True
)
def perform_scan(status, contents, filename, current_logs):
    if status != "trigger" or not contents:
        return no_update, no_update, no_update, no_update, no_update

    logs = current_logs or []
    try:
        content_type, content_string = contents.split(',')
        decoded = base64.b64decode(content_string)

        response = requests.post(
            "http://127.0.0.1:8000/scan",
            files={'file': (filename, io.BytesIO(decoded), 'application/x-tar')},
            data={'user_id': 'admin'},
            timeout=1800
        )

        if response.status_code == 200:
            scan_data = response.json()
            logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "스캐너 분석 완료 — DB 적재 확인 중..."})

            job_id = scan_data.get("job_id")
            final_data = scan_data
            if job_id:
                try:
                    db_resp = requests.get(f"http://127.0.0.1:3000/results/{job_id}", timeout=60)
                    if db_resp.status_code == 200:
                        final_data = db_resp.json()
                        vuln_cnt = len(final_data.get("vulnerabilities", []))
                        logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"DB 결과 조회 완료 (API 경유 · 취약점 {vuln_cnt}건)"})
                    else:
                        logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"DB 조회 실패({db_resp.status_code}) — 스캐너 응답으로 대체"})
                except Exception as db_err:
                    logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"DB 조회 통신 장애 — 스캐너 응답으로 대체: {str(db_err)[:80]}"})
            else:
                logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": "job_id 미수신 — 스캐너 응답을 그대로 사용"})

            return final_data, logs, "idle", False, False
        else:
            logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"서버 에러 발생: {response.status_code}"})
            return no_update, logs, "idle", False, False
    except Exception as e:
        logs.insert(0, {"time": datetime.datetime.now().strftime("%H:%M:%S"), "content": f"통신 장애 발생: {str(e)}"})
        return no_update, logs, "idle", False, False

@callback(
    Output("severity-pie-chart", "figure"),
    Output("pie-center-text", "children"),
    Input("analysis-result-store", "data"),
    Input("pie-tool-filter-toggle", "value")
)
def update_pie_chart(data, tool_filter):
    def get_empty_state(msg="데이터 없음"):
        fig = px.pie(title=msg, hole=0.4).update_layout(paper_bgcolor="rgba(0,0,0,0)", font_color="white")
        fig.update_traces(domain=dict(x=[0, 1], y=[0, 1]))
        center = [html.Div("0건", style={"fontSize": "24px", "fontWeight": "bold", "color": THEME_TEXT_ACCENT})]
        return fig, center

    if not data or "vulnerabilities" not in data or not data["vulnerabilities"]:
        return get_empty_state()

    df = pd.DataFrame(data["vulnerabilities"])
    if df.empty or 'severity' not in df.columns:
        return get_empty_state()

    # [추가 3] 미스매치 처리: 백엔드(results.js)가 동봉한 mismatch_meta 의 vulnerability_id
    # 집합으로 필터링. (구버전은 groupby().nunique()>1 로 계산했지만 /results 응답이
    # 이미 dedup 된 상태라 항상 0건이었음. 2026-05 DB 리팩토링으로 mismatch 테이블이
    # 신설되며 results.js 가 mismatch_meta 동봉 → 진짜 동작하게 됨.)
    if tool_filter == "mismatch":
        mismatch_vids = {m.get("vulnerability_id") for m in (data.get("mismatch_meta") or [])}
        df = df[df['vulnerability_id'].isin(mismatch_vids)]
        if df.empty: return get_empty_state("미스매치 결과 없음")
    elif tool_filter != "ALL":
        df = df[df['source'] == tool_filter]
        if df.empty: return get_empty_state(f"{tool_filter.upper()} 결과 없음")

    total_count = len(df)
    counts = df['severity'].value_counts().reset_index()
    counts.columns = ['severity', 'count']

    fig = px.pie(
        counts, values='count', names='severity',
        color='severity', color_discrete_map=SEVERITY_COLORS,
        hole=0.4
    )

    fig.update_traces(
        domain=dict(x=[0, 1], y=[0, 1]),
        hovertemplate="<b>%{label}</b><br>탐지 수: %{value}건",
        textinfo='label+percent'
    )

    fig.update_layout(
        showlegend=True,
        legend=dict(orientation="h", x=0.5, xanchor="center", y=-0.05),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=THEME_TEXT_MAIN),
        margin=dict(t=5, b=5, l=5, r=5)
    )

    center_html = [
        html.Div(f"{total_count}건", style={"fontSize": "24px", "fontWeight": "bold", "color": THEME_TEXT_ACCENT})
    ]

    return fig, center_html

@callback(
    Output("selected-severity-store", "data"),
    Input("severity-pie-chart", "clickData"),
    Input("pie-center-text", "n_clicks"),
    prevent_initial_call=True
)
def manage_severity_filter(click_data, center_clicks):
    trigger = ctx.triggered_id
    if trigger == "pie-center-text":
        return None
    elif trigger == "severity-pie-chart" and click_data:
        return click_data['points'][0]['label']
    return no_update

@callback(
    Output("vulnerability-table-container", "children"),
    Output("sort-state", "data"),
    Input("analysis-result-store", "data"),
    Input("tool-filter-toggle", "value"),
    Input("class-filter-toggle", "value"),
    Input("selected-severity-store", "data"),
    Input({"type": "sort-btn", "index": ALL}, "n_clicks"),
    State("sort-state", "data")
)
def update_table(data, tool_filter, class_filter, selected_severity, sort_clicks, sort_state):
    sort_state = sort_state or {"column": "id", "ascending": True}

    if not data or "vulnerabilities" not in data or not data["vulnerabilities"]:
        return dmc.Text("분석 결과가 없습니다.", c="dimmed", ta="center", py=50), sort_state

    df = pd.DataFrame(data["vulnerabilities"])
    if df.empty:
        return dmc.Text("분석 결과가 없습니다.", c="dimmed", ta="center", py=50), sort_state

    if ctx.triggered_id and isinstance(ctx.triggered_id, dict) and ctx.triggered_id.get("type") == "sort-btn":
        if sort_clicks and any(sort_clicks):
            clicked_col = ctx.triggered_id["index"]
            if sort_state.get("column") == clicked_col:
                sort_state["ascending"] = not sort_state.get("ascending", True)
            else:
                sort_state["column"] = clicked_col
                sort_state["ascending"] = True

    if selected_severity:
        df = df[df['severity'] == selected_severity]

    # [추가 3] 미스매치 필터링 로직 (테이블 용) — 도넛과 동일하게 mismatch_meta 사용
    if tool_filter == "mismatch":
        mismatch_vids = {m.get("vulnerability_id") for m in (data.get("mismatch_meta") or [])}
        df = df[df['vulnerability_id'].isin(mismatch_vids)]
    elif tool_filter != "ALL":
        df = df[df['source'] == tool_filter]

    if class_filter != "ALL":
        OS_PKG_TYPES = {'deb', 'dpkg', 'rpm', 'apk', 'apkg', 'portage', 'alpm', 'nix'}
        OS_DISTROS   = {'debian', 'ubuntu', 'alpine', 'centos', 'redhat', 'amazon',
                        'amzn', 'oracle', 'photon', 'suse', 'rocky', 'alma', 'fedora'}

        def classify_row(row):
            rc = str(row.get('result_class', '')).lower()
            rt = str(row.get('result_type', '')).lower()
            if 'secret' in rc or 'secret' in rt:
                return 'SECRET'
            if rc == 'os-pkgs':
                return 'OS'
            if rc == 'lang-pkgs':
                return 'APP'
            if rt in OS_PKG_TYPES or rt in OS_DISTROS:
                return 'OS'
            return 'APP'

        df['_computed_category'] = df.apply(classify_row, axis=1)
        df = df[df['_computed_category'] == class_filter]

    if sort_state.get("column") == "severity" and "severity" in df.columns:
        severity_map = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
        df['_sev_rank'] = df['severity'].map(severity_map).fillna(5)
        df = df.sort_values(by=["_sev_rank", "vulnerability_id"], ascending=[sort_state["ascending"], True])
        df = df.drop(columns=['_sev_rank'])
    elif "vulnerability_id" in df.columns:
        df = df.sort_values(by="vulnerability_id", ascending=sort_state["ascending"])

    id_icon = " ▲" if sort_state.get("column") == "id" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "id" else "")
    sev_icon = " ▲" if sort_state.get("column") == "severity" and sort_state["ascending"] else (" ▼" if sort_state.get("column") == "severity" else "")

    header = html.Thead(
        html.Tr([
            html.Th(
                html.Div([f"ID{id_icon}"], id={"type": "sort-btn", "index": "id"},
                         style={"cursor": "pointer", "userSelect": "none", "color": THEME_TEXT_ACCENT}),
                style={"textAlign": "center"}
            ),
            html.Th("패키지", style={"textAlign": "center"}),
            html.Th(
                html.Div([f"심각도{sev_icon}"], id={"type": "sort-btn", "index": "severity"},
                         style={"cursor": "pointer", "userSelect": "none", "color": THEME_TEXT_ACCENT}),
                style={"textAlign": "center"}
            ),
            html.Th("도구", style={"textAlign": "center"}),
            html.Th("고정 여부", style={"textAlign": "center"}),
            html.Th("상세", style={"textAlign": "center"})
        ]),
        style={"position": "sticky", "top": 0, "backgroundColor": THEME_BG_PAPER, "zIndex": 10}
    )

    rows = []
    for _, row in df.iterrows():
        sev_color = SEVERITY_COLORS.get(row['severity'], "#fff")
        rows.append(html.Tr([
            html.Td(row['vulnerability_id'], style={"textAlign": "center"}),
            html.Td(row['package_name'], style={"textAlign": "center"}),
            html.Td(dmc.Badge(row['severity'], color=sev_color, variant="filled"), style={"textAlign": "center"}),
            html.Td(row['source'].upper(), style={"textAlign": "center"}),
            html.Td("Available" if row['is_fixed_available'] else "-", style={"textAlign": "center"}),
            html.Td(
                dmc.Center(
                    dmc.ActionIcon(DashIconify(icon="mdi:eye"), id={"type": "view-detail", "index": row['vulnerability_id']}, variant="subtle")
                ),
                style={"textAlign": "center"}
            )
        ]))

    table = dmc.Table(children=[header, html.Tbody(rows)], withColumnBorders=True, highlightOnHover=True)
    return table, sort_state

@callback(
    Output("detail-modal", "opened"),
    Output("modal-content", "children"),
    Output("current-vuln-id", "data"),
    Input({"type": "view-detail", "index": ALL}, "n_clicks"),
    Input("lang-toggle", "value"),
    State("analysis-result-store", "data"),
    State("current-vuln-id", "data"),
    prevent_initial_call=True
)
def open_modal(n_clicks, lang, data, current_id):
    if not ctx.triggered or not data or not data.get("vulnerabilities"):
        return no_update, no_update, no_update

    trigger_id = ctx.triggered_id
    triggered_val = ctx.triggered[0]['value']

    if isinstance(trigger_id, dict) and trigger_id.get("type") == "view-detail":
        if not triggered_val:
            return False, no_update, no_update
        vuln_id = trigger_id["index"]
        is_open = True
    elif trigger_id == "lang-toggle":
        if current_id is None:
            return False, no_update, no_update
        vuln_id = current_id
        is_open = no_update
    else:
        return no_update, no_update, no_update

    v = next((item for item in data["vulnerabilities"] if item["vulnerability_id"] == vuln_id), None)
    if not v:
        return no_update, no_update, no_update

    description = v.get('description', 'No Description')
    title_val   = v.get('title', 'No Title')
    if lang == "KR":
        description = translate_to_korean(description)
        title_val   = translate_to_korean(title_val)
    display_desc = description

    fields = [
        ("Source", v['source']), ("Target", v.get('target','-')), ("Class", v.get('result_class','-')),
        ("Type", v.get('result_type','-')), ("Vulnerability ID", v['vulnerability_id']),
        ("Package", v['package_name']), ("Path", v.get('package_path','-')),
        ("Installed", v['installed_version']), ("Fixed", v.get('fixed_version','-')),
        ("Fix Available", str(v['is_fixed_available'])), ("Severity", v['severity']),
        ("Primary URL", html.A(v['primary_url'], href=v['primary_url'], target="_blank", style={"color": THEME_TEXT_ACCENT}) if v.get('primary_url') else "-"),
        ("Title", title_val)
    ]

    content = dmc.Stack([
        dmc.Text(f"상세 정보: {vuln_id}", fw=700, size="lg", style={"color": THEME_TEXT_ACCENT}),
        dmc.Grid([
            dmc.GridCol([dmc.Text(label, fw=600, size="sm", c="dimmed"), dmc.Text(str(val), size="md")], span=4)
            for label, val in fields
        ]),
        dmc.Divider(label="Description"),
        dmc.Text(display_desc, size="sm", style={"lineHeight": "1.6"})
    ], gap="md")

    return is_open, content, vuln_id

# [추가 5] 도움말 모달 작동 콜백
@callback(
    Output("help-modal", "opened"),
    Input("btn-help", "n_clicks"),
    prevent_initial_call=True
)
def open_help(n_clicks):
    if n_clicks:
        return True
    return no_update

@callback(Output("system-log-container", "children"), Input("upload-log-store", "data"))
def render_logs(logs):
    if not logs: return dmc.Text("로그가 없습니다.", c="dimmed")
    return [html.Div(f"[{l['time']}] {l['content']}", style={"marginBottom": "4px"}) for l in logs]


# ================================================================
# [LOGIN-INTEGRATION] ④ 헤더에 로그인된 사용자 이메일 표시
# ----------------------------------------------------------------
# localStorage 의 Supabase 세션에서 user.email 을 꺼내 헤더에 렌더.
# dcc.Location pathname 을 트리거로 페이지 로드 시 1회 실행.
# 토큰이 없으면 빈 문자열 (어차피 게이트에서 /login 으로 보내짐).
# ================================================================
app.clientside_callback(
    """
    function(pathname) {
        const keys = Object.keys(window.localStorage)
            .filter(k => k.startsWith('sb-') && k.endsWith('-auth-token'));
        for (const k of keys) {
            try {
                const v = JSON.parse(window.localStorage.getItem(k));
                if (v && v.user && v.user.email) return '👤 ' + v.user.email;
            } catch (e) {}
        }
        return '';
    }
    """,
    Output("user-email-display", "children"),
    Input("url", "pathname")
)

# ================================================================
# [LOGIN-INTEGRATION] ⑤ 로그아웃 — Supabase 토큰 제거 + /login 으로
# ----------------------------------------------------------------
# Supabase SDK 의 signOut() 을 거치지 않고 localStorage 만 비우면
# 다음 요청부터 게이트가 토큰 없음 판정 → /login 으로 보냄.
# (서버측 세션 즉시 만료가 필요하면 supabase.auth.signOut() REST 호출 추가)
# ================================================================
app.clientside_callback(
    """
    function(n_clicks) {
        if (!n_clicks) return window.dash_clientside.no_update;
        const keys = Object.keys(window.localStorage).filter(k => k.startsWith('sb-'));
        keys.forEach(k => window.localStorage.removeItem(k));
        window.location.href = '/login/';
        return '';
    }
    """,
    Output("_logout-dummy", "children"),
    Input("btn-logout", "n_clicks"),
    prevent_initial_call=True
)


# ================================================================
# [PDF] 추출 버튼 콜백 — Node /pdf 호출 → URL 받아 store 에 저장
# ----------------------------------------------------------------
# 흐름:
#   1. btn-export-pdf 클릭 → analysis-result-store 의 job_id 추출
#   2. POST http://127.0.0.1:3000/pdf  { job_id }
#      Node 가 캐시 확인 → 없으면 스캐너 호출 → Storage 업로드 → Signed URL
#   3. 응답의 url 을 pdf-url-store 에 저장 → clientside callback 이 다운로드 트리거
# 사용자 로그는 upload-log-store 로 같이 흘려 보내 진행 표시.
# ================================================================
@callback(
    Output("pdf-url-store", "data"),
    Output("upload-log-store", "data", allow_duplicate=True),
    Input("btn-export-pdf", "n_clicks"),
    State("analysis-result-store", "data"),
    State("upload-log-store", "data"),
    prevent_initial_call=True
)
def request_pdf(n_clicks, analysis, current_logs):
    def _ts():
        return datetime.datetime.now().strftime("%H:%M:%S")
    if not n_clicks:
        return no_update, no_update
    logs = list(current_logs or [])
    if not analysis or not analysis.get("job_id"):
        logs.insert(0, {"time": _ts(), "content": "PDF 추출 실패 — 먼저 이미지 스캔을 실행해 주세요."})
        return no_update, logs
    job_id = analysis["job_id"]
    logs.insert(0, {"time": _ts(), "content": f"PDF 추출 요청 중 (job {job_id[:8]}...)"})
    try:
        resp = requests.post(
            "http://127.0.0.1:3000/pdf",
            json={"job_id": job_id},
            timeout=300,  # PDF 생성 단계가 수~수십초 가능
        )
        data = resp.json()
        if not data.get("ok") or not data.get("url"):
            logs.insert(0, {"time": _ts(), "content": f"PDF 생성 실패: {data.get('error') or resp.status_code}"})
            return no_update, logs
        cached_label = "캐시 재사용" if data.get("cached") else "신규 생성"
        logs.insert(0, {"time": _ts(), "content": f"PDF 다운로드 시작 ({cached_label})"})
        # store 에 URL 저장 → clientside callback 이 다운로드 트리거
        return {"url": data["url"], "ts": _ts()}, logs
    except Exception as e:
        logs.insert(0, {"time": _ts(), "content": f"PDF 통신 장애: {str(e)[:120]}"})
        return no_update, logs


# [PDF] clientside — store 에 URL 들어오면 navigation 으로 다운로드 트리거.
# 서버(Node /pdf)가 Supabase createSignedUrl 의 download 옵션을 줘서
# 응답에 Content-Disposition: attachment 헤더가 항상 붙는다 → 어떤 PC /
# 어떤 브라우저 / 어떤 PDF 핸들러 설정에서도 무조건 다운로드로 처리.
# 이전 <a download> 트릭은 cross-origin + 지연 click 으로 silent block 되는
# 환경(특히 바닐라 Windows + Chrome 기본 설정)이 있어 폐기.
app.clientside_callback(
    """
    function(payload) {
        if (!payload || !payload.url) return window.dash_clientside.no_update;
        try {
            // 단순 navigation — Content-Disposition: attachment 헤더 때문에
            // 브라우저가 즉시 download 로 전환 (페이지 이동 X).
            window.location.assign(payload.url);
        } catch (e) {
            console.error('PDF 다운로드 트리거 실패:', e);
        }
        return '';
    }
    """,
    Output("_pdf-trigger-dummy", "children"),
    Input("pdf-url-store", "data"),
    prevent_initial_call=True
)


if __name__ == "__main__":
    app.run(debug=False, port=8050)
