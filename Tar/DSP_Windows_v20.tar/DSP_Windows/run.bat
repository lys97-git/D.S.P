@echo off
chcp 65001 > nul
title DSP Launcher

echo.
echo  =========================================
echo   DSP Launcher
echo  =========================================
echo.
echo  [1/2] Checking run.ps1 UTF-8 BOM...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p='%~dp0run.ps1';" ^
  "if(-not(Test-Path $p)){Write-Host '  [ERR] run.ps1 not found' -ForegroundColor Red;exit 1}" ^
  "$b=[IO.File]::ReadAllBytes($p);" ^
  "if($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF){" ^
  "  Write-Host '  [OK] BOM already exists' -ForegroundColor Green" ^
  "}else{" ^
  "  [IO.File]::WriteAllBytes($p,([byte[]](0xEF,0xBB,0xBF)+$b));" ^
  "  Write-Host '  [OK] BOM injected' -ForegroundColor Green" ^
  "}"

if %errorlevel% neq 0 (
    echo.
    echo  [ERR] BOM injection failed.
    pause
    exit /b 1
)

echo.
echo  [2/2] Launching run.ps1 (UAC will appear if admin needed)...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1"

echo.
echo  =========================================
echo   Launcher finished.
echo   (Services may still be running in separate windows)
echo   This window will close in 3 seconds...
echo  =========================================
timeout /t 3 /nobreak > nul
exit
