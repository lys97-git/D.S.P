이 폴더에 NanumGothic-Regular.ttf 파일을 두면 PDF 보고서에 한국어 폰트가 임베드됩니다.

다운로드처: https://hangeul.naver.com/font 또는 https://github.com/naver/nanumfont
파일명을 정확히 "NanumGothic-Regular.ttf" 로 두세요.

폰트 파일이 없어도 PDF 는 시스템 폰트(Malgun Gothic 등)로 폴백되어 정상 생성됩니다.
파일을 두면 모든 환경에서 동일한 폰트 렌더링이 보장됩니다.
