/**
 * GET /scan-results
 *
 * grype_only 테이블을 **user-scoped Supabase 클라이언트** 로 조회한다.
 * - 기존 /results/:job_id 는 service_role 키 → RLS 우회 → 모든 사용자 데이터 노출
 * - 본 라우트는 anon 키 + 사용자 JWT → RLS 정책 적용 → 본인 데이터만 노출
 *
 * 필요한 사전 작업 (DB 측):
 *   1) grype_only 테이블에 user_id uuid 컬럼 추가 (auth.users.id 외래키)
 *   2) ALTER TABLE grype_only ENABLE ROW LEVEL SECURITY;
 *   3) CREATE POLICY "own_rows" ON grype_only
 *        FOR SELECT USING (auth.uid() = user_id);
 *   (자세한 가이드는 docs/RLS_GUIDE.md 참조)
 *
 * 요청 헤더:
 *   Authorization: Bearer <Supabase JWT>
 *
 * 응답:
 *   200 [{ ...grype_only row }, ...]    // 본인 데이터만
 *   401 토큰 누락
 *   500 DB 에러
 */

const express = require('express');
const { getUserSupabase } = require('../db');

const router = express.Router();

router.get('/', async (req, res) => {
  // Bearer 토큰 추출 (없으면 401)
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Authorization Bearer 토큰이 필요합니다.' });
  }

  // 사용자별 클라이언트로 grype_only 조회 — RLS 정책이 본인 행만 반환
  const supabase = getUserSupabase(token);
  const { data, error } = await supabase
    .from('grype_only')
    .select('*');

  if (error) {
    console.error('[ScanResults] grype_only 조회 실패:', error.message);
    return res.status(500).json({ error: error.message });
  }

  console.log(`[ScanResults] grype_only 조회 — ${data?.length || 0} 건 (user-scoped)`);
  res.json(data || []);
});

module.exports = router;
