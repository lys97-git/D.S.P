module.exports = {
  PORT: process.env.PORT || 3000,

  // ── CORS ──────────────────────────────────────────────
  // 쉼표로 구분해서 여러 오리진 허용 가능
  // 예: http://localhost:5173,http://localhost:4173
  ALLOWED_ORIGINS: process.env.ALLOWED_ORIGINS
    ? process.env.ALLOWED_ORIGINS.split(',').map(s => s.trim())
    : ['http://localhost:5173', 'http://localhost:4173', 'http://localhost:3000', 'http://localhost:8050', 'http://localhost:8080'],

  // ── Supabase ───────────────────────────────────────────
  // SERVICE_KEY: 서버 전용 (RLS 우회). 기존 대부분의 라우트가 사용.
  // ANON_KEY:    user-scoped 클라이언트(getUserSupabase) 가 사용. 사용자 JWT 와
  //              함께 쓰여 RLS 정책이 적용된 접근을 만든다 (본인 데이터만 노출).
  SUPABASE_URL:         process.env.SUPABASE_URL         || '',
  SUPABASE_SERVICE_KEY: process.env.SUPABASE_SERVICE_KEY || '',
  SUPABASE_ANON_KEY:    process.env.SUPABASE_ANON_KEY    || '',

  // ── 스캔 도구 경로 ────────────────────────────────────
  TRIVY_BIN: process.env.TRIVY_BIN || 'trivy',
  GRYPE_BIN: process.env.GRYPE_BIN || 'grype',

  // ── Python 스캐너 (교차 분석) ─────────────────────────
  // uvicorn python.scanner:app --port 8000 으로 실행
  PYTHON_SCANNER_URL: process.env.PYTHON_SCANNER_URL || 'http://localhost:8000',

  // ── 파일 업로드 ───────────────────────────────────────
  UPLOAD_DIR:       process.env.UPLOAD_DIR       || 'uploads',
  MAX_FILE_SIZE_MB: parseInt(process.env.MAX_FILE_SIZE_MB) || 2048,
};
