/**
 * Supabase 클라이언트
 *
 * 두 종류를 제공한다:
 *   1) supabase           — service_role 키, RLS 우회. 서버 신뢰 작업용.
 *      사용법: const supabase = require('./db');
 *   2) getUserSupabase(t) — anon 키 + 사용자 JWT, RLS 정책 적용.
 *      사용법: const { getUserSupabase } = require('./db');
 *              const sb = getUserSupabase(req.headers.authorization?.split(' ')[1]);
 *
 * 어느 쪽을 써야 하는가?
 *   - 사용자 본인 데이터만 노출해야 하면 → getUserSupabase
 *     (DB 가 auth.uid() 로 자동 필터 → 코드 실수로 user_id 필터 누락해도 안전)
 *   - 백그라운드 작업/집계/시스템 처리 → 기존 supabase (service_role)
 *
 * 동작 전제 (없으면 빈 결과만 받음):
 *   - 대상 테이블에 user_id 컬럼 + RLS Enable + auth.uid()=user_id 정책
 *   - 호출 시 Authorization: Bearer <JWT> 헤더 동봉
 */

const { createClient } = require('@supabase/supabase-js');
const {
  SUPABASE_URL,
  SUPABASE_SERVICE_KEY,
  SUPABASE_ANON_KEY,
} = require('../config');

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.warn('[DB] SUPABASE_URL 또는 SUPABASE_SERVICE_KEY 가 설정되지 않았습니다. .env 파일을 확인하세요.');
}
if (!SUPABASE_ANON_KEY) {
  console.warn('[DB] SUPABASE_ANON_KEY 가 설정되지 않았습니다 — user-scoped 클라이언트(getUserSupabase) 가 동작하지 않습니다.');
}

// ── ① service_role 클라이언트 (기존 동작 유지) ────────────────
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
  auth: { persistSession: false },
});

// 연결 테스트
supabase
  .from('scan_jobs')
  .select('id', { count: 'exact', head: true })
  .then(({ error }) => {
    if (error) {
      console.warn('[DB] Supabase 연결 실패:', error.message);
    } else {
      console.log('[DB] Supabase 연결 성공');
    }
  });

// ── ② user-scoped 클라이언트 팩토리 (RLS 적용) ────────────────
// 호출 1회당 클라이언트 1개를 만든다 (Authorization 헤더가 토큰 단위로 달라짐).
// 토큰이 비어도 호출은 가능 — 단 RLS 정책상 anon 권한만 부여돼 대부분 0건.
const getUserSupabase = (accessToken) => {
  return createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
    {
      auth: { persistSession: false },
      global: {
        headers: accessToken
          ? { Authorization: `Bearer ${accessToken}` }
          : {},
      },
    }
  );
};

// 기존 호환: `const supabase = require('./db')` 형태가 그대로 동작하도록
// default export 는 service_role 클라이언트로 유지. getUserSupabase 는
// named export 로 노출.
module.exports = supabase;
module.exports.getUserSupabase = getUserSupabase;
