#!/bin/bash
# ============================================================
# DSP 초기 설치 스크립트 (Ubuntu 24.04 LTS)
# (구버전 — 신규 배포 시 ./run.sh 하나로 통합되어 있으므로 권장)
# 실행: chmod +x setup.sh && sudo ./setup.sh
# ============================================================
set -e

echo "=== [1/6] 시스템 패키지 업데이트 ==="
apt-get update -y && apt-get upgrade -y

echo "=== [2/6] 필수 도구 설치 ==="
apt-get install -y curl wget git unzip software-properties-common

echo "=== [3/6] Node.js 22.x 설치 ==="
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs
node -v && npm -v

echo "=== [4/6] Python3 + pip + 패키지 설치 ==="
apt-get install -y python3 python3-pip python3-venv
# Ubuntu 24.04(PEP 668) 대응: --break-system-packages 로 시스템 파이썬에 직접 설치
# FastAPI 공식 권장: fastapi[standard] 한 줄로 uvicorn[standard] + python-multipart + httpx 자동 포함
PIP_FLAGS="--break-system-packages"
pip3 install $PIP_FLAGS --upgrade pip
pip3 install $PIP_FLAGS "fastapi[standard]" requests
pip3 install $PIP_FLAGS dash dash-mantine-components dash-iconify pandas plotly deep-translator

echo "=== [5/6] Trivy 설치 ==="
wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | gpg --dearmor | \
    tee /usr/share/keyrings/trivy.gpg > /dev/null
echo "deb [signed-by=/usr/share/keyrings/trivy.gpg] https://aquasecurity.github.io/trivy-repo/deb generic main" | \
    tee /etc/apt/sources.list.d/trivy.list
apt-get update -y
apt-get install -y trivy
trivy --version

echo "=== [6/6] Grype 설치 ==="
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b /usr/local/bin
grype version

echo ""
echo "=== 의존성 설치 ==="
cd "$(dirname "$0")"

echo "  서버 패키지 설치 중..."
cd server && npm install --production
cd ..

echo "  클라이언트 빌드 중..."
cd client && npm install && npm run build
cd ..

echo ""
echo "✅ 설치 완료!"
echo "   .env 파일을 server/.env 에 설정한 뒤 ./start.sh 를 실행하세요."
