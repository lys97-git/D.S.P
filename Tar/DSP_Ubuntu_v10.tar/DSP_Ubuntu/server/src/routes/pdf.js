/**
 * POST /pdf
 *
 * Dash 의 "PDF 추출" 버튼이 호출하는 라우트. 결과: Storage Signed URL.
 *
 * ── 흐름 ────────────────────────────────────────────────────────────────
 *   1. 캐시 확인 — scan_reports.report_path 에 이미 값이 있는지 조회.
 *   2. 캐시 있음 → 그대로 Signed URL 만 발급해 반환 (스캐너 호출 X).
 *      캐시 없음 → 스캐너(:8000) /report/generate 호출하여 신규 생성.
 *                  스캐너가 PDF 만들어 Storage('reports' 버킷)에 업로드 후
 *                  storage_path 반환 → scan_reports.report_path 업데이트.
 *   3. supabase.storage.from('reports').createSignedUrl(path, 3600) 호출.
 *   4. { ok, job_id, storage_path, url, cached } 반환.
 *
 * ── 캐싱 의도 ───────────────────────────────────────────────────────────
 *   같은 job 의 PDF 추출 버튼을 여러 번 눌러도 스캐너는 1회만 호출. PDF
 *   파일은 Storage 에 영구 보존되고 URL 만 매번 새로 발급(1시간 만료).
 *
 * ── 보안 (TODO 향후) ────────────────────────────────────────────────────
 *   현재는 job_id 만 받으면 누구든 PDF 생성/조회 가능. Authorization 헤더
 *   (Supabase JWT) 검증 + user_id 매칭은 보안 2단계 작업으로 별도 진행.
 */

const express  = require('express');
const supabase = require('../db/index');

const router = express.Router();

const SCANNER_URL    = process.env.PYTHON_SCANNER_URL || 'http://localhost:8000';
const STORAGE_BUCKET = process.env.SUPABASE_BUCKET    || 'reports';
const SIGNED_URL_TTL = 3600; // seconds (1 hour)

// ── POST /pdf ──────────────────────────────────────────────────
router.post('/', async (req, res) => {
  const jobId = req.body && req.body.job_id;
  if (!jobId) {
    return res.status(400).json({ ok: false, error: 'job_id 필드가 필요합니다.' });
  }

  try {
    // ── 1. 캐시 확인 ────────────────────────────────────────────
    // scan_reports.scan_job_id 는 FK 비활성. 실제 컬럼은 scan_jobs_id(s).
    const { data: report, error: rErr } = await supabase
      .from('scan_reports')
      .select('id, report_path, scan_jobs_id')
      .eq('scan_jobs_id', jobId)
      .maybeSingle();
    if (rErr) throw new Error(`scan_reports 조회 실패: ${rErr.message}`);

    let storagePath = report && report.report_path;
    const cached    = !!storagePath;

    // ── 2. 캐시 없음 → 스캐너에게 PDF 생성 요청 ────────────────
    if (!cached) {
      console.log(`[PDF] job ${jobId} 캐시 없음 — 스캐너 /report/generate 호출`);
      const scResp = await fetch(`${SCANNER_URL}/report/generate`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ scan_job_id: jobId }),
      });
      if (!scResp.ok) {
        const txt = await scResp.text();
        throw new Error(`스캐너 응답 ${scResp.status}: ${txt.slice(0, 200)}`);
      }
      const scData = await scResp.json();
      if (scData.status !== 'success' || !scData.storage_path) {
        throw new Error(`스캐너 PDF 생성 실패: ${scData.detail || JSON.stringify(scData)}`);
      }
      storagePath = scData.storage_path;
      console.log(`[PDF] 스캐너 응답 storage_path=${storagePath}`);

      // 캐시: scan_reports.report_path 업데이트
      if (report && report.id) {
        const { error: updErr } = await supabase
          .from('scan_reports')
          .update({ report_path: storagePath })
          .eq('id', report.id);
        if (updErr) console.warn(`[PDF] scan_reports report_path 업데이트 실패: ${updErr.message}`);
      } else {
        console.warn(`[PDF] scan_reports 행 없음 (job ${jobId}) — report_path 캐시 보류`);
      }
    } else {
      console.log(`[PDF] job ${jobId} 캐시 히트 — storage_path=${storagePath}`);
    }

    // ── 3. Signed URL 발급 ───────────────────────────────────────
    const { data: urlData, error: urlErr } = await supabase
      .storage
      .from(STORAGE_BUCKET)
      .createSignedUrl(storagePath, SIGNED_URL_TTL);
    if (urlErr) throw new Error(`Signed URL 발급 실패: ${urlErr.message}`);

    // ── 4. 응답 ───────────────────────────────────────────────────
    res.json({
      ok:           true,
      job_id:       jobId,
      storage_path: storagePath,
      bucket:       STORAGE_BUCKET,
      url:          urlData.signedUrl,
      cached,
      expires_in:   SIGNED_URL_TTL,
    });

  } catch (e) {
    console.error(`[PDF] 에러: ${e.message}`);
    res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
