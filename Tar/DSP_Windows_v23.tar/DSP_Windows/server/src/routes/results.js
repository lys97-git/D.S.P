/**
 * GET /results/:job_id
 *
 * ── 데이터 흐름 2단계 ───────────────────────────────────────────────────
 * 1단계: 스캐너(:8000) → POST /save → Supabase DB 적재 (save.js)
 * 2단계: 대시보드(:8050) → GET /results/:job_id → Node API 가 DB 에서
 *        결과를 읽어 대시보드 렌더링 규격으로 가공해 반환  ← 이 파일
 *
 * 즉, 대시보드가 스캐너의 직접 응답이 아니라 "DB 에 적재된 값"을 본다.
 * 이렇게 해야 scanner.py 의 v4 호환 어댑터에서 누락된 secret 항목까지
 * (security_filtered 테이블에 저장되어 있으므로) 화면에 정상 노출된다.
 *
 * ── 반환 규격 (front_end_v9_3.py 가 직접 사용) ────────────────────────────
 *   {
 *     job_id, status,
 *     summary:         { CRITICAL, HIGH, MEDIUM, LOW, UNKNOWN },
 *     vulnerabilities: [ {14개 필드}, ... ],   // Trivy + Grype + Secret 통합
 *     mismatch_meta:   [ {vulnerability_id, grype_severity, trivy_severity}, ... ],
 *     scan_job:        scan_jobs 원본 레코드
 *   }
 *
 * ── 2026-05-28 DB 리팩토링 반영 ─────────────────────────────────────────
 *   - 구 grype_filtered 삭제 → OS_filtered 로 교체 (조회 테이블만 바꾸면 됨,
 *     컬럼 의미는 동일).
 *   - 신규 mismatch 테이블 select 추가 → mismatch_meta 로 응답 동봉.
 *     프런트(front_end_v9_3)의 "미스매치" 필터는 이 메타의 vulnerability_id
 *     집합을 기준으로 행을 추린다. (기존: groupby().nunique()>1 — 항상 0건)
 *   - grype_only / trivy_only 테이블은 현재 응답에 포함시키지 않음. 통합
 *     vulnerabilities 리스트엔 grype_vulnerabilities + trivy_vulnerabilities
 *     가 이미 그들을 포함하고 있어 중복을 피하기 위함. 필요 시 추후 노출.
 */

const express  = require('express');
const supabase = require('../db/index');

const router = express.Router();

// ── 헬퍼: severity 안전 정규화 (UPPERCASE) ──────────────────────
function normSev(s) {
  const u = String(s || 'UNKNOWN').toUpperCase();
  return ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'UNKNOWN'].includes(u) ? u : 'UNKNOWN';
}

// ── GET /results/:job_id ────────────────────────────────────────
router.get('/:job_id', async (req, res) => {
  const jobId = req.params.job_id;

  try {
    // DB 5개 소스 동시 조회
    // (OS_filtered 가 구 grype_filtered 의 자리. mismatch 는 신규 추가.)
    const [jobRes, appRes, osRes, secRes, mismatchRes] = await Promise.all([
      supabase.from('scan_jobs').select('*').eq('id', jobId).maybeSingle(),
      supabase.from('application_filtered').select('*').eq('scan_job_id', jobId),
      supabase.from('OS_filtered').select('*').eq('scan_job_id', jobId),
      supabase.from('security_filtered').select('*').eq('scan_job_id', jobId),
      supabase.from('mismatch')
        .select('vulnerability_id,grype_severity,trivy_severity,package_name')
        .eq('scan_job_id', jobId),
    ]);

    if (jobRes.error) throw new Error(`scan_jobs 조회 실패: ${jobRes.error.message}`);
    if (!jobRes.data) {
      return res.status(404).json({ error: `해당 job_id 없음: ${jobId}` });
    }
    if (appRes.error)      throw new Error(`application_filtered 조회 실패: ${appRes.error.message}`);
    if (osRes.error)       throw new Error(`OS_filtered 조회 실패: ${osRes.error.message}`);
    if (secRes.error)      throw new Error(`security_filtered 조회 실패: ${secRes.error.message}`);
    if (mismatchRes.error) throw new Error(`mismatch 조회 실패: ${mismatchRes.error.message}`);

    const vulnerabilities = [];
    const seen = new Set();   // vulnerability_id 중복 제거 (Grype 우선)

    // ── 미스매치 CVE 집합 — Trivy 행 dedup 예외 처리용 ──────────────
    // (v14.1) 미스매치는 Grype 와 Trivy 가 같은 CVE 를 다르게 분류한 케이스라
    // 양도구 행을 모두 보여줘야 비교가 됨. 일반 CVE 는 Grype 우선 dedup 하되,
    // mismatch 테이블에 있는 CVE 는 Trivy 측 행도 vulnerabilities 에 추가.
    const mismatchVidSet = new Set(
      (mismatchRes.data || []).map(m => m.vulnerability_id).filter(Boolean)
    );

    // ── Grype OS 패키지 → 14필드 스키마 ──────────────────────────
    for (const v of (osRes.data || [])) {
      const vid = v.vulnerability_id;
      if (!vid || seen.has(vid)) continue;
      seen.add(vid);
      vulnerabilities.push({
        vulnerability_id:   vid,
        package_name:       v.package_name || '',
        package_path:       v.install_path || '',
        installed_version:  v.version || '',           // OS_filtered 의 version 컬럼 활용
        fixed_version:      v.fix_version || '',
        severity:           normSev(v.severity),
        source:             'grype',
        is_fixed_available: !!v.is_fixed_available,
        target:             '',
        result_class:       '',
        result_type:        v.package_type || '',
        primary_url:        '',
        title:              '',
        description:        v.description || '',
      });
    }

    // ── Trivy → application_filtered ──────────────────────────
    // 일반 CVE: seen 체크로 dedup (Grype 가 이미 추가했으면 skip)
    // 미스매치 CVE: seen 무시하고 Trivy 행도 추가 → 양도구 비교 가능
    for (const v of (appRes.data || [])) {
      const vid = v.vulnerability_id;
      if (!vid) continue;
      const isMismatch = mismatchVidSet.has(vid);
      if (seen.has(vid) && !isMismatch) continue;   // 일반 dedup
      if (!seen.has(vid)) seen.add(vid);             // 미스매치도 seen 에 기록 (다음 source 중복 방지)
      vulnerabilities.push({
        vulnerability_id:   vid,
        package_name:       v.package_name || '',
        package_path:       v.package_path || '',
        installed_version:  v.installed_version || '',
        fixed_version:      v.fixed_version || '',
        severity:           normSev(v.severity),
        source:             'trivy',
        is_fixed_available: !!v.is_fixed_available,
        target:             v.target || '',
        result_class:       v.result_class || '',
        result_type:        v.result_type || '',
        primary_url:        v.primary_url || '',
        title:              v.title || '',
        description:        v.description || '',
      });
    }

    // ── Secret → security_filtered ────────────────────────────
    // result_class/result_type 에 'secret' 을 넣어 대시보드 분류 필터가
    // 이 행을 SECRET 으로 인식하도록 한다 (front_end_v9_3 classify_row).
    for (const s of (secRes.data || [])) {
      vulnerabilities.push({
        vulnerability_id:   s.rule_id || `secret-${s.id}`,
        package_name:       s.category || 'Secret',
        package_path:       s.created_by || '',
        installed_version:  '',
        fixed_version:      '',
        severity:           normSev(s.severity || 'HIGH'),
        source:             'trivy',
        is_fixed_available: false,
        target:             '',
        result_class:       'secret',
        result_type:        'secret',
        primary_url:        '',
        title:              s.rule_id || 'Secret',
        description:        s.match_text || '',
      });
    }

    // ── mismatch_meta 구성 ────────────────────────────────────────
    // 미스매치 = 같은 vulnerability_id 를 Grype 와 Trivy 가 다른 severity 로
    // 잡은 경우. front_end_v9_3 의 "미스매치" 필터가 이 메타의 ID 집합으로
    // vulnerabilities 행을 추린다. (응답 vulnerabilities 는 dedup 되어 있어
    // 프런트가 자체적으로 mismatch 계산은 불가능 — 백엔드에서 메타 동봉.)
    const mismatch_meta = (mismatchRes.data || []).map(m => ({
      vulnerability_id: m.vulnerability_id,
      package_name:     m.package_name || '',
      grype_severity:   normSev(m.grype_severity),
      trivy_severity:   normSev(m.trivy_severity),
    }));

    // ── summary 집계 (도넛차트용) ─────────────────────────────
    const summary = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0, UNKNOWN: 0 };
    for (const v of vulnerabilities) summary[v.severity]++;

    res.json({
      job_id:          jobId,
      status:          jobRes.data.status,
      summary,
      vulnerabilities,
      mismatch_meta,
      scan_job:        jobRes.data,
    });

    console.log(
      `[Results] job ${jobId} 조회 — OS(grype):${osRes.data?.length || 0} ` +
      `app(trivy):${appRes.data?.length || 0} secret:${secRes.data?.length || 0} ` +
      `mismatch:${mismatch_meta.length} → 통합 ${vulnerabilities.length}건`
    );

  } catch (e) {
    console.error('[Results] 조회 실패:', e.message);
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
