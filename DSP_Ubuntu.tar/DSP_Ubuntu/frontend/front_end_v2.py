"""
DSP  Integrated Security Dashboard
front_end_v2.py  —  Python Dash 기반 단일 페이지 대시보드

통합 기능:
  - Docker 이미지 .tar 업로드 & 스캔 (Trivy + Grype 동시)
  - 심각도 분포 차트 (전체 / Trivy / Grype 도넛)
  - KEV 등재 취약점 & Top 10 위험 순위
  - 전체 / Trivy 전용 / Grype 전용 취약점 테이블 (정렬·필터·페이지네이션)
  - 시크릿 탐지 결과
  - 교차 분석 (Grype Only / Trivy Only / 심각도 불일치)
  - 최근 스캔 이력 (Node.js API)
  - 업로드 로그
  - 취약점 상세 모달
"""

import subprocess, sys, datetime, base64, io, json, requests, webbrowser
from threading import Timer

# ── 필수 패키지 자동 설치 ─────────────────────────────────────────────────────
_REQUIRED = {
    "dash": "dash",
    "dash_mantine_components": "dash-mantine-components",
    "dash_iconify": "dash-iconify",
    "pandas": "pandas",
    "plotly": "plotly",
    "requests": "requests",
}
for mod, pkg in _REQUIRED.items():
    try:
        __import__(mod)
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "-q"])

import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html, Input, Output, State, callback, ALL, no_update, ctx
from dash.dash_table import DataTable
import dash_mantine_components as dmc
from dash_iconify import DashIconify

# ── 설정 ──────────────────────────────────────────────────────────────────────
SCANNER_URL  = "http://127.0.0.1:8000/scan"
HISTORY_URL  = "http://127.0.0.1:3000/scan"
DASH_PORT    = 8080
APP_TITLE    = "Project DSP: Integrated Security Dashboard"

SEV_ORDER    = ["Critical", "High", "Medium", "Low", "Unknown"]
SEV_COLOR    = {"Critical": "#e03131", "High": "#f76707",
                "Medium":   "#f59f00", "Low":  "#2f9e44", "Unknown": "#868e96"}
SEV_BADGE    = {"Critical": "red",     "High": "orange",
                "Medium":   "yellow",  "Low":  "green",   "Unknown": "gray"}

# ── Dash 앱 초기화 ────────────────────────────────────────────────────────────
app = dash.Dash(__name__, suppress_callback_exceptions=True,
                title="DSP Dashboard")

# ── 공통 헬퍼 ─────────────────────────────────────────────────────────────────
def sev_badge(sev: str):
    return dmc.Badge(sev, color=SEV_BADGE.get(sev, "gray"), variant="filled", size="sm")

def _epss(score):
    return f"{score*100:.2f}%" if score is not None else "—"

def _plain_table(headers: list, rows: list, id_prefix=""):
    """단순 html.Table 반환 (소형 테이블용)"""
    ths = [html.Th(h, style={"padding":"6px 10px","borderBottom":"2px solid #dee2e6","whiteSpace":"nowrap"}) for h in headers]
    trs = []
    for i, row in enumerate(rows):
        bg = "#f8f9fa" if i % 2 else "white"
        tds = [html.Td(c, style={"padding":"5px 10px","borderBottom":"1px solid #f1f3f5"}) for c in row]
        trs.append(html.Tr(tds, style={"background": bg}))
    return html.Div(
        html.Table([html.Thead(html.Tr(ths)), html.Tbody(trs)],
                   style={"width":"100%","borderCollapse":"collapse","fontSize":"13px"}),
        style={"overflowX":"auto","maxHeight":"420px","overflowY":"auto"}
    )

def _datatable(data: list, columns: list, table_id: str):
    """dash DataTable (정렬·필터·페이지네이션 내장)"""
    return DataTable(
        id=table_id, data=data, columns=columns,
        page_size=20, page_action="native",
        sort_action="native", filter_action="native",
        style_table={"overflowX": "auto"},
        style_cell={"fontSize": "12px", "padding": "5px 8px",
                    "textAlign": "left", "maxWidth": "260px",
                    "overflow": "hidden", "textOverflow": "ellipsis"},
        style_header={"fontWeight": "700", "backgroundColor": "#f1f3f5",
                       "borderBottom": "2px solid #dee2e6"},
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "#f8f9fa"},
            {"if": {"filter_query": '{severity} = "Critical"'}, "color": "#e03131"},
            {"if": {"filter_query": '{severity} = "High"'},     "color": "#f76707"},
            {"if": {"filter_query": '{severity} = "Medium"'},   "color": "#e67700"},
            {"if": {"filter_query": '{kev_included} = "True"'}, "backgroundColor": "#fff3bf"},
        ],
        tooltip_data=[{c["id"]: {"value": str(row.get(c["id"],"")),"type":"markdown"}
                       for c in columns} for row in data],
        tooltip_duration=None,
    )

def _summary_cards(summary: dict, secrets_count: int, total: int):
    cards = []
    for sev in SEV_ORDER:
        cnt = summary.get(sev, 0)
        if cnt == 0:
            continue
        cards.append(dmc.Paper(
            withBorder=True, radius="md", p="sm",
            style={"textAlign":"center","borderTop":f"4px solid {SEV_COLOR.get(sev,'#868e96')}","minWidth":"100px"},
            children=[dmc.Text(str(cnt), size="xl", fw=700, c=SEV_COLOR.get(sev,"gray")),
                      dmc.Text(sev, size="xs", c="dimmed")]
        ))
    cards.append(dmc.Paper(
        withBorder=True, radius="md", p="sm",
        style={"textAlign":"center","borderTop":"4px solid #7048e8","minWidth":"100px"},
        children=[dmc.Text(str(secrets_count), size="xl", fw=700, c="#7048e8"),
                  dmc.Text("Secrets", size="xs", c="dimmed")]
    ))
    cards.append(dmc.Paper(
        withBorder=True, radius="md", p="sm",
        style={"textAlign":"center","borderTop":"4px solid #1c7ed6","minWidth":"100px"},
        children=[dmc.Text(str(total), size="xl", fw=700, c="#1c7ed6"),
                  dmc.Text("전체 고유", size="xs", c="dimmed")]
    ))
    return dmc.Group(cards, gap="sm", mb="md")

def _donut_fig(data_dict: dict, title: str):
    if not data_dict:
        return px.pie(title=f"{title}: 데이터 없음")
    df = pd.DataFrame([{"severity": k, "count": v} for k, v in data_dict.items() if v > 0])
    if df.empty:
        return px.pie(title=f"{title}: 취약점 없음")
    fig = px.pie(df, names="severity", values="count", hole=0.52, title=title,
                 color="severity", color_discrete_map=SEV_COLOR)
    fig.update_traces(textposition="inside", textinfo="percent+label")
    fig.update_layout(margin=dict(l=10,r=10,t=40,b=10), showlegend=True,
                      legend=dict(orientation="h", y=-0.15),
                      title=dict(font=dict(size=14)))
    return fig

# ── 레이아웃 ──────────────────────────────────────────────────────────────────
app.layout = dmc.MantineProvider(
    forceColorScheme="light",
    children=[
        dcc.Store(id="result-store"),
        dcc.Store(id="log-store", data=[]),

        html.Div(style={"position": "relative"}, children=[

            dmc.LoadingOverlay(
                id="loading-overlay", visible=False,
                loaderProps={"type": "bars", "color": "blue", "size": "xl"},
                overlayProps={"radius": "sm", "blur": 2},
                zIndex=1000,
            ),

            html.Div(style={"padding": "20px"}, children=[
                dmc.Container(size="xl", children=[

                    # ── 헤더 ──────────────────────────────────────────────
                    dmc.Group(justify="space-between", mb="lg", children=[
                        dmc.Group([
                            DashIconify(icon="tabler:shield-check", width=38, color="#228be6"),
                            dmc.Stack(gap=0, children=[
                                dmc.Title(APP_TITLE, order=2),
                                dmc.Text("Trivy + Grype 통합 취약점 분석 플랫폼", size="sm", c="dimmed"),
                            ]),
                        ]),
                        dmc.Group([
                            dmc.Button("PDF 저장", id="btn-pdf", variant="outline",
                                       leftSection=DashIconify(icon="tabler:file-download")),
                        ]),
                    ]),

                    # ── 업로드 섹션 ───────────────────────────────────────
                    dmc.Paper(withBorder=True, shadow="sm", radius="md", p="md", mb="lg", children=[
                        dmc.Group(justify="space-between", mb="xs", children=[
                            dmc.Text("Docker 이미지 업로드 (.tar / .tar.gz / .tgz)", fw=700),
                            html.Div(id="upload-status"),
                        ]),
                        dcc.Upload(
                            id="upload-data", multiple=False,
                            children=html.Div([
                                DashIconify(icon="tabler:cloud-upload", width=36, color="#74c0fc"),
                                html.Br(),
                                dmc.Text("클릭하거나 파일을 드래그하세요", size="sm"),
                                dmc.Text(".tar  .tar.gz  .tgz", size="xs", c="dimmed"),
                            ], style={"textAlign":"center"}),
                            style={
                                "width":"100%","height":"110px","borderWidth":"2px",
                                "borderStyle":"dashed","borderColor":"#74c0fc","borderRadius":"10px",
                                "display":"flex","alignItems":"center","justifyContent":"center","cursor":"pointer",
                            },
                        ),
                    ]),

                    # ── 메인 대시보드 (스캔 후 표시) ──────────────────────
                    html.Div(id="dashboard-area"),

                    # ── 최근 스캔 이력 ─────────────────────────────────────
                    dmc.Paper(withBorder=True, shadow="xs", radius="md", p="md", mt="lg", children=[
                        dmc.Group(justify="space-between", mb="sm", children=[
                            dmc.Text("최근 스캔 이력", fw=700),
                            dmc.Button("새로고침", id="btn-refresh-history", variant="subtle", size="xs",
                                       leftSection=DashIconify(icon="tabler:refresh")),
                        ]),
                        html.Div(id="history-area",
                                 children=dmc.Text("Node.js API 연결 확인 중...", c="dimmed", size="sm")),
                    ]),

                ]),
            ]),
        ]),

        # ── 상세 정보 모달 ─────────────────────────────────────────────────
        dmc.Modal(
            id="detail-modal", title="취약점 상세 정보",
            centered=True, size="lg",
            children=[html.Div(id="modal-content")],
        ),
    ]
)

# ── scanner_2.py final_payload → 대시보드 표시 형식 변환 ─────────────────────
def _cap(s):
    """UPPERCASE severity → Capitalized (예: CRITICAL → Critical)"""
    if not s:
        return "Unknown"
    s = str(s).strip()
    return (s[0].upper() + s[1:].lower()) if s else "Unknown"


def _adapt_payload(payload: dict, filename: str) -> dict:
    """
    scanner_2.py /scan 응답(final_payload)을 대시보드 렌더링 형식으로 변환합니다.

    final_payload 구조:
      scan_job      — scan_jobs 통계 (critical_count, high_count, ...)
      scan_report   — 교차 분석 카운트 (total_count, grype_only, trivy_only, ...)
      filtered_data — 정제된 취약점 리스트 (grype_vulnerabilities, trivy_vulnerabilities,
                      secrets, grype_only, trivy_only, mismatch, vulnerabilities)

    대시보드 렌더링이 기대하는 형식:
      summary        — {"Critical": N, "High": N, ...}  (Capitalized 키)
      vulnerabilities — 전체 취약점 리스트 (pkg_name, installed_version, ...)
      trivy_vulns    — Trivy 전용 취약점 리스트
      grype_vulns    — Grype 전용 취약점 리스트 (epss_score/kev_included 없음 → None/False)
      secrets        — 시크릿 리스트
      cross_analysis — 교차 분석 카운트 + grype_only/trivy_only/mismatch 리스트
      scan_info      — 파일명, 스캔 시각, 총 취약점 수, 시크릿 수
    """
    scan_job     = payload.get("scan_job",     {})
    scan_report  = payload.get("scan_report",  {})
    filtered     = payload.get("filtered_data", {})

    # ── 심각도 요약 (Capitalized 키) ────────────────────────────
    summary = {
        "Critical": scan_job.get("critical_count", 0),
        "High":     scan_job.get("high_count",     0),
        "Medium":   scan_job.get("medium_count",   0),
        "Low":      scan_job.get("low_count",      0),
        "Unknown":  scan_job.get("unknown_count",  0),
    }

    # ── Trivy 취약점 ────────────────────────────────────────────
    # scanner_2: package_name, installed_version, fixed_version, package_path
    trivy_vulns = []
    for v in filtered.get("trivy_vulnerabilities", []):
        trivy_vulns.append({
            "vulnerability_id":  v.get("vulnerability_id", ""),
            "pkg_name":          v.get("package_name", ""),
            "severity":          _cap(v.get("severity", "")),
            "installed_version": v.get("installed_version", ""),
            "fixed_version":     v.get("fixed_version", ""),
            "result_type":       v.get("result_type", ""),
            "description":       v.get("description", ""),
            "pkg_path":          v.get("package_path", ""),
            "source":            "trivy",
        })

    # ── Grype 취약점 ────────────────────────────────────────────
    # scanner_2: package_name, version(설치), fix_version(수정), install_path, risk(CVSS)
    # EPSS/KEV 미지원 → None/False 처리
    grype_vulns = []
    for v in filtered.get("grype_vulnerabilities", []):
        risk = v.get("risk")
        grype_vulns.append({
            "vulnerability_id":  v.get("vulnerability_id", ""),
            "pkg_name":          v.get("package_name", ""),
            "severity":          _cap(v.get("severity", "")),
            "installed_version": v.get("version", ""),
            "fixed_version":     v.get("fix_version", ""),
            "is_fixed_available": v.get("is_fixed_available", False),
            "epss_score":        None,
            "kev_included":      False,
            "risk_score":        risk if risk not in (None, "N/A") else None,
            "package_type":      v.get("package_type", ""),
            "description":       v.get("description", ""),
            "source":            "grype",
            "pkg_path":          v.get("install_path", ""),
        })

    # ── 시크릿 ──────────────────────────────────────────────────
    secrets = []
    for s in filtered.get("secrets", []):
        secrets.append({
            "rule_id":      s.get("rule_id", ""),
            "title":        s.get("title", "") or "",
            "severity":     _cap(s.get("severity", "")),
            "match_text":   s.get("match_text", "") or "",
            "category":     s.get("category", "") or "",
            "layer_digest": s.get("layer_digest", "") or "",
        })

    # ── 교차 분석 리스트 헬퍼 ────────────────────────────────────
    def _adapt_grype_item(v):
        return {
            "vulnerability_id":  v.get("vulnerability_id", ""),
            "pkg_name":          v.get("package_name", ""),
            "severity":          _cap(v.get("severity", "")),
            "installed_version": v.get("version", ""),
            "fixed_version":     v.get("fix_version", ""),
        }

    def _adapt_trivy_item(v):
        return {
            "vulnerability_id":  v.get("vulnerability_id", ""),
            "pkg_name":          v.get("package_name", ""),
            "severity":          _cap(v.get("severity", "")),
            "installed_version": v.get("installed_version", ""),
            "fixed_version":     v.get("fixed_version", ""),
        }

    def _adapt_mismatch_item(v):
        return {
            "vulnerability_id": v.get("vulnerability_id", ""),
            "pkg_name":         v.get("package_name", ""),
            "grype_severity":   _cap(v.get("grype_severity", "")),
            "trivy_severity":   _cap(v.get("trivy_severity", "")),
        }

    # ── 교차 분석 ────────────────────────────────────────────────
    # scan_report.grype_only / trivy_only 는 카운트(int),
    # filtered.grype_only / trivy_only / mismatch 는 리스트
    cross_analysis = {
        "total_count":      scan_report.get("total_count",    0),
        "common_count":     scan_report.get("common_count",   0),
        "grype_only_count": scan_report.get("grype_only",     0),
        "trivy_only_count": scan_report.get("trivy_only",     0),
        "mismatch_count":   scan_report.get("mismatch_count", 0),
        "grype_only": [_adapt_grype_item(v)    for v in filtered.get("grype_only", [])],
        "trivy_only":  [_adapt_trivy_item(v)   for v in filtered.get("trivy_only", [])],
        "mismatch":    [_adapt_mismatch_item(v) for v in filtered.get("mismatch",   [])],
    }

    # ── 전체 취약점 리스트 (grype_only + mismatch + trivy_only) ──
    # 전체 탭(tab_all)에 표시되는 리스트로, 교차분석 대상 취약점 전체
    all_vulns = []
    for v in filtered.get("grype_only", []) + filtered.get("mismatch", []):
        all_vulns.append({
            "vulnerability_id":  v.get("vulnerability_id", ""),
            "pkg_name":          v.get("package_name", ""),
            "severity":          _cap(v.get("severity", "")),
            "installed_version": v.get("version", ""),
            "fixed_version":     v.get("fix_version", ""),
            "source":            "grype",
            "pkg_path":          v.get("install_path", ""),
            "description":       v.get("description", ""),
        })
    for v in filtered.get("trivy_only", []):
        all_vulns.append({
            "vulnerability_id":  v.get("vulnerability_id", ""),
            "pkg_name":          v.get("package_name", ""),
            "severity":          _cap(v.get("severity", "")),
            "installed_version": v.get("installed_version", ""),
            "fixed_version":     v.get("fixed_version", ""),
            "source":            "trivy",
            "pkg_path":          v.get("package_path", ""),
            "description":       v.get("description", ""),
        })

    # ── 스캔 정보 ────────────────────────────────────────────────
    scan_info = {
        "filename":      scan_job.get("file_name", filename),
        "scan_time":     scan_job.get("finished_at", ""),
        "total_vulns":   scan_job.get("total_vulnerabilities", 0),
        "secrets_count": len(secrets),
    }

    return {
        "summary":         summary,
        "vulnerabilities": all_vulns,
        "trivy_vulns":     trivy_vulns,
        "grype_vulns":     grype_vulns,
        "secrets":         secrets,
        "cross_analysis":  cross_analysis,
        "scan_info":       scan_info,
    }


# ── 콜백 1: 파일 업로드 → 스캔 실행 ─────────────────────────────────────────
@callback(
    Output("result-store", "data"),
    Output("log-store", "data"),
    Output("loading-overlay", "visible"),
    Output("upload-status", "children"),
    Input("upload-data", "contents"),
    State("upload-data", "filename"),
    State("log-store", "data"),
    prevent_initial_call=True,
)
def run_scan(contents, filename, logs):
    if contents is None:
        return no_update, no_update, False, no_update

    logs = logs or []
    now  = datetime.datetime.now().strftime("%H:%M:%S")

    try:
        _, content_string = contents.split(",")
        decoded = base64.b64decode(content_string)
        response = requests.post(
            SCANNER_URL,
            files={"file": (filename, io.BytesIO(decoded), "application/x-tar")},
            data={"user_id": "dash_user", "scan_name": filename},
            timeout=600,
        )
        if response.status_code == 200:
            raw = response.json()
            # scanner_2.py 예외 시 {"status": "Error", "detail": "..."}
            if raw.get("status") == "Error":
                raise RuntimeError(raw.get("detail", "스캐너 내부 오류"))
            # final_payload → 대시보드 표시 형식으로 변환
            result = _adapt_payload(raw, filename)
            total = result.get("scan_info", {}).get("total_vulns", 0)
            new_log = {"time": now, "msg": f"[{filename}] 완료 — 취약점 {total}개 탐지"}
            status  = dmc.Badge("스캔 완료", color="green", variant="filled")
            return result, [new_log] + logs, False, status
        else:
            raise RuntimeError(f"서버 에러 {response.status_code}")

    except Exception as e:
        new_log = {"time": now, "msg": f"[{filename}] 오류: {e}"}
        status  = dmc.Badge("스캔 실패", color="red", variant="filled")
        return no_update, [new_log] + logs, False, status

# ── 콜백 2: 결과 store → 대시보드 렌더링 ─────────────────────────────────────
@callback(
    Output("dashboard-area", "children"),
    Input("result-store", "data"),
    Input("log-store", "data"),
)
def render_dashboard(result, logs):
    # ── 로그 섹션 (항상 마지막 탭에 표시) ──────────────────────────────────
    log_rows = [html.Tr([html.Td(l["time"], style={"color":"#868e96","whiteSpace":"nowrap","paddingRight":"12px"}),
                         html.Td(l["msg"])]) for l in (logs or [])]
    log_tab = html.Div([
        dmc.Text("업로드 및 스캔 로그", fw=700, mb="xs"),
        html.Div(
            html.Table([html.Tbody(log_rows)],
                       style={"width":"100%","fontSize":"13px"}),
            style={"maxHeight":"300px","overflowY":"auto"},
        ) if log_rows else dmc.Text("로그 없음", c="dimmed", size="sm")
    ])

    if not result:
        return dmc.Paper(
            withBorder=True, p="xl", radius="md", mt="md",
            children=[dmc.Text("파일을 업로드하면 분석 결과가 여기에 표시됩니다.",
                               c="dimmed", ta="center", size="lg", mt=40, mb=40)]
        )

    summary     = result.get("summary", {})
    vulns       = result.get("vulnerabilities", [])
    trivy_vulns = result.get("trivy_vulns", [])
    grype_vulns = result.get("grype_vulns", [])
    secrets     = result.get("secrets", [])
    cross       = result.get("cross_analysis", {})
    scan_info   = result.get("scan_info", {})

    total_vulns    = scan_info.get("total_vulns", len(vulns))
    secrets_count  = scan_info.get("secrets_count", len(secrets))
    filename       = scan_info.get("filename", "—")
    scan_time_raw  = scan_info.get("scan_time", "")
    try:
        scan_dt = datetime.datetime.fromisoformat(scan_time_raw.replace("Z", "+00:00"))
        scan_time_str = scan_dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        scan_time_str = scan_time_raw

    # ── 스캔 정보 바 ───────────────────────────────────────────────────────
    info_bar = dmc.Paper(
        withBorder=True, radius="md", p="sm", mb="md",
        style={"background":"#e7f5ff"},
        children=dmc.Group(gap="xl", children=[
            dmc.Group(gap="xs", children=[DashIconify(icon="tabler:file", width=16), dmc.Text(filename, size="sm", fw=600)]),
            dmc.Group(gap="xs", children=[DashIconify(icon="tabler:clock", width=16), dmc.Text(scan_time_str, size="sm")]),
            dmc.Group(gap="xs", children=[DashIconify(icon="tabler:shield", width=16),
                                          dmc.Text(f"Trivy: {len(trivy_vulns)}  /  Grype: {len(grype_vulns)}", size="sm")]),
        ]),
    )

    # ── 요약 카드 ──────────────────────────────────────────────────────────
    summary_cards = _summary_cards(summary, secrets_count, total_vulns)

    # ── 탭 1: 위험도 분포 차트 ─────────────────────────────────────────────
    def _count_sev(vuln_list):
        cnt = {s: 0 for s in SEV_ORDER}
        for v in vuln_list:
            sev = v.get("severity", "Unknown")
            cnt[sev] = cnt.get(sev, 0) + 1
        return {k: v for k, v in cnt.items() if v > 0}

    tab_chart = dmc.Grid(gutter="md", children=[
        dmc.GridCol(dcc.Graph(figure=_donut_fig(summary,       "전체 취약점"), style={"height":"320px"}), span=4),
        dmc.GridCol(dcc.Graph(figure=_donut_fig(_count_sev(trivy_vulns), "Trivy"), style={"height":"320px"}), span=4),
        dmc.GridCol(dcc.Graph(figure=_donut_fig(_count_sev(grype_vulns), "Grype"), style={"height":"320px"}), span=4),
    ])

    # ── 탭 2: KEV / Top 위험 ───────────────────────────────────────────────
    kev_list = [v for v in grype_vulns if v.get("kev_included")]
    kev_table = _plain_table(
        ["CVE ID", "패키지", "버전", "심각도", "EPSS", "수정 버전"],
        [[v["vulnerability_id"], v["pkg_name"], v["installed_version"],
          sev_badge(v["severity"]), _epss(v.get("epss_score")), v["fixed_version"]]
         for v in sorted(kev_list, key=lambda x: x.get("epss_score") or 0, reverse=True)],
    ) if kev_list else dmc.Text("KEV 등재 취약점 없음 ✅", c="dimmed", size="sm")

    sev_rank = {"Critical":4,"High":3,"Medium":2,"Low":1,"Unknown":0}
    top10 = sorted(grype_vulns,
                   key=lambda v: (v.get("epss_score") or 0, sev_rank.get(v["severity"],0)),
                   reverse=True)[:10]
    top_table = _plain_table(
        ["#", "CVE ID", "패키지", "심각도", "EPSS", "Risk Score", "KEV", "수정가능"],
        [[i+1, v["vulnerability_id"], v["pkg_name"], sev_badge(v["severity"]),
          _epss(v.get("epss_score")), v.get("risk_score") or "—",
          "🔴 KEV" if v.get("kev_included") else "—",
          "✅" if v.get("is_fixed_available") else "—"]
         for i, v in enumerate(top10)],
    ) if top10 else dmc.Text("데이터 없음", c="dimmed", size="sm")

    tab_kev = html.Div([
        dmc.Text("KEV 등재 취약점", fw=700, mb="xs"), kev_table,
        dmc.Divider(my="md"),
        dmc.Text("Top 10 위험 순위 (EPSS / 심각도 기준)", fw=700, mb="xs"), top_table,
    ])

    # ── 탭 3: 전체 취약점 (DataTable) ─────────────────────────────────────
    all_cols = [
        {"name":"CVE ID",   "id":"vulnerability_id"},
        {"name":"패키지",    "id":"pkg_name"},
        {"name":"심각도",    "id":"severity"},
        {"name":"설치 버전", "id":"installed_version"},
        {"name":"수정 버전", "id":"fixed_version"},
        {"name":"출처",      "id":"source"},
        {"name":"경로",      "id":"pkg_path"},
    ]
    tab_all = html.Div([
        dmc.Text(f"전체 고유 취약점 {total_vulns}개 (DataTable — 컬럼 클릭으로 정렬, 헤더 아래 입력으로 필터)", size="xs", c="dimmed", mb="xs"),
        _datatable([{c["id"]: v.get(c["id"],"") for c in all_cols} for v in vulns], all_cols, "dt-all"),
    ])

    # ── 취약점 행 클릭용 invisible 트리거 (modal용) ────────────────────────
    vuln_rows = [
        html.Tr(
            id={"type":"vuln-row","index":v["vulnerability_id"]},
            style={"display":"none"},
            children=[html.Td(v["vulnerability_id"])],
            n_clicks=0,
        ) for v in vulns
    ]
    hidden_rows = html.Table(html.Tbody(vuln_rows), style={"display":"none"})

    # ── 탭 4: Trivy 결과 ──────────────────────────────────────────────────
    trivy_cols = [
        {"name":"CVE ID",   "id":"vulnerability_id"},
        {"name":"패키지",    "id":"pkg_name"},
        {"name":"심각도",    "id":"severity"},
        {"name":"설치 버전", "id":"installed_version"},
        {"name":"수정 버전", "id":"fixed_version"},
        {"name":"타입",      "id":"result_type"},
        {"name":"설명",      "id":"description"},
    ]
    tab_trivy = html.Div([
        dmc.Text(f"Trivy 탐지 취약점: {len(trivy_vulns)}개", size="sm", c="dimmed", mb="xs"),
        _datatable([{c["id"]: v.get(c["id"],"") for c in trivy_cols} for v in trivy_vulns], trivy_cols, "dt-trivy"),
    ])

    # ── 탭 5: Grype 결과 ──────────────────────────────────────────────────
    grype_cols = [
        {"name":"CVE ID",      "id":"vulnerability_id"},
        {"name":"패키지",       "id":"pkg_name"},
        {"name":"심각도",       "id":"severity"},
        {"name":"설치 버전",    "id":"installed_version"},
        {"name":"수정 버전",    "id":"fixed_version"},
        {"name":"EPSS",        "id":"epss_score"},
        {"name":"KEV",         "id":"kev_included"},
        {"name":"Risk",        "id":"risk_score"},
        {"name":"타입",         "id":"package_type"},
        {"name":"수정가능",     "id":"is_fixed_available"},
    ]
    grype_data = []
    for v in grype_vulns:
        row = {c["id"]: v.get(c["id"],"") for c in grype_cols}
        row["epss_score"]       = _epss(v.get("epss_score"))
        row["kev_included"]     = "🔴 KEV" if v.get("kev_included") else ""
        row["is_fixed_available"] = "✅" if v.get("is_fixed_available") else ""
        grype_data.append(row)
    tab_grype = html.Div([
        dmc.Text(f"Grype 탐지 취약점: {len(grype_vulns)}개 (EPSS·KEV·Risk 포함)", size="sm", c="dimmed", mb="xs"),
        _datatable(grype_data, grype_cols, "dt-grype"),
    ])

    # ── 탭 6: 시크릿 ──────────────────────────────────────────────────────
    tab_secrets = html.Div([
        dmc.Text(f"시크릿 탐지: {secrets_count}개", fw=700, mb="xs"),
        _plain_table(
            ["심각도","Rule ID","유형","카테고리","탐지 내용(마스킹)","레이어"],
            [[sev_badge(s["severity"]), s["rule_id"], s["title"], s["category"],
              html.Code(s["match_text"][:60]+"…" if len(s["match_text"])>60 else s["match_text"]),
              s["layer_digest"]]
             for s in secrets],
        ) if secrets else dmc.Text("시크릿 탐지 없음 ✅", c="dimmed", size="sm")
    ])

    # ── 탭 7: 교차 분석 ───────────────────────────────────────────────────
    cross_cards = dmc.Group(gap="sm", mb="md", children=[
        dmc.Paper(withBorder=True, radius="md", p="sm", style={"textAlign":"center","minWidth":"90px"},
                  children=[dmc.Text(str(cross.get("total_count",0)), size="lg", fw=700),
                             dmc.Text("전체 고유", size="xs", c="dimmed")]),
        dmc.Paper(withBorder=True, radius="md", p="sm", style={"textAlign":"center","minWidth":"90px"},
                  children=[dmc.Text(str(cross.get("common_count",0)), size="lg", fw=700, c="blue"),
                             dmc.Text("공통 탐지", size="xs", c="dimmed")]),
        dmc.Paper(withBorder=True, radius="md", p="sm", style={"textAlign":"center","minWidth":"90px"},
                  children=[dmc.Text(str(cross.get("grype_only_count",0)), size="lg", fw=700, c="orange"),
                             dmc.Text("Grype Only", size="xs", c="dimmed")]),
        dmc.Paper(withBorder=True, radius="md", p="sm", style={"textAlign":"center","minWidth":"90px"},
                  children=[dmc.Text(str(cross.get("trivy_only_count",0)), size="lg", fw=700, c="teal"),
                             dmc.Text("Trivy Only", size="xs", c="dimmed")]),
        dmc.Paper(withBorder=True, radius="md", p="sm", style={"textAlign":"center","minWidth":"90px"},
                  children=[dmc.Text(str(cross.get("mismatch_count",0)), size="lg", fw=700, c="red"),
                             dmc.Text("불일치", size="xs", c="dimmed")]),
    ])

    def _cross_table(rows, headers):
        return _plain_table(headers, rows) if rows else dmc.Text("없음 ✅", c="dimmed", size="sm")

    tab_cross = html.Div([
        cross_cards,
        dmc.Tabs(value="go", children=[
            dmc.TabsList([
                dmc.TabsTab(f"Grype Only ({cross.get('grype_only_count',0)})",  value="go"),
                dmc.TabsTab(f"Trivy Only ({cross.get('trivy_only_count',0)})",  value="to"),
                dmc.TabsTab(f"심각도 불일치 ({cross.get('mismatch_count',0)})", value="mm"),
            ]),
            dmc.TabsPanel(value="go", pt="sm", children=[
                _cross_table(
                    [[v["vulnerability_id"],v["pkg_name"],sev_badge(v["severity"]),
                      v["installed_version"],v["fixed_version"]] for v in cross.get("grype_only",[])],
                    ["CVE ID","패키지","심각도","설치 버전","수정 버전"],
                )]),
            dmc.TabsPanel(value="to", pt="sm", children=[
                _cross_table(
                    [[v["vulnerability_id"],v["pkg_name"],sev_badge(v["severity"]),
                      v["installed_version"],v["fixed_version"]] for v in cross.get("trivy_only",[])],
                    ["CVE ID","패키지","심각도","설치 버전","수정 버전"],
                )]),
            dmc.TabsPanel(value="mm", pt="sm", children=[
                _cross_table(
                    [[v["vulnerability_id"],v["pkg_name"],
                      sev_badge(v["grype_severity"]),"→",sev_badge(v["trivy_severity"])]
                     for v in cross.get("mismatch",[])],
                    ["CVE ID","패키지","Grype 심각도","","Trivy 심각도"],
                )]),
        ]),
    ])

    # ── 메인 탭 조립 ──────────────────────────────────────────────────────
    main_tabs = dmc.Tabs(value="chart", children=[
        dmc.TabsList([
            dmc.TabsTab("📊 위험도 분포",                              value="chart"),
            dmc.TabsTab(f"🔴 KEV / Top 위험 ({len(kev_list)})",        value="kev"),
            dmc.TabsTab(f"📋 전체 취약점 ({total_vulns})",             value="all"),
            dmc.TabsTab(f"🔬 Trivy ({len(trivy_vulns)})",              value="trivy"),
            dmc.TabsTab(f"🔬 Grype ({len(grype_vulns)})",              value="grype"),
            dmc.TabsTab(f"🔐 시크릿 ({secrets_count})",               value="secrets"),
            dmc.TabsTab(f"🔀 교차 분석",                               value="cross"),
            dmc.TabsTab("📝 로그",                                     value="log"),
        ]),
        dmc.TabsPanel(value="chart",   pt="md", children=[tab_chart]),
        dmc.TabsPanel(value="kev",     pt="md", children=[tab_kev]),
        dmc.TabsPanel(value="all",     pt="md", children=[tab_all, hidden_rows]),
        dmc.TabsPanel(value="trivy",   pt="md", children=[tab_trivy]),
        dmc.TabsPanel(value="grype",   pt="md", children=[tab_grype]),
        dmc.TabsPanel(value="secrets", pt="md", children=[tab_secrets]),
        dmc.TabsPanel(value="cross",   pt="md", children=[tab_cross]),
        dmc.TabsPanel(value="log",     pt="md", children=[log_tab]),
    ])

    return html.Div([
        info_bar,
        summary_cards,
        dmc.Paper(withBorder=True, shadow="sm", radius="md", p="lg", children=[main_tabs]),
    ])

# ── 콜백 3: 취약점 행 클릭 → 모달 ─────────────────────────────────────────────
@callback(
    Output("detail-modal", "opened"),
    Output("modal-content", "children"),
    Input({"type": "vuln-row", "index": ALL}, "n_clicks"),
    State("result-store", "data"),
    prevent_initial_call=True,
)
def open_modal(n_clicks, result):
    if not any(n_clicks) or not result:
        return False, no_update
    clicked_id = ctx.triggered_id["index"]
    v = next((x for x in result.get("vulnerabilities", [])
              if x["vulnerability_id"] == clicked_id), None)
    if not v:
        return False, no_update
    content = dmc.Stack([
        dmc.Grid([
            dmc.GridCol(dmc.Text("CVE ID",    fw=600), span=4),
            dmc.GridCol(dmc.Text(v["vulnerability_id"]), span=8),
            dmc.GridCol(dmc.Text("패키지명",   fw=600), span=4),
            dmc.GridCol(dmc.Text(v["pkg_name"]), span=8),
            dmc.GridCol(dmc.Text("설치 경로",  fw=600), span=4),
            dmc.GridCol(dmc.Text(v.get("pkg_path","—"), size="sm"), span=8),
            dmc.GridCol(dmc.Text("설치 버전",  fw=600), span=4),
            dmc.GridCol(dmc.Text(v.get("installed_version","—")), span=8),
            dmc.GridCol(dmc.Text("수정 버전",  fw=600), span=4),
            dmc.GridCol(dmc.Text(v.get("fixed_version","—"), c="blue", fw=700), span=8),
            dmc.GridCol(dmc.Text("심각도",     fw=600), span=4),
            dmc.GridCol(sev_badge(v.get("severity","Unknown")), span=8),
            dmc.GridCol(dmc.Text("출처",       fw=600), span=4),
            dmc.GridCol(dmc.Text(v.get("source","—")), span=8),
        ]),
        dmc.Divider(),
        dmc.Text("취약점 설명", fw=600),
        dmc.Text(v.get("description","설명 없음"), size="sm"),
    ])
    return True, content

# ── 콜백 4: 최근 스캔 이력 ────────────────────────────────────────────────────
@callback(
    Output("history-area", "children"),
    Input("btn-refresh-history", "n_clicks"),
    prevent_initial_call=False,
)
def load_history(_):
    STATUS_LABEL = {"pending":"대기","uploaded":"업로드됨","running":"진행 중",
                    "completed":"완료","failed":"실패","cancelled":"취소"}
    STATUS_COLOR = {"pending":"gray","uploaded":"blue","running":"yellow",
                    "completed":"green","failed":"red","cancelled":"gray"}
    try:
        # 타임아웃 10초 — Supabase 콜드 스타트 / 네트워크 지연 대비
        res = requests.get(f"{HISTORY_URL}?limit=10", timeout=10)
        if res.status_code != 200:
            return dmc.Text(
                f"Node.js API 응답 오류 (status: {res.status_code}) — {res.text[:200]}",
                c="red", size="sm"
            )
        jobs = res.json()
        if not jobs:
            return dmc.Text("스캔 이력 없음", c="dimmed", size="sm")
        rows = []
        for j in jobs:
            status = j.get("status","—")
            rows.append(dmc.Group(justify="space-between", mb=4, children=[
                dmc.Text(j.get("file_name") or j.get("image_name") or "—", size="sm", style={"flex":1}),
                dmc.Badge(STATUS_LABEL.get(status, status), color=STATUS_COLOR.get(status,"gray"), size="xs"),
                dmc.Text(str(j.get("created_at",""))[:16], size="xs", c="dimmed"),
            ]))
        return html.Div(rows)
    except requests.exceptions.ConnectionError:
        return dmc.Text(
            "Node.js API 서버에 연결할 수 없습니다 (http://localhost:3000) — 서버가 실행 중인지 확인하세요",
            c="red", size="sm"
        )
    except requests.exceptions.Timeout:
        return dmc.Text(
            "Node.js API 응답 지연 (10초 초과) — Supabase 연결 상태를 확인하세요",
            c="orange", size="sm"
        )
    except Exception as e:
        return dmc.Text(f"이력 조회 오류: {type(e).__name__}: {str(e)[:200]}", c="red", size="sm")

# ── 브라우저 자동 실행 ─────────────────────────────────────────────────────────
def _open_browser():
    webbrowser.open_new(f"http://127.0.0.1:{DASH_PORT}/")

if __name__ == "__main__":
    Timer(1.5, _open_browser).start()
    app.run(debug=False, port=DASH_PORT)
