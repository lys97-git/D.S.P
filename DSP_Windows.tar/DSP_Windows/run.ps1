﻿# ================================================================
#  DSP  통합 실행 스크립트  (run.ps1)
#  run.bat -> PowerShell 실행 -> 이 파일이 관리자 권한 자체 처리
#
#  STEP 1  포트 정리
#  STEP 2  기술스택 설치 / 확인
#  STEP 3  서비스 시작  (Python 8000 / Node.js 3000 / Dash 8080)
#  STEP 4  자가점검  (도구 . 서버 . 파일 전체 확인)
#  STEP 5  실행 모드 선택
#           [1] 터미널 유지 (모니터링)
#           [2] 백그라운드 실행 (이 창만 닫기)
#           [3] 모든 서비스 종료
# ================================================================

# -- 관리자 권한 자가 확인 및 재실행 ----------------------------
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal   = New-Object Security.Principal.WindowsPrincipal($currentUser)
$isAdmin     = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "  관리자 권한으로 재실행합니다. UAC 창을 수락하세요..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# -- 전역 설정 --------------------------------------------------
$ErrorActionPreference = "SilentlyContinue"
try { $HOST.UI.RawUI.WindowTitle = "DSP 통합 실행기" } catch {}

$ROOT  = Split-Path -Parent $MyInvocation.MyCommand.Path
$TOOLS = Join-Path $ROOT "tools"
if (-not (Test-Path $TOOLS)) { New-Item -ItemType Directory -Path $TOOLS | Out-Null }
$env:PATH = "$TOOLS;$env:PATH"

# -- 컬러 출력 헬퍼 ---------------------------------------------
function cw  { param($t, $c = "White");  Write-Host $t -ForegroundColor $c }
function ok  { param($label); cw "  |  [OK] $label" Green  }
function ng  { param($label); cw "  |  [NG] $label  <- 확인 필요" Red    }
function inf { param($label); cw "  |       $label"  Gray   }
function war { param($label); cw "  |  [!!] $label"  Yellow }

function Show-Banner {
    Clear-Host
    cw ""
    cw "  +========================================================+" Cyan
    cw "  |        DSP  통합 실행기  [관리자 모드]            |" Cyan
    cw "  |   Python(8000)  .  Node.js(3000)  .  Dash(8080)        |" Cyan
    cw "  +========================================================+" Cyan
    cw ""
}

# -- TCP 포트 응답 확인 ------------------------------------------
function Test-Port {
    param([int]$port)
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $tcp.BeginConnect("127.0.0.1", $port, $null, $null)
        $ok = $ar.AsyncWaitHandle.WaitOne(800, $false)
        if ($ok) { try { $tcp.EndConnect($ar) } catch {} }
        $tcp.Close()
        return $ok
    } catch { return $false }
}

# -- 포트 점유 프로세스 종료 ------------------------------------
function Stop-Port {
    param([int]$port)
    netstat -ano 2>$null |
        Select-String "\s:$port\s" |
        ForEach-Object {
            if ($_.Line -match '\s(\d+)\s*$') {
                $p = [int]$Matches[1]
                if ($p -gt 4) { Stop-Process -Id $p -Force -ErrorAction SilentlyContinue }
            }
        }
}

# -- 서비스 시작 (임시 bat 방식 - 인용 부호 충돌 방지) ----------
# 띄운 cmd 의 PID 를 $script:ServicePids 에 저장 -> Stop-AllServices 에서 종료
$script:ServicePids = @()

function Start-Service {
    param(
        [string]$title,
        [string]$workDir,
        [string]$cmd,
        [hashtable]$envVars = @{}
    )
    $tmp = Join-Path $env:TEMP "$title.bat"

    # 추가 환경 변수를 set 줄로 변환
    $envLines = ""
    foreach ($k in $envVars.Keys) {
        $envLines += "set $k=$($envVars[$k])`r`n"
    }

    $body = "@echo off`r`nchcp 65001 > nul`r`ntitle $title`r`nset PATH=$TOOLS;%PATH%`r`n${envLines}cd /d `"$workDir`"`r`n$cmd"
    [System.IO.File]::WriteAllText($tmp, $body, [System.Text.Encoding]::UTF8)
    $proc = Start-Process "cmd.exe" -ArgumentList "/k `"$tmp`"" -WindowStyle Normal -PassThru
    if ($proc) { $script:ServicePids += $proc.Id }
}

# ================================================================
#  STEP 1  포트 정리
# ================================================================
function Invoke-PortCleanup {
    cw "  +-- STEP 1/3  포트 정리 ----------------------------------------" DarkGray
    inf "기존 node / python 프로세스 종료..."
    Get-Process -Name "node"   -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name "python" -ErrorAction SilentlyContinue | Stop-Process -Force
    foreach ($p in @(3000, 8000, 8080)) { Stop-Port $p }
    Start-Sleep -Milliseconds 800
    inf "포트 3000 / 8000 / 8080 해제 완료"
    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  STEP 2  기술스택 설치 / 확인
# ================================================================
function Invoke-StackSetup {
    cw "  +-- STEP 2/3  기술스택 설치 / 확인 ----------------------------" DarkGray

    $useWinget = $null -ne (Get-Command winget -ErrorAction SilentlyContinue)

    # -- Node.js ----------------------------------------------------
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
        war "[Node.js]  없음 -> 설치 중..."
        if ($useWinget) {
            winget install OpenJS.NodeJS.LTS --silent --scope machine `
                --accept-source-agreements --accept-package-agreements | Out-Null
            $env:PATH = "C:\Program Files\nodejs;$env:PATH"
        }
        if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
            $msi = "$env:TEMP\node_lts.msi"
            Invoke-WebRequest "https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi" `
                -OutFile $msi -UseBasicParsing
            Start-Process msiexec -ArgumentList "/i `"$msi`" /quiet /norestart ADDLOCAL=ALL" -Wait
            Remove-Item $msi -Force -ErrorAction SilentlyContinue
            $env:PATH = "C:\Program Files\nodejs;$env:PATH"
        }
    }
    $v = (node --version 2>$null)
    if ($v) { ok "[Node.js]   $v" } else { ng "[Node.js]   설치 실패 - 재실행 필요" }

    # -- Python -----------------------------------------------------
    if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
        war "[Python]   없음 -> 설치 중..."
        if ($useWinget) {
            winget install Python.Python.3.12 --silent --scope machine `
                --accept-source-agreements --accept-package-agreements | Out-Null
            $env:PATH = "C:\Program Files\Python312;C:\Program Files\Python312\Scripts;$env:PATH"
        }
    }
    $v = (python --version 2>$null)
    if ($v) { ok "[Python]    $v" } else { ng "[Python]    설치 실패 - 재실행 필요" }

    # -- Trivy ------------------------------------------------------
    if (-not (Get-Command trivy -ErrorAction SilentlyContinue)) {
        war "[Trivy]    없음 -> 다운로드 중..."
        try {
            $tag = (Invoke-WebRequest "https://api.github.com/repos/aquasecurity/trivy/releases/latest" `
                -UseBasicParsing | ConvertFrom-Json).tag_name
            $ver = $tag.TrimStart("v")
            Invoke-WebRequest "https://github.com/aquasecurity/trivy/releases/download/$tag/trivy_${ver}_windows-64bit.zip" `
                -OutFile "$env:TEMP\trivy.zip" -UseBasicParsing
            Expand-Archive "$env:TEMP\trivy.zip" -DestinationPath $TOOLS -Force
            Remove-Item "$env:TEMP\trivy.zip" -Force
        } catch { ng "[Trivy]    다운로드 실패: $_" }
    }
    $v = (trivy --version 2>$null | Select-Object -First 1)
    if ($v) { ok "[Trivy]     $v" } else { ng "[Trivy]     설치 실패" }

    # -- Grype ------------------------------------------------------
    if (-not (Get-Command grype -ErrorAction SilentlyContinue)) {
        war "[Grype]    없음 -> 다운로드 중..."
        try {
            $tag = (Invoke-WebRequest "https://api.github.com/repos/anchore/grype/releases/latest" `
                -UseBasicParsing | ConvertFrom-Json).tag_name
            $ver = $tag.TrimStart("v")
            Invoke-WebRequest "https://github.com/anchore/grype/releases/download/$tag/grype_${ver}_windows_amd64.zip" `
                -OutFile "$env:TEMP\grype.zip" -UseBasicParsing
            Expand-Archive "$env:TEMP\grype.zip" -DestinationPath $TOOLS -Force
            Remove-Item "$env:TEMP\grype.zip" -Force
        } catch { ng "[Grype]    다운로드 실패: $_" }
    }
    if (Get-Command grype -ErrorAction SilentlyContinue) { ok "[Grype]     설치됨" } else { ng "[Grype]     설치 실패" }

    # -- Syft -------------------------------------------------------
    if (-not (Get-Command syft -ErrorAction SilentlyContinue)) {
        war "[Syft]     없음 -> 다운로드 중..."
        try {
            $tag = (Invoke-WebRequest "https://api.github.com/repos/anchore/syft/releases/latest" `
                -UseBasicParsing | ConvertFrom-Json).tag_name
            $ver = $tag.TrimStart("v")
            Invoke-WebRequest "https://github.com/anchore/syft/releases/download/$tag/syft_${ver}_windows_amd64.zip" `
                -OutFile "$env:TEMP\syft.zip" -UseBasicParsing
            Expand-Archive "$env:TEMP\syft.zip" -DestinationPath $TOOLS -Force
            Remove-Item "$env:TEMP\syft.zip" -Force
        } catch { ng "[Syft]     다운로드 실패: $_" }
    }
    if (Get-Command syft -ErrorAction SilentlyContinue) { ok "[Syft]      설치됨" } else { ng "[Syft]      설치 실패" }

    # -- npm 패키지 -------------------------------------------------
    $serverDir = Join-Path $ROOT "server"
    if (-not (Test-Path (Join-Path $serverDir "node_modules"))) {
        war "[npm]      node_modules 없음 -> 설치 중..."
        Push-Location $serverDir
        npm install 2>$null | Out-Null
        Pop-Location
    }
    ok "[npm]       패키지 준비됨"

    # -- pip 패키지 -------------------------------------------------
    $pipOk = $(python -c "import dash, fastapi, uvicorn, requests, pandas" 2>$null; $LASTEXITCODE -eq 0)
    if (-not $pipOk) {
        war "[pip]      패키지 없음 -> 설치 중..."
        pip install fastapi uvicorn httpx python-multipart requests `
            dash dash-mantine-components dash-iconify pandas plotly --quiet 2>$null | Out-Null
    }
    ok "[pip]       패키지 준비됨"

    # -- .env 확인 --------------------------------------------------
    $envFile = Join-Path $serverDir ".env"
    if (-not (Test-Path $envFile)) {
        $ex = Join-Path $serverDir ".env.example"
        if (Test-Path $ex) { Copy-Item $ex $envFile }
        war "[.env]     생성됨 - Supabase 키를 입력하세요!"
    } else {
        ok "[.env]      확인됨"
    }

    # -- uploads 디렉터리 -------------------------------------------
    $upDir = Join-Path $serverDir "uploads"
    if (-not (Test-Path $upDir)) { New-Item -ItemType Directory -Path $upDir | Out-Null }
    ok "[uploads]   디렉터리 준비됨"

    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  STEP 3  서비스 시작
# ================================================================
function Invoke-StartServices {
    cw "  +-- STEP 3/3  서비스 시작 --------------------------------------" DarkGray

    # 스캐너 임시 작업 디렉터리 (분석 산출물 .json 들이 여기 쌓임 — 프로젝트 루트 오염 방지)
    $scannerWork = Join-Path $ROOT "python\.work"
    if (-not (Test-Path $scannerWork)) {
        New-Item -ItemType Directory -Path $scannerWork -Force | Out-Null
    }

    inf "[1/3] Python 스캐너     (port 8000) 시작..."
    Start-Service "DSP-Scanner" $ROOT "uvicorn python.scanner:app --host 0.0.0.0 --port 8000" `
        @{ SCANNER_WORK_DIR = $scannerWork }
    Start-Sleep -Seconds 2

    inf "[2/3] Node.js API 서버  (port 3000) 시작..."
    Start-Service "DSP-Node" "$ROOT\server" "npm start"
    Start-Sleep -Seconds 2

    inf "[3/3] Dash 대시보드     (port 8080) 시작..."
    Start-Service "DSP-Dash" $ROOT "python frontend\front_end_v2.py"

    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  STEP 4  자가점검
# ================================================================
function Invoke-SelfCheck {
    cw "  +-- STEP 4  자가점검 (서비스 기동 대기 5초...) -----------------" DarkGray
    Start-Sleep -Seconds 5

    $allOk = $true

    function Check {
        param([string]$label, [bool]$result)
        if ($result) { ok $label }
        else         { ng $label; $script:allOk = $false }
    }

    Check "[도구] Trivy                " ($null -ne (Get-Command trivy -EA SilentlyContinue))
    Check "[도구] Grype                " ($null -ne (Get-Command grype -EA SilentlyContinue))
    Check "[도구] Syft                 " ($null -ne (Get-Command syft  -EA SilentlyContinue))
    Check "[서버] Python 스캐너 :8000  " (Test-Port 8000)
    Check "[서버] Node.js API   :3000  " (Test-Port 3000)
    Check "[서버] Dash 대시보드 :8080  " (Test-Port 8080)
    Check "[파일] server/.env          " (Test-Path "$ROOT\server\.env")
    Check "[파일] server/node_modules  " (Test-Path "$ROOT\server\node_modules")
    Check "[파일] python/scanner.py    " (Test-Path "$ROOT\python\scanner.py")
    Check "[파일] frontend/front_end   " (Test-Path "$ROOT\frontend\front_end_v2.py")
    Check "[폴더] server/uploads/      " (Test-Path "$ROOT\server\uploads")

    cw "  |" DarkGray
    if ($allOk) {
        cw "  |  [ALL OK] 모든 항목 정상입니다." Green
    } else {
        cw "  |  [!!] [NG] 항목을 확인하세요. 서비스가 뜨는 중일 수 있습니다." Yellow
    }
    cw "  +----------------------------------------------------------------" DarkGray
    cw ""
}

# ================================================================
#  서비스 전체 종료
# ================================================================
function Stop-AllServices {
    cw ""
    cw "  서비스 종료 중..." Yellow

    # 1. 우리가 띄운 cmd 창 + 자식 프로세스 트리 통째로 종료 (PID 기반 - 가장 확실)
    foreach ($id in $script:ServicePids) {
        cmd /c "taskkill /T /F /PID $id" 2>$null | Out-Null
    }
    $script:ServicePids = @()

    # 2. 혹시 남아있는 node / python / uvicorn 프로세스 정리
    Get-Process -Name "node"    -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name "python"  -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name "uvicorn" -ErrorAction SilentlyContinue | Stop-Process -Force

    # 3. 포트 점유 프로세스 정리 (마지막 안전망)
    foreach ($p in @(3000, 8000, 8080)) { Stop-Port $p }

    cw "  서비스 / 창 종료 완료." Green
    cw "  (브라우저 탭은 직접 닫아주세요)" Gray
    Start-Sleep -Seconds 2
}

# ================================================================
#  상태 바
# ================================================================
function Show-StatusBar {
    $t  = Get-Date -Format "HH:mm:ss"
    $r1 = Test-Port 8000; $r2 = Test-Port 3000; $r3 = Test-Port 8080
    $s1 = if ($r1) { "(*) ON " } else { "( ) OFF" }
    $s2 = if ($r2) { "(*) ON " } else { "( ) OFF" }
    $s3 = if ($r3) { "(*) ON " } else { "( ) OFF" }
    cw "  +-- 서비스 상태  $t ----------------------------------------" DarkGray
    Write-Host "  |  Python  스캐너  :8000  " -NoNewline; cw $s1 $(if ($r1){"Green"}else{"Red"})
    Write-Host "  |  Node.js API     :3000  " -NoNewline; cw $s2 $(if ($r2){"Green"}else{"Red"})
    Write-Host "  |  Dash   대시보드 :8080  " -NoNewline; cw $s3 $(if ($r3){"Green"}else{"Red"})
    cw "  +----------------------------------------------------------------" DarkGray
}

# ================================================================
#  STEP 5  실행 모드 선택 메뉴
# ================================================================
function Show-Menu {
    cw "  +========================================================+" Cyan
    cw "  |  DSP 실행 중                                       |" Cyan
    cw "  |  대시보드 : http://localhost:8080                        |" Cyan
    cw "  |  API      : http://localhost:3000/health                 |" Cyan
    cw "  |  스캐너   : http://localhost:8000/health                 |" Cyan
    cw "  +========================================================+" Cyan
    cw ""
    cw "  실행 모드를 선택하세요:" White
    cw ""
    cw "    [1]  모니터링 유지     - 이 창에서 서비스 상태 실시간 확인" White
    cw "    [2]  이 창만 닫기      - 서비스 창 3개는 그대로 유지" White
    cw "    [3]  모든 서비스 종료  - 서비스 창 3개 + 이 창 모두 종료" White
    cw ""

    while ($true) {
        $choice = (Read-Host "  선택 (1 / 2 / 3)").Trim()
        switch ($choice) {

            "1" {
                cw ""
                cw "  [모니터링]  Enter = 상태 갱신 / q = 종료 메뉴" DarkGray
                cw ""
                while ($true) {
                    Show-StatusBar
                    $key = (Read-Host "  > Enter 갱신 . q 종료메뉴").Trim()
                    if ($key -match '^[qQ]$') { break }
                }
                cw ""
                $yn = (Read-Host "  서비스를 종료하시겠습니까? (y / n)").Trim()
                if ($yn -match '^[yY]$') { Stop-AllServices; return }
                cw ""; Show-Menu; return
            }

            "2" {
                cw ""
                cw "  이 창만 닫습니다. 서비스 창 3개는 계속 실행됩니다." Green
                cw "  (작업표시줄에 Scanner / Node / Dash 창이 그대로 남음)" Gray
                cw "  나중에 종료하려면 run.bat 재실행 -> [3] 선택" DarkGray
                cw ""
                Read-Host "  Enter 키를 누르면 이 창이 닫힙니다" | Out-Null
                return
            }

            "3" {
                Stop-AllServices
                return
            }

            default {
                cw "  1, 2, 3 중 하나를 입력하세요." Yellow
            }
        }
    }
}

# ================================================================
#  메인 - 전체를 try-catch로 감싸서 오류 시 창이 닫히지 않음
# ================================================================
try {
    Show-Banner
    Invoke-PortCleanup

    Show-Banner
    Invoke-StackSetup

    Show-Banner
    Invoke-StartServices

    Show-Banner
    Invoke-SelfCheck

    # 브라우저는 front_end_v2.py 가 자체적으로 엽니다 (중복 방지)

    Show-Menu

} catch {
    cw ""
    cw "  ==========================================" Red
    cw "  오류 발생:" Red
    cw "  $($_.Exception.Message)" Red
    cw "  위치: $($_.InvocationInfo.PositionMessage)" Red
    cw "  ==========================================" Red
    cw ""
    Read-Host "  오류 내용을 확인하고 Enter 를 누르세요"
}
