﻿#!/bin/bash
# ============================================================
# DSP 서비스 시작 (Ubuntu)
# 실행: chmod +x start.sh && ./start.sh
# ============================================================
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVER_DIR="$ROOT_DIR/server"
PYTHON_DIR="$ROOT_DIR/python"
LOG_DIR="$ROOT_DIR/logs"

mkdir -p "$LOG_DIR"

# ── Redis 확인 ──────────────────────────────────────────────
if ! systemctl is-active --quiet redis-server 2>/dev/null; then
    echo "[start] Redis 시작 중..."
    sudo systemctl start redis-server 2>/dev/null || redis-server --daemonize yes
fi
echo "[start] Redis ✓"

# ── Python 교차 분석 스캐너 (백그라운드) ────────────────────
if lsof -i:8000 -t >/dev/null 2>&1; then
    echo "[start] Python 스캐너 이미 실행 중 (port 8000) ✓"
else
    echo "[start] Python 스캐너 시작 중..."
    cd "$ROOT_DIR"
    nohup python3 -m uvicorn python.scanner:app --host 0.0.0.0 --port 8000 \
        > "$LOG_DIR/python.log" 2>&1 &
    echo $! > "$LOG_DIR/python.pid"
    echo "[start] Python 스캐너 PID: $(cat $LOG_DIR/python.pid) ✓"
fi

# ── Node.js 서버 (백그라운드) ────────────────────────────────
if lsof -i:3000 -t >/dev/null 2>&1; then
    echo "[start] 서버 이미 실행 중 (port 3000) ✓"
else
    echo "[start] API 서버 시작 중..."
    cd "$SERVER_DIR"
    nohup npm start > "$LOG_DIR/server.log" 2>&1 &
    echo $! > "$LOG_DIR/server.pid"
    echo "[start] API 서버 PID: $(cat $LOG_DIR/server.pid) ✓"
fi

# ── Bull 워커 (백그라운드) ───────────────────────────────────
echo "[start] 스캔 워커 시작 중..."
cd "$SERVER_DIR"
nohup npm run worker > "$LOG_DIR/worker.log" 2>&1 &
echo $! > "$LOG_DIR/worker.pid"
echo "[start] 워커 PID: $(cat $LOG_DIR/worker.pid) ✓"

echo ""
echo "✅ DSP 시작 완료"
echo "   웹 UI  → http://localhost:3000"
echo "   API    → http://localhost:3000/health"
echo "   로그   → $LOG_DIR/"
echo "   중지   → ./stop.sh"
